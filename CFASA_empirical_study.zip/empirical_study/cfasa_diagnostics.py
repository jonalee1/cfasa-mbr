"""
CFASA Enhanced Diagnostics Module - Publication Version

Provides comprehensive diagnostic output for foundation section reporting.
Supports both supervised and self-consistency modes.

Usage:
    from cfasa_diagnostics import run_enhanced_diagnostics
    results = run_enhanced_diagnostics(n_samples=800, n_items=5, mode='supervised')

Author: Jonathan Lee
Version: 0.35.0

Changes from v0.32.0:
- Updated history keys: val_corr, val_js, val_gt_corr, val_metric
- Updated training result keys: final_val_corr, final_val_js, final_gt_corr
- Mode-specific reporting (JS for self-consistency, correlation for supervised)
- Separate GT correlation reporting in self-consistency mode
"""
from __future__ import annotations
from typing import Dict, Optional

import numpy as np
import torch

from cfasa_config import RANDOM_SEED, DEVICE, set_reproducible_state
from cfasa_data import UniversalPersonaGenerator, AttentionPersonaGenerator
from cfasa_training import CFASATrainer
from cfasa_utils import evaluate_attention_recovery, characterize_personas, cluster_attention_patterns


def run_enhanced_diagnostics(n_samples: int = 800, 
                             n_items: int = 5,
                             mode: str = 'supervised',
                             verbose: bool = True) -> Dict:
    """
    Enhanced foundation demonstration with detailed diagnostics.
    
    Args:
        n_samples: Number of samples to generate
        n_items: Number of items (4 or 5 supported with domain labels)
        mode: Training mode - 'supervised' or 'self_consistency'
        verbose: Whether to print detailed output
        
    Returns:
        Dictionary containing all results and diagnostics
    """
    set_reproducible_state(RANDOM_SEED)
    
    if verbose:
        print("CFASA Enhanced Foundation Diagnostics")
        print("=" * 80)
        print(f"Mode: {mode} | Items: {n_items} | Samples: {n_samples}")
    
    # =========================================================================
    # 1. Generate Controlled Dataset
    # =========================================================================
    if verbose:
        print("\n1. Generating Controlled Validation Dataset")
        print("-" * 80)
    
    generator = UniversalPersonaGenerator(n_items=n_items, n_personas=3)
    
    # Set domain-specific labels
    if n_items == 4:
        generator.set_domain_labels(
            item_labels=['Social Withdrawal', 'Somatic Symptoms', 
                        'Sleep/Appetite', 'Cognitive/Anhedonia'],
            persona_names=['cognitive_focused', 'somatic_focused', 'social_focused']
        )
    elif n_items == 5:
        generator.set_domain_labels(
            item_labels=['Social Withdrawal', 'Somatic Symptoms', 
                        'Sleep/Appetite', 'Cognitive/Anhedonia', 'Mood/Affect'],
            persona_names=['cognitive_focused', 'somatic_focused', 'social_focused']
        )
    
    dataset = generator.generate_dataset(n_samples=n_samples)
    true_attention = dataset['true_attention_patterns']
    
    # Calculate true diversity (normalized variance)
    max_var = (1/n_items) * (1 - 1/n_items)  # Maximum variance for simplex
    true_diversity = np.sum(np.var(true_attention, axis=0)) / (n_items * max_var)
    
    if verbose:
        print(f"Generated {n_samples} samples with {len(generator.persona_names)} personas")
        print(f"True attention diversity: {true_diversity:.1%}")
        
        for name, template in zip(generator.persona_names, generator.templates):
            count = sum(1 for p in dataset['individual_assignments'] if p == name)
            pattern_str = ', '.join([f'{x:.3f}' for x in template])
            print(f"  {name}: {count} individuals")
            print(f"    Template: [{pattern_str}]")
    
    # =========================================================================
    # 2. Train CFASA with Detailed Monitoring
    # =========================================================================
    if verbose:
        print(f"\n2. CFASA Training ({mode} mode)")
        print("-" * 80)
    
    trainer = CFASATrainer(n_items=n_items, n_attention_heads=3, mode=mode)
    initial_temp = 1.5  # Default initial temperature
    
    if verbose:
        print(f"Architecture: Dual-encoder + {trainer.n_attention_heads}-head attention")
        print(f"Initial temperature: {initial_temp:.2f}")
        print(f"Loss function: {trainer.loss_function}")
        print(f"Loss weights: {trainer.loss_weights}")
        if mode == 'self_consistency':
            print(f"Alpha tempering: {trainer.alpha_tempering}")
            print(f"Entropy floor: {trainer.entropy_floor:.3f}")
    
    # Training with appropriate ground truth handling
    if mode == 'supervised':
        training_results = trainer.train(
            responses=dataset['responses'],
            true_attention_patterns=true_attention,
            n_epochs=220,
            verbose=verbose
        )
    else:  # self_consistency
        training_results = trainer.train(
            responses=dataset['responses'],
            true_attention_patterns=true_attention,  # For validation metrics only
            n_epochs=220,
            verbose=verbose
        )
    
    # Extract training diagnostics (v35 keys)
    final_temp = trainer.training_history['temperature'][-1]
    
    # Mode-appropriate validation metric extraction
    if mode == 'supervised':
        # Supervised: primary metric is correlation with ground truth
        max_val_metric = max(trainer.training_history['val_corr'])
        final_val_metric = training_results['final_val_corr']
        metric_name = "correlation"
    else:
        # Self-consistency: primary metric is JS divergence (lower = better)
        # But we also have GT correlation for diagnostic purposes
        val_js_history = trainer.training_history['val_js']
        min_val_js = min([x for x in val_js_history if not np.isnan(x)], default=float('nan'))
        final_val_js = training_results['final_val_js']
        final_gt_corr = training_results['final_gt_corr']
        metric_name = "JS divergence"
    
    if verbose:
        print(f"\nTraining Diagnostics:")
        print(f"  Epochs completed: {training_results['epochs_trained']}")
        print(f"  Training time: {training_results['training_time']:.1f}s")
        print(f"  Temperature evolution: {initial_temp:.2f} -> {final_temp:.2f}")
        
        if mode == 'supervised':
            print(f"  Peak validation correlation: {max_val_metric:.3f}")
            print(f"  Final validation correlation: {final_val_metric:.3f}")
        else:
            print(f"  Final validation JS divergence: {final_val_js:.4f}")
            print(f"  Final target correlation: {training_results['final_val_corr']:.3f}")
            if not np.isnan(final_gt_corr):
                print(f"  Final GT correlation (diagnostic): {final_gt_corr:.3f}")
    
    # =========================================================================
    # 3. Comprehensive Pattern Recovery Analysis
    # =========================================================================
    if verbose:
        print(f"\n3. Pattern Recovery Analysis")
        print("-" * 80)
    
    predictions = trainer.predict_attention_patterns(dataset['responses'])
    predicted_attention = predictions['attention_weights']
    
    # Calculate recovered diversity
    recovered_diversity = np.sum(np.var(predicted_attention, axis=0)) / (n_items * max_var)
    
    if verbose:
        print(f"Recovered attention diversity: {recovered_diversity:.1%}")
        print(f"Diversity preservation rate: {recovered_diversity/true_diversity:.1%}")
    
    # Individual-level correlations (with ground truth)
    individual_correlations = []
    for i in range(len(predicted_attention)):
        corr = np.corrcoef(predicted_attention[i], true_attention[i])[0, 1]
        if not np.isnan(corr):
            individual_correlations.append(corr)
    
    individual_correlations = np.array(individual_correlations)
    
    # Entropy analysis of learned patterns
    def compute_entropy(p, eps=1e-8):
        return -np.sum(p * np.log(np.clip(p, eps, 1.0)))
    
    learned_entropies = np.array([compute_entropy(p) for p in predicted_attention])
    true_entropies = np.array([compute_entropy(p) for p in true_attention])
    max_entropy = np.log(n_items)
    
    if verbose:
        print(f"\nIndividual-Level Recovery (vs Ground Truth):")
        print(f"  Mean correlation: {np.mean(individual_correlations):.3f}")
        print(f"  Correlation std: {np.std(individual_correlations):.3f}")
        print(f"  Strong recovery (r > 0.7): {np.mean(individual_correlations > 0.7):.1%}")
        print(f"  Excellent recovery (r > 0.9): {np.mean(individual_correlations > 0.9):.1%}")
        
        print(f"\nAttention Entropy Analysis:")
        print(f"  Max possible entropy: {max_entropy:.3f}")
        print(f"  True entropy: mean={np.mean(true_entropies):.3f}, std={np.std(true_entropies):.3f}")
        print(f"  Learned entropy: mean={np.mean(learned_entropies):.3f}, std={np.std(learned_entropies):.3f}")
        
        # Classify patterns by entropy
        entropy_ratio = learned_entropies / max_entropy
        n_concentrated = np.sum(entropy_ratio < 0.5)
        n_balanced = np.sum((entropy_ratio >= 0.5) & (entropy_ratio < 0.8))
        n_diffuse = np.sum(entropy_ratio >= 0.8)
        print(f"  Pattern types: Concentrated={n_concentrated}, Balanced={n_balanced}, Diffuse={n_diffuse}")
        
        # Distribution of recovered attention weights
        print(f"\nAttention Weight Statistics by Item:")
        for j in range(n_items):
            true_mean = np.mean(true_attention[:, j])
            pred_mean = np.mean(predicted_attention[:, j])
            true_std = np.std(true_attention[:, j])
            pred_std = np.std(predicted_attention[:, j])
            
            item_label = generator.item_labels[j] if j < len(generator.item_labels) else f"Item {j+1}"
            print(f"  {item_label}:")
            print(f"    True:      mu={true_mean:.3f}, sigma={true_std:.3f}")
            print(f"    Recovered: mu={pred_mean:.3f}, sigma={pred_std:.3f}")
    
    # =========================================================================
    # 4. Persona-Level Validation
    # =========================================================================
    evaluation_results = evaluate_attention_recovery(
        predicted_attention, true_attention, dataset['individual_assignments']
    )
    
    if verbose:
        print(f"\n4. Persona-Level Pattern Validation")
        print("-" * 80)
        
        for idx, persona_name in enumerate(generator.persona_names):
            mask = np.array(dataset['individual_assignments']) == persona_name
            persona_true = true_attention[mask]
            persona_pred = predicted_attention[mask]
            
            # Mean pattern recovery
            true_mean_pattern = np.mean(persona_true, axis=0)
            pred_mean_pattern = np.mean(persona_pred, axis=0)
            pattern_correlation = np.corrcoef(true_mean_pattern, pred_mean_pattern)[0, 1]
            
            # Within-persona consistency
            within_persona_var = np.mean(np.var(persona_pred, axis=0))
            
            # Entropy characterization
            pred_entropies = [compute_entropy(p) for p in persona_pred]
            mean_entropy = np.mean(pred_entropies)
            entropy_type = "Concentrated" if mean_entropy/max_entropy < 0.5 else \
                          ("Balanced" if mean_entropy/max_entropy < 0.8 else "Diffuse")
            
            print(f"  {persona_name} (n={mask.sum()}):")
            print(f"    True pattern:  [{', '.join([f'{x:.3f}' for x in true_mean_pattern])}]")
            print(f"    Recovered:     [{', '.join([f'{x:.3f}' for x in pred_mean_pattern])}]")
            print(f"    Pattern correlation: r={pattern_correlation:.3f}")
            print(f"    Entropy: {mean_entropy:.2f} ({entropy_type})")
            print(f"    Within-group variance: {within_persona_var:.4f}")
    
    # =========================================================================
    # 4b. Persona Characterization (Interpretation Aid)
    # =========================================================================
    if verbose:
        print(f"\n4b. Persona Characterization (Interpretation Aid)")
        print("-" * 80)
    
    # Determine persona indices for characterization
    if mode == 'supervised':
        # Use true persona assignments
        persona_name_to_idx = {name: idx for idx, name in enumerate(generator.persona_names)}
        persona_indices = np.array([persona_name_to_idx[name] 
                                   for name in dataset['individual_assignments']])
        characterization_source = "True persona assignments"
    else:
        # Discover personas via clustering on learned attention
        persona_indices = cluster_attention_patterns(predicted_attention, n_clusters=3)
        characterization_source = "Discovered via clustering"
    
    if verbose:
        print(f"  Source: {characterization_source}")
    
    # Run characterization on LEARNED attention patterns
    persona_report = characterize_personas(
        attention_weights=predicted_attention,
        persona_indices=persona_indices,
        item_labels=generator.item_labels,
        construct_name="Depression Symptom Assessment" if n_items <= 5 else "Psychological Construct",
        verbose=verbose
    )
    
    # =========================================================================
    # 5. Architecture Component Analysis
    # =========================================================================
    if verbose:
        print(f"\n5. Architecture Component Analysis")
        print("-" * 80)
    
    # Examine intermediate representations
    sample_responses = dataset['responses'][:10]
    trainer.network.eval()
    
    with torch.no_grad():
        X_scaled = trainer.response_scaler.transform(sample_responses)
        X_tensor = torch.as_tensor(X_scaled, dtype=torch.float32, device=DEVICE)
        
        # Get intermediate representations
        primary_context = trainer.network.primary_encoder(X_tensor)
        secondary_context = trainer.network.secondary_encoder(X_tensor)
        combined_context = torch.cat([primary_context, secondary_context], dim=1)
        fused_context = trainer.network.context_fusion(combined_context)
        
        # Multi-head attention outputs
        attention_head_logits = [head(fused_context) for head in trainer.network.attention_heads]
        
        # Calculate head diversity (lower similarity = more diverse)
        head_similarities = []
        for i in range(len(attention_head_logits)):
            for j in range(i+1, len(attention_head_logits)):
                sim = torch.nn.functional.cosine_similarity(
                    attention_head_logits[i], attention_head_logits[j], dim=1
                ).mean().item()
                head_similarities.append(sim)
        
        mean_head_similarity = np.mean(head_similarities) if head_similarities else 0.0
        head_diversity = 1 - mean_head_similarity
    
    if verbose:
        print(f"  Encoder dimensions:")
        print(f"    Primary encoder output: {primary_context.shape[1]}")
        print(f"    Secondary encoder output: {secondary_context.shape[1]}")
        print(f"    Fused context: {fused_context.shape[1]}")
        print(f"  Multi-head attention:")
        print(f"    Number of heads: {len(attention_head_logits)}")
        print(f"    Head diversity score: {head_diversity:.3f} (1.0 = fully diverse)")
        print(f"  Temperature parameter:")
        print(f"    Final value: {final_temp:.2f}")
        print(f"    Status: {'OK' if 0.5 < final_temp < 2.5 else 'WARNING'}")
    
    # =========================================================================
    # 6. Training Stability & Robustness Indicators
    # =========================================================================
    if verbose:
        print(f"\n6. Training Stability & Robustness")
        print("-" * 80)
    
    # Training stability (coefficient of variation in final epochs)
    loss_history = trainer.training_history['train_loss']
    loss_stability = np.std(loss_history[-10:]) / (np.mean(loss_history[-10:]) + 1e-8)
    
    # Convergence quality (mode-appropriate)
    if mode == 'supervised':
        val_history = trainer.training_history['val_corr']
        final_performance = val_history[-1]
        peak_performance = max(val_history)
        performance_gap = peak_performance - final_performance
    else:
        # For self-consistency, use negative JS (higher = better for comparison)
        val_history = [-x if not np.isnan(x) else float('-inf') 
                      for x in trainer.training_history['val_js']]
        final_performance = val_history[-1]
        peak_performance = max(val_history)
        performance_gap = peak_performance - final_performance
    
    if verbose:
        print(f"  Training convergence:")
        print(f"    Loss stability (CV): {loss_stability:.4f} (lower = more stable)")
        print(f"    Performance gap: {performance_gap:.4f} (peak - final)")
        print(f"    Early stopping: {'Yes' if training_results['epochs_trained'] < 220 else 'No'}")
        print(f"  Architecture robustness:")
        print(f"    Head diversity: {'OK' if head_diversity > 0.2 else 'LOW'}")
        print(f"    Temperature: {'OK' if 0.5 < final_temp < 2.5 else 'WARNING'}")
    
    # =========================================================================
    # 7. Persona Characterization (Interpretive Report)
    # =========================================================================
    # Convert string assignments to integer indices for characterization
    persona_name_to_idx = {name: idx for idx, name in enumerate(generator.persona_names)}
    persona_indices = np.array([persona_name_to_idx[p] for p in dataset['individual_assignments']])
    
    persona_report = characterize_personas(
        attention_weights=predicted_attention,
        persona_indices=persona_indices,
        item_labels=generator.item_labels,
        construct_name="Depression Symptom Attention",
        verbose=verbose
    )
    
    # =========================================================================
    # 8. Summary for Publication
    # =========================================================================

    # =========================================================================
    # 8. Summary for Publication
    # =========================================================================
    if verbose:
        print(f"\n" + "=" * 80)
        print("FOUNDATION VALIDATION SUMMARY")
        print("=" * 80)
        
        print(f"\nExperimental Setup:")
        print(f"  Dataset: {n_samples} samples, {n_items} items, 3 personas")
        print(f"  True diversity: {true_diversity:.1%}")
        print(f"  Training mode: {mode}")
        print(f"  Architecture: Dual-encoder + 3-head attention + temperature scaling")
        
        # Mode-specific core metrics
        if mode == 'supervised':
            print(f"\nCore Performance Metrics (Ground Truth Recovery):")
            print(f"  Mean individual correlation: r = {np.mean(individual_correlations):.3f}")
            print(f"  Mean persona correlation: r = {evaluation_results['mean_persona_correlation']:.3f}")
            print(f"  Strong recovery rate (r > 0.7): {evaluation_results['strong_recovery_rate']:.1%}")
            print(f"  Excellent recovery rate (r > 0.9): {np.mean(individual_correlations > 0.9):.1%}")
            print(f"  Diversity preservation: {recovered_diversity/true_diversity:.1%}")
        else:  # self_consistency
            print(f"\nCore Performance Metrics (Profile-Respecting Attention):")
            print(f"  Final target correlation: r = {training_results['final_val_corr']:.3f}")
            print(f"  Final JS divergence: {final_val_js:.4f}")
            print(f"  Learned entropy: mean = {np.mean(learned_entropies):.3f} (max = {max_entropy:.3f})")
            print(f"  Diversity preservation: {recovered_diversity/true_diversity:.1%}")
            
            print(f"\nDiagnostic Only (GT Comparison):")
            print(f"  Mean GT correlation: r = {np.mean(individual_correlations):.3f}")
            if not np.isnan(final_gt_corr):
                print(f"  Final validation GT corr: r = {final_gt_corr:.3f}")
            print(f"  Note: Low GT corr is expected when estimands differ (see Panel 2 logic)")
        
        print(f"\nArchitectural Validation:")
        print(f"  Multi-head diversity: {head_diversity:.3f}")
        print(f"  Temperature adaptation: {initial_temp:.2f} -> {final_temp:.2f}")
        print(f"  Training stability (CV): {loss_stability:.4f}")
        print(f"  Epochs to convergence: {training_results['epochs_trained']}")
        
        # Mode-specific success criteria
        if mode == 'supervised':
            all_checks_passed = (
                np.mean(individual_correlations) > 0.9 and
                evaluation_results['strong_recovery_rate'] > 0.9 and
                head_diversity > 0.2 and
                0.5 < final_temp < 2.5
            )
        else:  # self_consistency
            # B-only: profile-respecting attention, not GT recovery
            all_checks_passed = (
                training_results['final_val_corr'] > 0.7 and  # Matches response profile
                not np.isnan(final_val_js) and final_val_js < 0.1 and  # Low JS divergence
                head_diversity > 0.2 and
                0.5 < final_temp < 2.5
            )
        
        print(f"\nConclusion:")
        if all_checks_passed:
            if mode == 'supervised':
                print(f"  [PASS] CFASA successfully recovers individual attention patterns")
                print(f"         with high fidelity across diverse personas.")
            else:
                print(f"  [PASS] CFASA learns profile-respecting attention patterns")
                print(f"         that reflect individual response distributions.")
        else:
            print(f"  [CHECK] Some metrics below optimal thresholds.")
            print(f"          Review individual diagnostics above.")

    # =========================================================================
    # Return comprehensive results
    # =========================================================================
    return {
        'dataset': dataset,
        'trainer': trainer,
        'training_results': training_results,
        'predictions': predictions,
        'evaluation_results': evaluation_results,
        'persona_report': persona_report,
        'diagnostics': {
            'n_items': n_items,
            'n_samples': n_samples,
            'mode': mode,
            'true_diversity': true_diversity,
            'recovered_diversity': recovered_diversity,
            'diversity_preservation': recovered_diversity / true_diversity,
            'individual_correlations': individual_correlations,
            'mean_individual_correlation': np.mean(individual_correlations),
            'strong_recovery_rate': np.mean(individual_correlations > 0.7),
            'excellent_recovery_rate': np.mean(individual_correlations > 0.9),
            'head_diversity': head_diversity,
            'temperature_initial': initial_temp,
            'temperature_final': final_temp,
            'training_stability': loss_stability,
            'performance_gap': performance_gap,
            'epochs_trained': training_results['epochs_trained'],
            'learned_entropies': learned_entropies,
            'true_entropies': true_entropies
        }
    }


def compare_modes(n_samples: int = 800, n_items: int = 5, verbose: bool = True) -> Dict:
    """
    Compare supervised vs self-consistency mode performance.
    
    Args:
        n_samples: Number of samples
        n_items: Number of items
        verbose: Whether to print comparison
        
    Returns:
        Dictionary with results from both modes
    """
    if verbose:
        print("=" * 80)
        print("CFASA MODE COMPARISON")
        print("=" * 80)
    
    # Run supervised mode
    if verbose:
        print("\n>>> SUPERVISED MODE <<<\n")
    supervised_results = run_enhanced_diagnostics(
        n_samples=n_samples, n_items=n_items, mode='supervised', verbose=verbose
    )
    
    # Run self-consistency mode
    if verbose:
        print("\n\n>>> SELF-CONSISTENCY MODE <<<\n")
    self_consistency_results = run_enhanced_diagnostics(
        n_samples=n_samples, n_items=n_items, mode='self_consistency', verbose=verbose
    )
    
    # Comparison summary
    if verbose:
        print("\n" + "=" * 80)
        print("MODE COMPARISON SUMMARY")
        print("=" * 80)
        
        sup = supervised_results['diagnostics']
        sc = self_consistency_results['diagnostics']
        
        print(f"\n{'Metric':<35} {'Supervised':>12} {'Self-Consist':>12}")
        print("-" * 60)
        print(f"{'Mean GT correlation':<35} {sup['mean_individual_correlation']:>12.3f} {sc['mean_individual_correlation']:>12.3f}")
        print(f"{'Strong recovery rate (r>0.7)':<35} {sup['strong_recovery_rate']:>12.1%} {sc['strong_recovery_rate']:>12.1%}")
        print(f"{'Excellent recovery rate (r>0.9)':<35} {sup['excellent_recovery_rate']:>12.1%} {sc['excellent_recovery_rate']:>12.1%}")
        print(f"{'Diversity preservation':<35} {sup['diversity_preservation']:>12.1%} {sc['diversity_preservation']:>12.1%}")
        print(f"{'Head diversity':<35} {sup['head_diversity']:>12.3f} {sc['head_diversity']:>12.3f}")
        print(f"{'Final temperature':<35} {sup['temperature_final']:>12.2f} {sc['temperature_final']:>12.2f}")
        print(f"{'Epochs trained':<35} {sup['epochs_trained']:>12d} {sc['epochs_trained']:>12d}")
        
        # Entropy comparison
        print(f"\n{'Entropy Analysis':<35} {'Supervised':>12} {'Self-Consist':>12}")
        print("-" * 60)
        print(f"{'Mean learned entropy':<35} {np.mean(sup['learned_entropies']):>12.3f} {np.mean(sc['learned_entropies']):>12.3f}")
        print(f"{'Mean true entropy':<35} {np.mean(sup['true_entropies']):>12.3f} {np.mean(sc['true_entropies']):>12.3f}")
        
        # Self-consistency specific metrics
        sc_results = self_consistency_results['training_results']
        print(f"\nSelf-Consistency Specific:")
        print(f"  Final JS divergence: {sc_results['final_val_js']:.4f}")
        print(f"  Final target correlation: {sc_results['final_val_corr']:.3f}")
        
        print(f"\nInterpretation:")
        print(f"  Supervised mode: Trains with ground truth → validates method works")
        print(f"  Self-consistency: Learns from data alone → profile-respecting attention")
        print(f"  GT correlation in self-consistency is DIAGNOSTIC, not training objective")
    
    return {
        'supervised': supervised_results,
        'self_consistency': self_consistency_results
    }


if __name__ == "__main__":
    # Default: run mode comparison
    comparison = compare_modes(n_samples=800, n_items=5, verbose=True)
