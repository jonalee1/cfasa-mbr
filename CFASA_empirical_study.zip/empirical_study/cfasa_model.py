"""
CFASA Model Module

Neural network architecture with dual-encoder design and multi-head attention
for learning individual-specific attention patterns.

Author: Jonathan Lee
Version: 0.32.0
"""
from __future__ import annotations
from typing import Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class CFASANetwork(nn.Module):
    """
    CFASA neural network with dual-encoder architecture and multi-head attention.
    
    Architecture:
    1. Dual response encoders process input patterns from different perspectives
    2. Context fusion combines encoder outputs
    3. Multi-head attention mechanism generates attention weights
    4. Temperature-scaled softmax ensures valid probability distributions
    5. Factor predictor refines factor score estimates
    """
    
    def __init__(self, n_items: int = 5, hidden_dim: int = 64, 
                 fusion_dim: int = 32, n_attention_heads: int = 3,
                 temperature_init: float = 1.5):
        super().__init__()
        
        self.n_items = n_items
        self.n_attention_heads = n_attention_heads
        
        # Primary response encoder: high-capacity processing
        self.primary_encoder = nn.Sequential(
            nn.Linear(n_items, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.10),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 32)
        )
        
        # Secondary response encoder: complementary perspective
        self.secondary_encoder = nn.Sequential(
            nn.Linear(n_items, 24),
            nn.ReLU(),
            nn.Linear(24, 16)
        )
        
        # Context fusion layer
        self.context_fusion = nn.Sequential(
            nn.Linear(32 + 16, 48),  # Concatenated encoder outputs
            nn.ReLU(),
            nn.Dropout(0.05),
            nn.Linear(48, fusion_dim)
        )
        
        # Multi-head attention mechanism
        self.attention_heads = nn.ModuleList([
            nn.Linear(fusion_dim, n_items) for _ in range(n_attention_heads)
        ])
        
        # Attention combination layer
        self.attention_combiner = nn.Linear(n_attention_heads * n_items, n_items)
        
        # Temperature parameter for attention sharpness control
        temperature_logit_init = np.log(np.exp(max(0.1, temperature_init - 0.5)) - 1.0)
        self.temperature_logit = nn.Parameter(torch.tensor(float(temperature_logit_init)))
        
        # Factor score refinement head
        self.factor_predictor = nn.Sequential(
            nn.Linear(1, 16),
            nn.ReLU(),
            nn.Linear(16, 1)
        )
        
        # Initialize attention-related weights with small values for stable training
        self._initialize_attention_weights()
    
    def _initialize_attention_weights(self):
        """Initialize attention mechanism weights for stable early training."""
        for head in self.attention_heads:
            nn.init.trunc_normal_(head.weight, std=0.01)
            nn.init.zeros_(head.bias)
        
        nn.init.trunc_normal_(self.attention_combiner.weight, std=0.01)
        nn.init.zeros_(self.attention_combiner.bias)
    
    def forward(self, responses: torch.Tensor, 
                return_attention_heads: bool = False) -> Tuple[torch.Tensor, ...]:
        """
        Forward pass through CFASA network.
        
        Args:
            responses: Input response patterns [batch_size, n_items]
            return_attention_heads: Whether to return individual head outputs
            
        Returns:
            attention_weights: Final attention distributions [batch_size, n_items]
            factor_scores: Raw factor scores [batch_size, 1]
            refined_scores: Refined factor scores [batch_size, 1]
            head_outputs: (Optional) Individual attention head outputs
        """
        # Dual encoding of response patterns
        primary_context = self.primary_encoder(responses)
        secondary_context = self.secondary_encoder(responses)
        
        # Fuse encoder outputs
        combined_context = torch.cat([primary_context, secondary_context], dim=1)
        fused_context = self.context_fusion(combined_context)
        
        # Multi-head attention processing
        attention_head_logits = [head(fused_context) for head in self.attention_heads]
        
        # Combine attention heads
        concatenated_heads = torch.cat(attention_head_logits, dim=1)
        raw_attention_logits = self.attention_combiner(concatenated_heads)
        
        # Apply temperature-scaled softmax
        temperature = torch.clamp(
            F.softplus(self.temperature_logit) + 0.5, 
            min=0.3, max=3.0
        )
        attention_weights = F.softmax(raw_attention_logits / temperature, dim=1)
        
        # Compute factor scores as attention-weighted sum
        factor_scores = torch.sum(attention_weights * responses, dim=1, keepdim=True)
        
        # Refine factor scores through prediction head
        refined_scores = self.factor_predictor(factor_scores)
        
        if return_attention_heads:
            head_weights = [
                F.softmax(head_logits / temperature, dim=1) 
                for head_logits in attention_head_logits
            ]
            return attention_weights, factor_scores, refined_scores, head_weights
        
        return attention_weights, factor_scores, refined_scores
