"""
CFASA Utilities Module

Evaluation metrics and diagnostic utilities for assessing 
attention pattern recovery quality.

Author: Jonathan Lee
Version: 0.32.0
"""
from __future__ import annotations
from typing import Optional, Dict, List

import numpy as np
from scipy.stats import entropy as scipy_entropy


def evaluate_attention_recovery(predicted_attention: np.ndarray, 
                              true_attention: np.ndarray,
                              individual_assignments: Optional[List[str]] = None) -> Dict[str, float]:
    """
    Evaluate quality of attention pattern recovery.
    
    Args:
        predicted_attention: Predicted attention weights [n_samples, n_items]
        true_attention: True attention weights [n_samples, n_items]
        individual_assignments: Optional persona assignments for detailed analysis
        
    Returns:
        Dictionary with evaluation metrics:
        - mean_individual_correlation: Average per-person correlation
        - std_individual_correlation: Standard deviation of correlations
        - strong_recovery_rate: Proportion with r > 0.7
        - acceptable_recovery_rate: Proportion with r > 0.5
        - overall_attention_correlation: Flattened correlation
        - persona_correlations: (if assignments provided) Per-persona correlations
        - mean_persona_correlation: (if assignments provided) Average across personas
    """
    # Individual-level correlations
    individual_correlations = []
    for i in range(len(predicted_attention)):
        corr = np.corrcoef(predicted_attention[i], true_attention[i])[0, 1]
        if not np.isnan(corr):
            individual_correlations.append(corr)
    
    results = {
        'mean_individual_correlation': float(np.mean(individual_correlations)),
        'std_individual_correlation': float(np.std(individual_correlations)),
        'strong_recovery_rate': float(np.mean(np.array(individual_correlations) > 0.7)),
        'acceptable_recovery_rate': float(np.mean(np.array(individual_correlations) > 0.5)),
        'overall_attention_correlation': float(np.corrcoef(
            predicted_attention.flatten(), 
            true_attention.flatten()
        )[0, 1])
    }
    
    # Persona-level analysis if assignments provided
    if individual_assignments is not None:
        unique_personas = list(set(individual_assignments))
        persona_correlations = {}
        
        for persona in unique_personas:
            mask = np.array(individual_assignments) == persona
            if np.sum(mask) > 0:
                persona_pred = predicted_attention[mask]
                persona_true = true_attention[mask]
                
                # Mean pattern correlation
                pred_mean = np.mean(persona_pred, axis=0)
                true_mean = np.mean(persona_true, axis=0)
                persona_corr = np.corrcoef(pred_mean, true_mean)[0, 1]
                
                persona_correlations[persona] = float(persona_corr)
        
        results['persona_correlations'] = persona_correlations
        results['mean_persona_correlation'] = float(np.mean(list(persona_correlations.values())))
    
    return results


def compute_attention_diversity(attention_patterns: np.ndarray) -> Dict[str, float]:
    """
    Compute diversity metrics for attention patterns.
    
    Args:
        attention_patterns: Attention weights [n_samples, n_items]
        
    Returns:
        Dictionary with diversity metrics:
        - mean_entropy: Average entropy across individuals
        - std_entropy: Standard deviation of entropy
        - pattern_variance: Total variance in attention patterns
    """
    n_items = attention_patterns.shape[1]
    
    # Compute entropy for each individual
    epsilon = 1e-8
    entropies = -np.sum(
        attention_patterns * np.log(np.clip(attention_patterns, epsilon, 1.0)),
        axis=1
    )
    
    # Maximum entropy for uniform distribution
    max_entropy = np.log(n_items)
    normalized_entropies = entropies / max_entropy
    
    # Pattern variance
    pattern_variance = np.var(attention_patterns)
    
    return {
        'mean_entropy': float(np.mean(entropies)),
        'std_entropy': float(np.std(entropies)),
        'mean_normalized_entropy': float(np.mean(normalized_entropies)),
        'pattern_variance': float(pattern_variance),
        'diversity_index': float(np.std(attention_patterns.mean(axis=0)))
    }


def safe_correlation(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute Pearson correlation with handling for degenerate cases.
    
    Args:
        x: First array
        y: Second array
        
    Returns:
        Correlation coefficient, or NaN if undefined
    """
    if np.std(x) == 0 or np.std(y) == 0:
        return float('nan')
    return float(np.corrcoef(x, y)[0, 1])


def cluster_attention_patterns(attention_weights: np.ndarray,
                               n_clusters: int = 3,
                               random_state: int = 42) -> np.ndarray:
    """
    Cluster attention patterns for persona discovery in self-consistency mode.
    
    Uses K-Means clustering on attention weights to identify distinct
    measurement personas when ground truth is not available.
    
    Args:
        attention_weights: Attention patterns [n_samples, n_items]
        n_clusters: Number of clusters to form
        random_state: Random seed for reproducibility
        
    Returns:
        Integer cluster assignments [n_samples]
    """
    from sklearn.cluster import KMeans
    
    kmeans = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
    cluster_labels = kmeans.fit_predict(attention_weights)
    
    return cluster_labels


def characterize_personas(attention_weights: np.ndarray, 
                          persona_indices: np.ndarray, 
                          item_labels: Optional[List[str]] = None,
                          construct_name: str = "Construct",
                          verbose: bool = True) -> Dict:
    """
    Generate interpretive characterization of discovered attention personas.
    
    Helps reviewers and users understand what each persona represents by
    analyzing dominant focus, attention style (focused vs diffuse), and
    distinctive features compared to population average.
    
    Args:
        attention_weights: Attention patterns [n_samples, n_items]
        persona_indices: Integer persona assignment for each individual
        item_labels: Names for each item (defaults to "Item 1", "Item 2", etc.)
        construct_name: Name of the psychological construct being measured
        verbose: Whether to print the report
        
    Returns:
        Dictionary with persona characterizations:
        - personas: Dict mapping persona ID to characterization dict
        - global_mean: Population average attention pattern
    """
    N, J = attention_weights.shape
    unique_ids = np.unique(persona_indices)
    unique_ids.sort()
    
    if item_labels is None:
        item_labels = [f"Item {j+1}" for j in range(J)]
    
    # Global population mean for contrast
    global_mean = np.mean(attention_weights, axis=0)
    
    if verbose:
        print(f"\n{'='*60}")
        print(f"CFASA PERSONA CHARACTERIZATION: {construct_name}")
        print(f"{'='*60}")
        print(f"Population: N={N}, Items={J}")
        print(f"Global mean: [{', '.join([f'{w:.3f}' for w in global_mean])}]")
    
    personas = {}
    
    for k in unique_ids:
        # Get data for this persona
        mask = (persona_indices == k)
        n_k = np.sum(mask)
        if n_k == 0: 
            continue
        
        attn_k = attention_weights[mask]
        centroid = np.mean(attn_k, axis=0)
        prevalence = n_k / N
        
        # 1. Dominant Focus (Sort items by weight)
        dominance = sorted(zip(item_labels, centroid), key=lambda x: x[1], reverse=True)
        top_items = dominance[:2]
        
        # 2. Entropy Analysis (Focused vs Diffuse)
        c_norm = centroid / (centroid.sum() + 1e-9)
        ent = scipy_entropy(c_norm)
        max_ent = np.log(J)
        ent_ratio = ent / max_ent
        
        if ent_ratio < 0.6:
            focus_type = "Focused"
        elif ent_ratio < 0.85:
            focus_type = "Balanced"
        else:
            focus_type = "Diffuse"
        
        # 3. Contrast from Global Mean (Distinctive Features)
        contrast = centroid - global_mean
        contrast_sorted = sorted(zip(item_labels, contrast), key=lambda x: abs(x[1]), reverse=True)
        distinct_item, distinct_diff = contrast_sorted[0]
        
        # Store characterization
        personas[int(k)] = {
            'n': int(n_k),
            'prevalence': float(prevalence),
            'centroid': centroid.tolist(),
            'dominant_items': [(item, float(wt)) for item, wt in top_items],
            'entropy_ratio': float(ent_ratio),
            'focus_type': focus_type,
            'distinctive_item': distinct_item,
            'distinctive_diff': float(distinct_diff)
        }
        
        if verbose:
            sign = "+" if distinct_diff > 0 else ""
            dom_str = ", ".join([f"{item} ({wt:.2f})" for item, wt in top_items])
            
            print(f"\nPersona {k+1} (N={n_k}, {prevalence:.1%} of sample)")
            print(f"  Centroid:    [{', '.join([f'{w:.3f}' for w in centroid])}]")
            print(f"  Dominant:    {dom_str}")
            print(f"  Style:       {focus_type} (entropy ratio: {ent_ratio:.2f})")
            print(f"  Distinctive: {distinct_item} ({sign}{distinct_diff:.3f} vs population avg)")
    
    if verbose:
        print(f"\n{'-'*60}")
        print("Interpretation Guide:")
        print("  - Focused: Strong preference for specific items (entropy < 0.6)")
        print("  - Balanced: Moderate differentiation across items (0.6-0.85)")
        print("  - Diffuse: Near-uniform attention across items (> 0.85)")
        print(f"{'='*60}\n")
    
    return {
        'personas': personas,
        'global_mean': global_mean.tolist(),
        'n_personas': len(personas),
        'item_labels': item_labels,
        'construct_name': construct_name
    }
