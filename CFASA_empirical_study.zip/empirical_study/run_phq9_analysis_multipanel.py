"""
CFASA Empirical Study: PHQ-9 Analysis (Depression)
==================================================
Version 5 - Continuous Heterogeneity Framework

Research Question:
    "Among individuals experiencing depression symptoms, do people 
    differentially weight which symptoms define their depression?"

Methodological Advances in v5:
    1. Replaces K-Means clustering with simplex-appropriate methods
    2. Introduces Somatic-Cognitive Index (SCI) for continuous characterization
    3. Uses Compositional PCA (CLR transform) for dimensionality reduction
    4. Regression-based demographic analysis instead of chi-square
    5. Retains personas as heuristic categories for interpretability

Key Insight:
    Attention vectors live on the probability simplex (sum to 1, non-negative).
    K-Means uses Euclidean distance, which distorts simplex geometry.
    Individual heterogeneity is continuous, not class-based.

Data: NHANES 2017-2018, N ≈ 1,300 symptomatic adults

Usage:
    python run_phq9_analysis_multipanel.py

Required modules (same directory):
    cfasa_config.py, cfasa_data.py, cfasa_model.py, 
    cfasa_training.py, cfasa_utils.py, severity_table.py

Author: Jonathan Lee
Version: 1.2.0 (Empirical Study)

"""

import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt
from pathlib import Path
from scipy import stats
import warnings

# Import CFASA Suite
from cfasa_config import RANDOM_SEED, DEVICE, set_reproducible_state
from cfasa_training import CFASATrainer
from cfasa_utils import compute_attention_diversity
from severity_table import compute_severity_stratified_table, print_severity_table
import severity_table

# =============================================================================
# CONFIGURATION
# =============================================================================

DATA_FILE = Path("nhanes_2017_2018_complete_phq9.csv")

# PHQ-9 item codes and clinical labels
PHQ9_ITEMS = [f'DPQ{i:03d}' for i in range(10, 100, 10)]
ITEM_LABELS = [
    "Anhedonia",        # Item 1: Little interest/pleasure
    "Depressed Mood",   # Item 2: Feeling down/depressed/hopeless
    "Sleep",            # Item 3: Sleep problems
    "Fatigue",          # Item 4: Feeling tired/little energy
    "Appetite",         # Item 5: Poor appetite/overeating
    "Guilt",            # Item 6: Feeling bad about yourself
    "Concentration",    # Item 7: Trouble concentrating
    "Psychomotor",      # Item 8: Moving/speaking slowly or restless
    "Suicidality"       # Item 9: Thoughts of self-harm
]

# Clinical symptom domains
SOMATIC_ITEMS = ["Sleep", "Fatigue", "Appetite", "Psychomotor"]
COGNITIVE_ITEMS = ["Anhedonia", "Depressed Mood", "Guilt", "Concentration", "Suicidality"]

# Severity threshold
SEVERITY_THRESHOLD = 5

# =============================================================================
# COMPOSITIONAL DATA TRANSFORMATIONS
# =============================================================================

def clr_transform(X: np.ndarray, eps: float = 1e-10) -> np.ndarray:
    """
    Centered Log-Ratio (CLR) transformation for compositional data.
    
    The CLR is the natural transformation for data on the simplex,
    mapping from the (D-1)-simplex to R^D while preserving relative structure.
    
    CLR(x)_j = log(x_j) - (1/D) * sum_k(log(x_k))
    
    Args:
        X: Compositional data (N x D), rows sum to 1
        eps: Small constant to handle zeros
    
    Returns:
        X_clr: CLR-transformed data (N x D)
    """
    X_pos = X + eps  # Handle zeros
    log_X = np.log(X_pos)
    geometric_mean = np.mean(log_X, axis=1, keepdims=True)
    return log_X - geometric_mean


def ilr_transform(X: np.ndarray, eps: float = 1e-10) -> np.ndarray:
    """
    Isometric Log-Ratio (ILR) transformation for compositional data.
    
    Maps from the (D-1)-simplex to R^(D-1) using an orthonormal basis.
    Unlike CLR, ILR coordinates are unconstrained and suitable for
    standard multivariate methods.
    
    Args:
        X: Compositional data (N x D), rows sum to 1
        eps: Small constant to handle zeros
    
    Returns:
        X_ilr: ILR-transformed data (N x D-1)
    """
    n, D = X.shape
    X_pos = X + eps
    
    # Helmert subcomposition basis
    ilr_coords = np.zeros((n, D-1))
    for i in range(D-1):
        # ILR coordinate i contrasts components 0:i+1 vs component i+1
        ilr_coords[:, i] = np.sqrt((i+1)/(i+2)) * (
            (1/(i+1)) * np.sum(np.log(X_pos[:, :i+1]), axis=1) - np.log(X_pos[:, i+1])
        )
    return ilr_coords


def compute_somatic_cognitive_index(attention: np.ndarray) -> np.ndarray:
    """
    Compute the Somatic-Cognitive Index (SCI) for each individual.
    
    SCI = log(sum(somatic weights) / sum(cognitive weights))
    
    Interpretation:
        SCI > 0: Somatic-dominant measurement
        SCI ≈ 0: Balanced measurement
        SCI < 0: Cognitive-dominant measurement
    
    This is a log-ratio, which is the natural metric on the simplex.
    
    Args:
        attention: Attention weight matrix (N x 9)
    
    Returns:
        sci: Somatic-Cognitive Index (N,)
    """
    somatic_idx = [ITEM_LABELS.index(s) for s in SOMATIC_ITEMS]
    cognitive_idx = [ITEM_LABELS.index(s) for s in COGNITIVE_ITEMS]
    
    somatic_weight = attention[:, somatic_idx].sum(axis=1)
    cognitive_weight = attention[:, cognitive_idx].sum(axis=1)
    
    # Log-ratio with small constant for numerical stability
    eps = 1e-10
    sci = np.log((somatic_weight + eps) / (cognitive_weight + eps))
    
    return sci


def compute_attention_entropy(attention: np.ndarray) -> np.ndarray:
    """
    Compute normalized entropy of attention distribution for each individual.
    
    Entropy measures how concentrated vs. diffuse attention is:
        H = 1: Uniform attention (measurement invariance)
        H → 0: Concentrated on single item
    
    Args:
        attention: Attention weight matrix (N x p)
    
    Returns:
        entropy: Normalized entropy (N,), range [0, 1]
    """
    eps = 1e-10
    p = attention.shape[1]
    
    # Raw entropy
    entropy = -np.sum(attention * np.log(attention + eps), axis=1)
    
    # Normalize by maximum entropy
    max_entropy = np.log(p)
    normalized_entropy = entropy / max_entropy
    
    return normalized_entropy


# =============================================================================
# DATA LOADING AND PREPROCESSING
# =============================================================================

def load_and_filter_data(filepath: Path, threshold: int = 5) -> tuple:
    """
    Load PHQ-9 data and filter to symptomatic sample.
    """
    if not filepath.exists():
        raise FileNotFoundError(f"Data file not found: {filepath}")
    
    print("=" * 70)
    print("DATA LOADING AND PREPROCESSING")
    print("=" * 70)
    
    # Load full dataset
    df_full = pd.read_csv(filepath)
    X_full = df_full[PHQ9_ITEMS].values.astype(np.float32)
    
    # --- Full Sample Diagnostics ---
    print(f"\nFull Sample: N = {len(df_full)}")
    print(f"  PHQ-9 mean: {df_full['PHQ9_total'].mean():.2f} (SD = {df_full['PHQ9_total'].std():.2f})")
    
    zero_total = (df_full['PHQ9_total'] == 0).mean()
    below_threshold = (df_full['PHQ9_total'] < threshold).mean()
    flat_responders = (X_full.var(axis=1) == 0).mean()
    low_variance = (X_full.var(axis=1) < 0.5).mean()
    
    print(f"\n  ⚠ Zero total score: {zero_total:.1%}")
    print(f"  ⚠ Below threshold (<{threshold}): {below_threshold:.1%}")
    print(f"  ⚠ Flat responders (var=0): {flat_responders:.1%}")
    print(f"  ⚠ Low variance (<0.5): {low_variance:.1%}")
    
    full_sample_stats = {
        'n_total': len(df_full),
        'zero_total_pct': zero_total,
        'below_threshold_pct': below_threshold,
        'flat_responders_pct': flat_responders,
        'low_variance_pct': low_variance
    }
    
    # --- Filter to Symptomatic Sample ---
    print(f"\n{'─' * 70}")
    print(f"Filtering to PHQ-9 ≥ {threshold} (symptomatic sample)")
    print(f"{'─' * 70}")
    
    symptomatic_mask = df_full['PHQ9_total'] >= threshold
    df = df_full[symptomatic_mask].copy().reset_index(drop=True)
    X = X_full[symptomatic_mask]
    
    print(f"\nSymptomatic Sample: N = {len(df)} ({len(df)/len(df_full):.1%} of total)")
    print(f"  PHQ-9 mean: {df['PHQ9_total'].mean():.2f} (SD = {df['PHQ9_total'].std():.2f})")
    print(f"  PHQ-9 range: {df['PHQ9_total'].min()} - {df['PHQ9_total'].max()}")
    
    # Post-filter diagnostics
    var_per_person = X.var(axis=1)
    print(f"\n  Response variance per person: {var_per_person.mean():.2f} (SD = {var_per_person.std():.2f})")
    print(f"  Remaining flat responders: {(var_per_person == 0).mean():.1%}")
    print(f"  Remaining low variance (<0.5): {(var_per_person < 0.5).mean():.1%}")
    
    # Severity distribution
    print(f"\n  Severity Distribution:")
    print(f"    Mild (5-9):       {((df['PHQ9_total'] >= 5) & (df['PHQ9_total'] < 10)).sum():,} ({((df['PHQ9_total'] >= 5) & (df['PHQ9_total'] < 10)).mean():.1%})")
    print(f"    Moderate (10-14): {((df['PHQ9_total'] >= 10) & (df['PHQ9_total'] < 15)).sum():,} ({((df['PHQ9_total'] >= 10) & (df['PHQ9_total'] < 15)).mean():.1%})")
    print(f"    Mod-Severe (15-19): {((df['PHQ9_total'] >= 15) & (df['PHQ9_total'] < 20)).sum():,} ({((df['PHQ9_total'] >= 15) & (df['PHQ9_total'] < 20)).mean():.1%})")
    print(f"    Severe (20+):     {(df['PHQ9_total'] >= 20).sum():,} ({(df['PHQ9_total'] >= 20).mean():.1%})")
    
    return df, X, full_sample_stats


# =============================================================================
# CFASA TRAINING
# =============================================================================

def train_cfasa(X: np.ndarray, alpha: float = 0.5) -> tuple:
    """
    Train CFASA in self-consistency mode on symptomatic sample.
    """
    print("\n" + "=" * 70)
    print("CFASA TRAINING (Self-Consistency Mode)")
    print("=" * 70)
    
    print(f"\nConfiguration:")
    print(f"  Items: {X.shape[1]}")
    print(f"  Sample size: {X.shape[0]}")
    print(f"  Alpha (tempering): {alpha}")
    
    trainer = CFASATrainer(
        n_items=9,
        n_attention_heads=3,
        hidden_dim=128,
        mode='self_consistency',
        alpha_tempering=alpha
    )
    
    trainer.train(
        X,
        learning_rate=0.002,
        n_epochs=200,
        batch_size=256
    )
    
    # Extract attention patterns
    print("\nExtracting attention patterns...")
    preds = trainer.predict_attention_patterns(X)
    attention = preds['attention_weights']
    
    # Compute diversity
    diversity_results = compute_attention_diversity(attention)
    
    print(f"\n{'─' * 70}")
    print("ATTENTION DIVERSITY RESULTS")
    print(f"{'─' * 70}")
    print(f"  Global Diversity Index: {diversity_results['diversity_index']:.3f}")
    print(f"  Interpretation: ", end="")
    
    di = diversity_results['diversity_index']
    if di < 0.05:
        print("Near-uniform attention (strong measurement invariance)")
    elif di < 0.10:
        print("Low diversity (moderate measurement invariance)")
    elif di < 0.20:
        print("Moderate diversity (individual differences present)")
    else:
        print("High diversity (substantial individual differences)")
    
    return trainer, attention, diversity_results


# =============================================================================
# CONTINUOUS HETEROGENEITY ANALYSIS
# =============================================================================

def analyze_continuous_heterogeneity(attention: np.ndarray, df: pd.DataFrame) -> dict:
    """
    Analyze attention heterogeneity using simplex-appropriate methods.
    
    This replaces K-Means clustering with:
    1. Somatic-Cognitive Index (SCI) - primary continuous measure
    2. Attention Entropy - concentration measure
    3. Compositional PCA - dimensionality reduction
    4. Regression analysis - demographic associations
    
    Args:
        attention: Attention weight matrix (N x 9)
        df: DataFrame with demographic variables
    
    Returns:
        results: Dict containing all continuous measures and models
    """
    print("\n" + "=" * 70)
    print("CONTINUOUS HETEROGENEITY ANALYSIS")
    print("=" * 70)
    
    df = df.copy()
    
    # --- 1. Somatic-Cognitive Index ---
    print("\n" + "─" * 70)
    print("1. SOMATIC-COGNITIVE INDEX (SCI)")
    print("─" * 70)
    
    sci = compute_somatic_cognitive_index(attention)
    df['SCI'] = sci
    
    print(f"\n  SCI = log(Σ Somatic / Σ Cognitive)")
    print(f"    > 0: Somatic-dominant measurement")
    print(f"    ≈ 0: Balanced measurement")
    print(f"    < 0: Cognitive-dominant measurement")
    print(f"\n  Distribution:")
    print(f"    Mean:   {sci.mean():.3f}")
    print(f"    SD:     {sci.std():.3f}")
    print(f"    Range:  [{sci.min():.3f}, {sci.max():.3f}]")
    print(f"    Median: {np.median(sci):.3f}")
    print(f"    IQR:    [{np.percentile(sci, 25):.3f}, {np.percentile(sci, 75):.3f}]")
    
    # --- 2. Attention Entropy ---
    print("\n" + "─" * 70)
    print("2. ATTENTION ENTROPY")
    print("─" * 70)
    
    entropy = compute_attention_entropy(attention)
    df['Entropy'] = entropy
    
    print(f"\n  Normalized entropy (1.0 = uniform, 0 = concentrated)")
    print(f"    Mean:   {entropy.mean():.3f}")
    print(f"    SD:     {entropy.std():.3f}")
    print(f"    Range:  [{entropy.min():.3f}, {entropy.max():.3f}]")
    
    # --- 3. Compositional PCA ---
    print("\n" + "─" * 70)
    print("3. COMPOSITIONAL PCA (CLR-transformed)")
    print("─" * 70)
    
    from sklearn.decomposition import PCA
    
    # CLR transform
    attention_clr = clr_transform(attention)
    
    # PCA
    pca = PCA(n_components=3)
    pca_coords = pca.fit_transform(attention_clr)
    
    df['PC1'] = pca_coords[:, 0]
    df['PC2'] = pca_coords[:, 1]
    df['PC3'] = pca_coords[:, 2]
    
    print(f"\n  Variance explained:")
    for i, var in enumerate(pca.explained_variance_ratio_):
        print(f"    PC{i+1}: {var:.1%}")
    print(f"    Total (PC1-3): {pca.explained_variance_ratio_[:3].sum():.1%}")
    
    # Interpret PC loadings
    print(f"\n  PC1 loadings (dominant dimension):")
    loadings = pca.components_[0]
    sorted_idx = np.argsort(np.abs(loadings))[::-1]
    for idx in sorted_idx[:5]:
        print(f"    {ITEM_LABELS[idx]:20s}: {loadings[idx]:+.3f}")
    
    # Correlation between SCI and PC1
    sci_pc1_corr = np.corrcoef(sci, pca_coords[:, 0])[0, 1]
    print(f"\n  Correlation SCI ↔ PC1: r = {sci_pc1_corr:.3f}")
    
    # --- 4. Prepare Demographics ---
    print("\n" + "─" * 70)
    print("4. DEMOGRAPHIC ASSOCIATIONS (Regression)")
    print("─" * 70)
    
    # Gender encoding
    if df['RIAGENDR'].dtype == 'object':
        df['Gender'] = df['RIAGENDR']
    else:
        df['Gender'] = df['RIAGENDR'].map({1: 'Male', 2: 'Female'})
    
    df['Female'] = (df['Gender'] == 'Female').astype(int)
    
    # Age (centered for interpretation)
    df['Age_centered'] = df['RIDAGEYR'] - df['RIDAGEYR'].mean()
    
    # Severity (centered)
    df['Severity_centered'] = df['PHQ9_total'] - df['PHQ9_total'].mean()
    
    # --- 5. Regression: SCI ~ Severity + Age + Gender ---
    try:
        import statsmodels.api as sm
        
        X_reg = df[['Severity_centered', 'Age_centered', 'Female']].copy()
        X_reg = sm.add_constant(X_reg)
        
        model_sci = sm.OLS(df['SCI'], X_reg).fit()
        
        print(f"\n  Model: SCI ~ Severity + Age + Gender")
        print(f"  R² = {model_sci.rsquared:.3f}")
        print(f"\n  Coefficients:")
        print(f"    {'Variable':<20s} {'β':>8s} {'SE':>8s} {'t':>8s} {'p':>10s}")
        print(f"    {'-'*56}")
        for var in ['const', 'Severity_centered', 'Age_centered', 'Female']:
            coef = model_sci.params[var]
            se = model_sci.bse[var]
            t = model_sci.tvalues[var]
            p = model_sci.pvalues[var]
            sig = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else ''
            print(f"    {var:<20s} {coef:>8.4f} {se:>8.4f} {t:>8.2f} {p:>9.4f} {sig}")
        
        # Interpretation
        print(f"\n  Interpretation:")
        sev_coef = model_sci.params['Severity_centered']
        age_coef = model_sci.params['Age_centered']
        
        if model_sci.pvalues['Severity_centered'] < 0.05:
            direction = "more somatic-focused" if sev_coef > 0 else "more balanced"
            print(f"    • Severity: Higher severity → {direction} measurement")
        
        if model_sci.pvalues['Age_centered'] < 0.05:
            direction = "more somatic-focused" if age_coef > 0 else "more cognitive-focused"
            print(f"    • Age: Older adults → {direction} measurement")
        
        if model_sci.pvalues['Female'] < 0.05:
            direction = "more somatic-focused" if model_sci.params['Female'] > 0 else "more cognitive-focused"
            print(f"    • Gender: Females → {direction} measurement")
        else:
            print(f"    • Gender: No significant difference (measurement invariance)")
            
    except ImportError:
        print("\n  [statsmodels not available - using scipy for basic regression]")
        model_sci = None
        
        # Basic correlation analysis
        print(f"\n  Correlations with SCI:")
        r_sev, p_sev = stats.pearsonr(df['PHQ9_total'], sci)
        r_age, p_age = stats.pearsonr(df['RIDAGEYR'], sci)
        print(f"    Severity: r = {r_sev:.3f}, p = {p_sev:.4f}")
        print(f"    Age:      r = {r_age:.3f}, p = {p_age:.4f}")
        
        # Gender t-test
        sci_male = sci[df['Female'] == 0]
        sci_female = sci[df['Female'] == 1]
        t_stat, p_gender = stats.ttest_ind(sci_male, sci_female)
        print(f"    Gender:   t = {t_stat:.3f}, p = {p_gender:.4f}")
    
    # --- 6. Regression: Entropy ~ Severity + Age + Gender ---
    print(f"\n  Model: Entropy ~ Severity + Age + Gender")
    
    try:
        model_entropy = sm.OLS(df['Entropy'], X_reg).fit()
        
        print(f"  R² = {model_entropy.rsquared:.3f}")
        print(f"\n  Coefficients:")
        print(f"    {'Variable':<20s} {'β':>8s} {'SE':>8s} {'t':>8s} {'p':>10s}")
        print(f"    {'-'*56}")
        for var in ['const', 'Severity_centered', 'Age_centered', 'Female']:
            coef = model_entropy.params[var]
            se = model_entropy.bse[var]
            t = model_entropy.tvalues[var]
            p = model_entropy.pvalues[var]
            sig = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else ''
            print(f"    {var:<20s} {coef:>8.4f} {se:>8.4f} {t:>8.2f} {p:>9.4f} {sig}")
            
    except:
        model_entropy = None
    
    # --- 7. Heuristic Personas (for interpretability) ---
    print("\n" + "─" * 70)
    print("5. HEURISTIC PERSONAS (for interpretability)")
    print("─" * 70)
    print("\n  Note: These categories are pedagogical simplifications.")
    print("  The underlying heterogeneity is continuous.")
    
    # Define categories based on SCI thresholds
    df['Persona_Heuristic'] = pd.cut(
        df['SCI'],
        bins=[-np.inf, -0.3, 0.3, np.inf],
        labels=['Cognitive-Focused', 'Balanced', 'Somatic-Focused']
    )
    
    # Count
    persona_counts = df['Persona_Heuristic'].value_counts()
    print(f"\n  SCI-based categories:")
    for persona in ['Somatic-Focused', 'Balanced', 'Cognitive-Focused']:
        if persona in persona_counts.index:
            n = persona_counts[persona]
            pct = n / len(df)
            mean_sci = df.loc[df['Persona_Heuristic'] == persona, 'SCI'].mean()
            mean_sev = df.loc[df['Persona_Heuristic'] == persona, 'PHQ9_total'].mean()
            print(f"    {persona:<20s}: N={n:4d} ({pct:5.1%}), mean SCI={mean_sci:+.2f}, mean PHQ-9={mean_sev:.1f}")
    
    results = {
        'df': df,
        'sci': sci,
        'entropy': entropy,
        'pca': pca,
        'pca_coords': pca_coords,
        'attention_clr': attention_clr,
        'model_sci': model_sci if 'model_sci' in dir() else None,
        'model_entropy': model_entropy if 'model_entropy' in dir() else None
    }
    
    return results
    

# =============================================================================
# VISUALIZATION
# =============================================================================

def create_multipanel_figure(attention: np.ndarray, results: dict,
                              output_dir: Path = Path(".")):
    """
    Generate unified 3-row multi-panel figure for manuscript.
    
    Layout:
        Row 1: Compositional PCA by SCI (left) + Entropy vs SCI (right)
        Row 2: SCI histogram (left) + SCI vs Severity scatter (right)
        Row 3: Attention profiles by SCI tertiles (bar chart)
    """
    print("\n" + "=" * 70)
    print("GENERATING MULTI-PANEL MANUSCRIPT FIGURE")
    print("=" * 70)
    
    df = results['df']
    sci = results['sci']
    entropy = results['entropy']
    pca_coords = results['pca_coords']
    
    # Custom colormap for SCI (blue-white-red)
    from matplotlib.colors import LinearSegmentedColormap
    cmap_sci = LinearSegmentedColormap.from_list('sci', ['#2166ac', '#f7f7f7', '#b2182b'])
    
    # Create figure with GridSpec for flexible layout
    fig = plt.figure(figsize=(14, 16))
    gs = fig.add_gridspec(3, 2, height_ratios=[1, 1, 1.2], 
                          hspace=0.28, wspace=0.25)
    
    # =========================================================================
    # ROW 1 LEFT: Compositional PCA colored by SCI
    # =========================================================================
    ax1a = fig.add_subplot(gs[0, 0])
    
    scatter1a = ax1a.scatter(pca_coords[:, 0], pca_coords[:, 1], c=sci, 
                             cmap=cmap_sci, alpha=0.5, s=30, vmin=-1, vmax=1)
    ax1a.set_xlabel(f"PC1 ({results['pca'].explained_variance_ratio_[0]:.1%} var)", fontsize=12)
    ax1a.set_ylabel(f"PC2 ({results['pca'].explained_variance_ratio_[1]:.1%} var)", fontsize=12)
    ax1a.set_title('A. Compositional PCA (by Emphasis)', fontsize=14, fontweight='bold')
    ax1a.axhline(y=0, color='gray', linestyle='--', alpha=0.3)
    ax1a.axvline(x=0, color='gray', linestyle='--', alpha=0.3)
    plt.colorbar(scatter1a, ax=ax1a, label='SCI')
    
    # =========================================================================
    # ROW 1 RIGHT: Entropy vs SCI (colored by Severity)
    # =========================================================================
    ax1b = fig.add_subplot(gs[0, 1])
    
    scatter1b = ax1b.scatter(sci, entropy, c=df['PHQ9_total'], cmap='plasma', 
                             alpha=0.5, s=30)
    ax1b.set_xlabel('Somatic-Cognitive Index', fontsize=12)
    ax1b.set_ylabel('Attention Entropy (1 = uniform)', fontsize=12)
    ax1b.set_title('B. Measurement Concentration vs Emphasis', fontsize=14, fontweight='bold')
    ax1b.axvline(x=0, color='gray', linestyle='--', alpha=0.5)
    plt.colorbar(scatter1b, ax=ax1b, label='PHQ-9 Severity')
    
    # Add correlation annotation
    r_ent_sci = np.corrcoef(sci, entropy)[0, 1]
    ax1b.annotate(f'r = {r_ent_sci:.3f}', xy=(0.95, 0.95), xycoords='axes fraction',
                  ha='right', va='top', fontsize=11, 
                  bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # =========================================================================
    # ROW 2 LEFT: SCI Distribution Histogram
    # =========================================================================
    ax2a = fig.add_subplot(gs[1, 0])
    
    ax2a.hist(sci, bins=50, density=True, alpha=0.7, color='steelblue', edgecolor='black')
    ax2a.axvline(x=0, color='black', linestyle='--', linewidth=2, label='Balanced')
    ax2a.axvline(x=sci.mean(), color='red', linestyle='-', linewidth=2, label=f'Mean={sci.mean():.2f}')
    ax2a.set_xlabel('Somatic-Cognitive Index (SCI)', fontsize=12)
    ax2a.set_ylabel('Density', fontsize=12)
    ax2a.set_title('C. Distribution of Measurement Emphasis', fontsize=14, fontweight='bold')
    ax2a.legend(fontsize=9)
    
    # Add annotations
    ylim = ax2a.get_ylim()
    ax2a.annotate('Somatic\nDominant', xy=(0.8, ylim[1]*0.75), fontsize=10, ha='center')
    ax2a.annotate('Cognitive\nDominant', xy=(-0.7, ylim[1]*0.75), fontsize=10, ha='center')
    
    # =========================================================================
    # ROW 2 RIGHT: SCI vs Severity (colored by Age)
    # =========================================================================
    ax2b = fig.add_subplot(gs[1, 1])
    
    scatter2b = ax2b.scatter(df['PHQ9_total'], sci, c=df['RIDAGEYR'], 
                             cmap='viridis', alpha=0.5, s=30)
    ax2b.axhline(y=0, color='black', linestyle='--', alpha=0.5)
    
    # Add regression line
    z = np.polyfit(df['PHQ9_total'], sci, 1)
    p = np.poly1d(z)
    x_line = np.linspace(df['PHQ9_total'].min(), df['PHQ9_total'].max(), 100)
    ax2b.plot(x_line, p(x_line), 'r-', linewidth=2, label=f'Trend (slope={z[0]:.3f})')
    
    ax2b.set_xlabel('PHQ-9 Severity', fontsize=12)
    ax2b.set_ylabel('Somatic-Cognitive Index', fontsize=12)
    ax2b.set_title('D. Measurement Structure by Severity', fontsize=14, fontweight='bold')
    plt.colorbar(scatter2b, ax=ax2b, label='Age')
    ax2b.legend(loc='upper right', fontsize=9)
    
    # =========================================================================
    # ROW 3: Attention Profiles by SCI Tertiles (spans both columns)
    # =========================================================================
    ax3 = fig.add_subplot(gs[2, :])  # Span both columns
    
    # Split by SCI tertiles
    sci_tertiles = pd.qcut(sci, q=3, labels=['Cognitive-Leaning', 'Balanced', 'Somatic-Leaning'])
    
    x = np.arange(9)
    width = 0.25
    colors_tertile = ['#3498db', '#95a5a6', '#e74c3c']  # Blue, Gray, Red
    
    for i, (tertile, color) in enumerate(zip(['Cognitive-Leaning', 'Balanced', 'Somatic-Leaning'], colors_tertile)):
        mask = sci_tertiles == tertile
        means = attention[mask].mean(axis=0)
        stds = attention[mask].std(axis=0)
        
        offset = (i - 1) * width
        ax3.bar(x + offset, means, width, label=tertile, color=color, 
               edgecolor='black', linewidth=0.5, alpha=0.8)
        ax3.errorbar(x + offset, means, yerr=stds/np.sqrt(mask.sum())*1.96, 
                    fmt='none', color='black', capsize=2)
    
    ax3.axhline(y=1/9, color='gray', linestyle='--', alpha=0.5, label='Uniform')
    ax3.set_xlabel('PHQ-9 Symptom', fontsize=12)
    ax3.set_ylabel('Attention Weight', fontsize=12)
    ax3.set_title('E. Attention Profiles by Measurement Emphasis (SCI Tertiles)', fontsize=14, fontweight='bold')
    ax3.set_xticks(x)
    ax3.set_xticklabels(ITEM_LABELS, rotation=45, ha='right')
    ax3.legend(loc='upper right')
    ax3.set_ylim(0, 0.35)
    
    # =========================================================================
    # Save figure
    # =========================================================================
    plt.savefig(output_dir / 'phq9_multipanel_figure.png', dpi=300, bbox_inches='tight')
    plt.savefig(output_dir / 'phq9_multipanel_figure.pdf', bbox_inches='tight')
    plt.savefig(output_dir / 'phq9_multipanel_figure.svg', bbox_inches='tight')
    print(f"  Saved: phq9_multipanel_figure.png/pdf/svg")
    plt.close()
    
    return fig


def create_visualizations(attention: np.ndarray, results: dict, 
                          output_dir: Path = Path(".")):
    """
    Generate publication-quality figures for continuous heterogeneity analysis.
    """
    print("\n" + "=" * 70)
    print("GENERATING VISUALIZATIONS")
    print("=" * 70)
    
    df = results['df']
    sci = results['sci']
    entropy = results['entropy']
    pca_coords = results['pca_coords']
    
    # Color scheme
    cmap = plt.cm.RdYlBu_r  # Red = somatic, Blue = cognitive
    
    # --- Figure 1: SCI Distribution ---
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    # 1a: Histogram
    ax = axes[0]
    ax.hist(sci, bins=50, density=True, alpha=0.7, color='steelblue', edgecolor='black')
    ax.axvline(x=0, color='black', linestyle='--', linewidth=2, label='Balanced')
    ax.axvline(x=sci.mean(), color='red', linestyle='-', linewidth=2, label=f'Mean={sci.mean():.2f}')
    ax.set_xlabel('Somatic-Cognitive Index (SCI)', fontsize=12)
    ax.set_ylabel('Density', fontsize=12)
    ax.set_title('Distribution of Measurement Emphasis', fontsize=14)
    ax.legend()
    
    # Add annotations
    ax.annotate('Somatic\nDominant', xy=(1.0, ax.get_ylim()[1]*0.8), fontsize=10, ha='center')
    ax.annotate('Cognitive\nDominant', xy=(-0.8, ax.get_ylim()[1]*0.8), fontsize=10, ha='center')
    
    # 1b: SCI vs Severity
    ax = axes[1]
    scatter = ax.scatter(df['PHQ9_total'], sci, c=df['RIDAGEYR'], 
                         cmap='viridis', alpha=0.5, s=30)
    ax.axhline(y=0, color='black', linestyle='--', alpha=0.5)
    
    # Add regression line
    z = np.polyfit(df['PHQ9_total'], sci, 1)
    p = np.poly1d(z)
    x_line = np.linspace(df['PHQ9_total'].min(), df['PHQ9_total'].max(), 100)
    ax.plot(x_line, p(x_line), 'r-', linewidth=2, label=f'Trend (slope={z[0]:.3f})')
    
    ax.set_xlabel('PHQ-9 Severity', fontsize=12)
    ax.set_ylabel('Somatic-Cognitive Index', fontsize=12)
    ax.set_title('Measurement Structure by Severity', fontsize=14)
    plt.colorbar(scatter, ax=ax, label='Age')
    ax.legend(loc='upper right')
    
    plt.tight_layout()
    plt.savefig(output_dir / 'phq9_sci_distribution.png', dpi=150)
    plt.savefig(output_dir / 'phq9_sci_distribution.pdf')
    print(f"  Saved: phq9_sci_distribution.png/pdf")
    plt.close()
    
    # --- Figure 2: SCI by Severity Bands ---
    fig, ax = plt.subplots(figsize=(10, 6))
    
    severity_bands = ['Mild\n(5-9)', 'Moderate\n(10-14)', 'Mod-Severe\n(15-19)', 'Severe\n(20+)']
    severity_masks = [
        (df['PHQ9_total'] >= 5) & (df['PHQ9_total'] < 10),
        (df['PHQ9_total'] >= 10) & (df['PHQ9_total'] < 15),
        (df['PHQ9_total'] >= 15) & (df['PHQ9_total'] < 20),
        df['PHQ9_total'] >= 20
    ]
    
    positions = range(len(severity_bands))
    bp_data = [sci[mask] for mask in severity_masks]
    
    bp = ax.boxplot(bp_data, positions=positions, widths=0.6, patch_artist=True)
    
    # Color boxes by median SCI
    colors = [cmap((np.median(d) + 1) / 2) for d in bp_data]  # Normalize to [0,1]
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    
    ax.axhline(y=0, color='black', linestyle='--', alpha=0.5, label='Balanced')
    ax.set_xticks(positions)
    ax.set_xticklabels(severity_bands)
    ax.set_xlabel('Depression Severity', fontsize=12)
    ax.set_ylabel('Somatic-Cognitive Index', fontsize=12)
    ax.set_title('Measurement Emphasis Shifts with Severity', fontsize=14)
    
    # Add N labels
    for i, (mask, band) in enumerate(zip(severity_masks, severity_bands)):
        n = mask.sum()
        ax.annotate(f'N={n}', xy=(i, ax.get_ylim()[1]), ha='center', fontsize=9)
    
    plt.tight_layout()
    plt.savefig(output_dir / 'phq9_sci_by_severity.png', dpi=150)
    plt.savefig(output_dir / 'phq9_sci_by_severity.pdf')
    print(f"  Saved: phq9_sci_by_severity.png/pdf")
    plt.close()
    
    # --- Figure 3: Compositional PCA ---
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # 3a: PC1 vs PC2, colored by SCI
    ax = axes[0]
    scatter = ax.scatter(pca_coords[:, 0], pca_coords[:, 1], c=sci, 
                         cmap=cmap, alpha=0.5, s=30, vmin=-1, vmax=1)
    ax.set_xlabel(f"PC1 ({results['pca'].explained_variance_ratio_[0]:.1%} var)", fontsize=12)
    ax.set_ylabel(f"PC2 ({results['pca'].explained_variance_ratio_[1]:.1%} var)", fontsize=12)
    ax.set_title('Compositional PCA of Attention Patterns', fontsize=14)
    ax.axhline(y=0, color='gray', linestyle='--', alpha=0.3)
    ax.axvline(x=0, color='gray', linestyle='--', alpha=0.3)
    plt.colorbar(scatter, ax=ax, label='SCI')
    
    # 3b: PC1 vs PC2, colored by Severity
    ax = axes[1]
    scatter = ax.scatter(pca_coords[:, 0], pca_coords[:, 1], c=df['PHQ9_total'], 
                         cmap='plasma', alpha=0.5, s=30)
    ax.set_xlabel(f"PC1 ({results['pca'].explained_variance_ratio_[0]:.1%} var)", fontsize=12)
    ax.set_ylabel(f"PC2 ({results['pca'].explained_variance_ratio_[1]:.1%} var)", fontsize=12)
    ax.set_title('Attention Structure by Depression Severity', fontsize=14)
    ax.axhline(y=0, color='gray', linestyle='--', alpha=0.3)
    ax.axvline(x=0, color='gray', linestyle='--', alpha=0.3)
    plt.colorbar(scatter, ax=ax, label='PHQ-9')
    
    plt.tight_layout()
    plt.savefig(output_dir / 'phq9_compositional_pca.png', dpi=150)
    plt.savefig(output_dir / 'phq9_compositional_pca.pdf')
    print(f"  Saved: phq9_compositional_pca.png/pdf")
    plt.close()
    
    # --- Figure 4: Item-Level Attention by SCI Tertiles ---
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # Split by SCI tertiles
    sci_tertiles = pd.qcut(sci, q=3, labels=['Cognitive-Leaning', 'Balanced', 'Somatic-Leaning'])
    
    x = np.arange(9)
    width = 0.25
    colors_tertile = ['#3498db', '#95a5a6', '#e74c3c']  # Blue, Gray, Red
    
    for i, (tertile, color) in enumerate(zip(['Cognitive-Leaning', 'Balanced', 'Somatic-Leaning'], colors_tertile)):
        mask = sci_tertiles == tertile
        means = attention[mask].mean(axis=0)
        stds = attention[mask].std(axis=0)
        
        offset = (i - 1) * width
        ax.bar(x + offset, means, width, label=tertile, color=color, 
               edgecolor='black', linewidth=0.5, alpha=0.8)
        ax.errorbar(x + offset, means, yerr=stds/np.sqrt(mask.sum())*1.96, 
                    fmt='none', color='black', capsize=2)
    
    ax.axhline(y=1/9, color='gray', linestyle='--', alpha=0.5, label='Uniform')
    ax.set_xlabel('PHQ-9 Symptom', fontsize=12)
    ax.set_ylabel('Attention Weight', fontsize=12)
    ax.set_title('Attention Profiles by Measurement Emphasis (SCI Tertiles)', fontsize=14)
    ax.set_xticks(x)
    ax.set_xticklabels(ITEM_LABELS, rotation=45, ha='right')
    ax.legend(loc='upper right')
    ax.set_ylim(0, 0.35)
    
    plt.tight_layout()
    plt.savefig(output_dir / 'phq9_attention_by_sci_tertiles.png', dpi=150)
    plt.savefig(output_dir / 'phq9_attention_by_sci_tertiles.pdf')
    print(f"  Saved: phq9_attention_by_sci_tertiles.png/pdf")
    plt.close()
    
    # --- Figure 5: Entropy vs SCI ---
    fig, ax = plt.subplots(figsize=(8, 6))
    
    scatter = ax.scatter(sci, entropy, c=df['PHQ9_total'], cmap='plasma', alpha=0.5, s=30)
    ax.set_xlabel('Somatic-Cognitive Index', fontsize=12)
    ax.set_ylabel('Attention Entropy (1 = uniform)', fontsize=12)
    ax.set_title('Measurement Concentration vs Emphasis', fontsize=14)
    ax.axvline(x=0, color='gray', linestyle='--', alpha=0.5)
    plt.colorbar(scatter, ax=ax, label='PHQ-9 Severity')
    
    plt.tight_layout()
    plt.savefig(output_dir / 'phq9_entropy_vs_sci.png', dpi=150)
    plt.savefig(output_dir / 'phq9_entropy_vs_sci.pdf')
    print(f"  Saved: phq9_entropy_vs_sci.png/pdf")
    plt.close()
    
    # --- Figure 6: Age Effect ---
    fig, ax = plt.subplots(figsize=(8, 6))
    
    ax.scatter(df['RIDAGEYR'], sci, alpha=0.3, s=20, color='steelblue')
    
    # Add LOESS or polynomial fit
    z = np.polyfit(df['RIDAGEYR'], sci, 2)
    p = np.poly1d(z)
    x_line = np.linspace(df['RIDAGEYR'].min(), df['RIDAGEYR'].max(), 100)
    ax.plot(x_line, p(x_line), 'r-', linewidth=2, label='Quadratic fit')
    
    ax.axhline(y=0, color='black', linestyle='--', alpha=0.5)
    ax.set_xlabel('Age', fontsize=12)
    ax.set_ylabel('Somatic-Cognitive Index', fontsize=12)
    ax.set_title('Measurement Emphasis by Age', fontsize=14)
    ax.legend()
    
    plt.tight_layout()
    plt.savefig(output_dir / 'phq9_sci_by_age.png', dpi=150)
    plt.savefig(output_dir / 'phq9_sci_by_age.pdf')
    print(f"  Saved: phq9_sci_by_age.png/pdf")
    plt.close()


# =============================================================================
# EXPORT RESULTS
# =============================================================================

def export_results(attention: np.ndarray, results: dict, output_dir: Path = Path(".")):
    """Export analysis results for further use."""
    
    print("\n" + "=" * 70)
    print("EXPORTING RESULTS")
    print("=" * 70)
    
    df = results['df']
    
    # Add attention weights to dataframe
    for i, label in enumerate(ITEM_LABELS):
        df[f'Att_{label}'] = attention[:, i]
    
    # Select columns for export
    export_cols = ['SEQN', 'RIDAGEYR', 'RIAGENDR', 'PHQ9_total', 'Gender',
                   'SCI', 'Entropy', 'PC1', 'PC2', 'PC3', 'Persona_Heuristic']
    export_cols += [f'Att_{label}' for label in ITEM_LABELS]
    
    df[export_cols].to_csv(output_dir / 'cfasa_phq9_results_v5.csv', index=False)
    print(f"  Saved: cfasa_phq9_results_v5.csv")
    
    # Export summary statistics
    summary = {
        'N': len(df),
        'SCI_mean': results['sci'].mean(),
        'SCI_sd': results['sci'].std(),
        'Entropy_mean': results['entropy'].mean(),
        'Entropy_sd': results['entropy'].std(),
        'PC1_var_explained': results['pca'].explained_variance_ratio_[0],
        'PC2_var_explained': results['pca'].explained_variance_ratio_[1],
    }
    
    if results['model_sci'] is not None:
        summary['R2_SCI_model'] = results['model_sci'].rsquared
        summary['Severity_beta'] = results['model_sci'].params['Severity_centered']
        summary['Severity_p'] = results['model_sci'].pvalues['Severity_centered']
        summary['Age_beta'] = results['model_sci'].params['Age_centered']
        summary['Age_p'] = results['model_sci'].pvalues['Age_centered']
        summary['Female_beta'] = results['model_sci'].params['Female']
        summary['Female_p'] = results['model_sci'].pvalues['Female']
    
    pd.DataFrame([summary]).to_csv(output_dir / 'cfasa_phq9_summary_v5.csv', index=False)
    print(f"  Saved: cfasa_phq9_summary_v5.csv")


# =============================================================================
# MAIN ANALYSIS
# =============================================================================

def run_phq9_analysis(severity_threshold: int = 5):
    """
    Complete CFASA analysis of PHQ-9 depression measurement.
    
    Version 5: Continuous heterogeneity framework.
    """
    set_reproducible_state(RANDOM_SEED)
    
    print("\n" + "=" * 70)
    print("CFASA EMPIRICAL STUDY: PHQ-9 DEPRESSION MEASUREMENT")
    print("Version 5: Continuous Heterogeneity Framework")
    print("=" * 70)
    print(f"\nResearch Question:")
    print(f"  'Among individuals experiencing depression symptoms,")
    print(f"   do people differentially weight which symptoms define their depression?'")
    print(f"\nSample: NHANES 2017-2018, PHQ-9 ≥ {severity_threshold}")
    
    # 1. Load and filter data
    df, X, full_stats = load_and_filter_data(DATA_FILE, threshold=severity_threshold)
    
    # 2. Train CFASA
    trainer, attention, diversity = train_cfasa(X, alpha=0.5)
    
    # 3. Continuous heterogeneity analysis
    results = analyze_continuous_heterogeneity(attention, df)
    severity_table = compute_severity_stratified_table(results['df'], attention)
    print_severity_table(severity_table)
    
    # 4. Visualizations
    create_visualizations(attention, results)
    
    # 4b. Multi-panel manuscript figure
    create_multipanel_figure(attention, results)
    
    # 5. Export
    export_results(attention, results)
    
    # --- Summary ---
    print("\n" + "=" * 70)
    print("ANALYSIS COMPLETE")
    print("=" * 70)
    
    print(f"\nKey Findings:")
    print(f"  • Symptomatic sample: N = {len(df):,}")
    print(f"  • Attention Diversity Index: {diversity['diversity_index']:.3f}")
    print(f"  • Somatic-Cognitive Index: M = {results['sci'].mean():.3f}, SD = {results['sci'].std():.3f}")
    print(f"  • Attention Entropy: M = {results['entropy'].mean():.3f}, SD = {results['entropy'].std():.3f}")
    
    if results['model_sci'] is not None:
        print(f"\n  Regression (SCI ~ Severity + Age + Gender):")
        print(f"    • R² = {results['model_sci'].rsquared:.3f}")
        
        sev_p = results['model_sci'].pvalues['Severity_centered']
        age_p = results['model_sci'].pvalues['Age_centered']
        gen_p = results['model_sci'].pvalues['Female']
        
        print(f"    • Severity: β = {results['model_sci'].params['Severity_centered']:.4f}, p = {sev_p:.4f}")
        print(f"    • Age: β = {results['model_sci'].params['Age_centered']:.4f}, p = {age_p:.4f}")
        print(f"    • Gender: β = {results['model_sci'].params['Female']:.4f}, p = {gen_p:.4f}")
    
    return {
        'df': results['df'],
        'attention': attention,
        'diversity': diversity,
        'sci': results['sci'],
        'entropy': results['entropy'],
        'pca': results['pca'],
        'model_sci': results['model_sci'],
        'trainer': trainer
    }


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    results = run_phq9_analysis(severity_threshold=5)
