"""
Severity-Stratified Summary Table for CFASA PHQ-9 Analysis
===========================================================

Add this function to run_phq9_analysis_v5.py and call it in the main analysis.

This produces a reviewer-friendly table with:
- N per severity band
- Mean/SD for SCI
- Mean/SD for Entropy  
- Within-band Diversity Index
- Effect sizes (Cohen's d from mild)
"""

import numpy as np
import pandas as pd
from scipy import stats


def compute_severity_stratified_table(df: pd.DataFrame, attention: np.ndarray) -> pd.DataFrame:
    """
    Compute severity-stratified summary statistics for attention heterogeneity.
    
    This table directly supports regression findings and provides quotable
    numbers for reviewers.
    
    Args:
        df: DataFrame with SCI, Entropy, PHQ9_total columns
        attention: Attention weight matrix (N x 9) for within-band DI
    
    Returns:
        summary_df: DataFrame with one row per severity band
    """
    from cfasa_utils import compute_attention_diversity
    
    # Define severity bands
    severity_bands = [
        ('Mild (5-9)', (df['PHQ9_total'] >= 5) & (df['PHQ9_total'] < 10)),
        ('Moderate (10-14)', (df['PHQ9_total'] >= 10) & (df['PHQ9_total'] < 15)),
        ('Mod-Severe (15-19)', (df['PHQ9_total'] >= 15) & (df['PHQ9_total'] < 20)),
        ('Severe (20+)', df['PHQ9_total'] >= 20)
    ]
    
    results = []
    
    # Store mild group stats for effect size computation
    mild_mask = severity_bands[0][1]
    mild_sci_mean = df.loc[mild_mask, 'SCI'].mean()
    mild_sci_sd = df.loc[mild_mask, 'SCI'].std()
    mild_entropy_mean = df.loc[mild_mask, 'Entropy'].mean()
    mild_entropy_sd = df.loc[mild_mask, 'Entropy'].std()
    
    for band_name, mask in severity_bands:
        n = mask.sum()
        
        if n == 0:
            continue
        
        # SCI statistics
        sci_vals = df.loc[mask, 'SCI']
        sci_mean = sci_vals.mean()
        sci_sd = sci_vals.std()
        sci_median = sci_vals.median()
        sci_iqr_low = sci_vals.quantile(0.25)
        sci_iqr_high = sci_vals.quantile(0.75)
        
        # Entropy statistics
        entropy_vals = df.loc[mask, 'Entropy']
        entropy_mean = entropy_vals.mean()
        entropy_sd = entropy_vals.std()
        
        # Within-band Diversity Index
        attention_band = attention[mask.values]
        if len(attention_band) > 10:  # Need minimum sample for DI
            di_results = compute_attention_diversity(attention_band)
            di = di_results['diversity_index']
        else:
            di = np.nan
        
        # Effect sizes (Cohen's d relative to Mild)
        # Pooled SD for Cohen's d
        pooled_sd_sci = np.sqrt((mild_sci_sd**2 + sci_sd**2) / 2)
        pooled_sd_entropy = np.sqrt((mild_entropy_sd**2 + entropy_sd**2) / 2)
        
        cohens_d_sci = (sci_mean - mild_sci_mean) / pooled_sd_sci if pooled_sd_sci > 0 else 0
        cohens_d_entropy = (entropy_mean - mild_entropy_mean) / pooled_sd_entropy if pooled_sd_entropy > 0 else 0
        
        # PHQ-9 mean for reference
        phq9_mean = df.loc[mask, 'PHQ9_total'].mean()
        
        results.append({
            'Severity': band_name,
            'N': n,
            'PHQ9_M': phq9_mean,
            'SCI_M': sci_mean,
            'SCI_SD': sci_sd,
            'SCI_Mdn': sci_median,
            'SCI_IQR': f"[{sci_iqr_low:.2f}, {sci_iqr_high:.2f}]",
            'Entropy_M': entropy_mean,
            'Entropy_SD': entropy_sd,
            'DI': di,
            'd_SCI': cohens_d_sci,
            'd_Entropy': cohens_d_entropy
        })
    
    summary_df = pd.DataFrame(results)
    
    return summary_df


def print_severity_table(summary_df: pd.DataFrame):
    """
    Print formatted severity-stratified table for console output.
    """
    print("\n" + "=" * 90)
    print("SEVERITY-STRATIFIED SUMMARY TABLE")
    print("=" * 90)
    
    print(f"\n{'Severity':<20} {'N':>6} {'SCI M':>8} {'SCI SD':>8} {'Entropy M':>10} {'Entropy SD':>10} {'DI':>8}")
    print("-" * 90)
    
    for _, row in summary_df.iterrows():
        di_str = f"{row['DI']:.3f}" if not np.isnan(row['DI']) else "—"
        print(f"{row['Severity']:<20} {row['N']:>6} {row['SCI_M']:>8.3f} {row['SCI_SD']:>8.3f} "
              f"{row['Entropy_M']:>10.3f} {row['Entropy_SD']:>10.3f} {di_str:>8}")
    
    print("-" * 90)
    
    # Effect sizes
    print(f"\nEffect Sizes (Cohen's d relative to Mild):")
    print(f"{'Severity':<20} {'d(SCI)':>10} {'d(Entropy)':>12} {'Interpretation':<20}")
    print("-" * 70)
    
    for _, row in summary_df.iterrows():
        if row['Severity'] == 'Mild (5-9)':
            interp = "(reference)"
        else:
            # Interpret effect size
            d_sci = abs(row['d_SCI'])
            d_ent = abs(row['d_Entropy'])
            
            if d_sci < 0.2:
                sci_size = "negligible"
            elif d_sci < 0.5:
                sci_size = "small"
            elif d_sci < 0.8:
                sci_size = "medium"
            else:
                sci_size = "large"
            
            if d_ent < 0.2:
                ent_size = "negligible"
            elif d_ent < 0.5:
                ent_size = "small"
            elif d_ent < 0.8:
                ent_size = "medium"
            else:
                ent_size = "large"
            
            interp = f"SCI: {sci_size}, Ent: {ent_size}"
        
        d_sci_str = f"{row['d_SCI']:+.3f}" if row['Severity'] != 'Mild (5-9)' else "—"
        d_ent_str = f"{row['d_Entropy']:+.3f}" if row['Severity'] != 'Mild (5-9)' else "—"
        
        print(f"{row['Severity']:<20} {d_sci_str:>10} {d_ent_str:>12} {interp:<20}")
    
    # Summary statistics
    print("\n" + "-" * 90)
    print("Key Findings:")
    
    mild_row = summary_df[summary_df['Severity'] == 'Mild (5-9)'].iloc[0]
    severe_row = summary_df[summary_df['Severity'] == 'Severe (20+)'].iloc[0]
    
    delta_sci = severe_row['SCI_M'] - mild_row['SCI_M']
    delta_entropy = severe_row['Entropy_M'] - mild_row['Entropy_M']
    
    print(f"  • SCI shift (Mild → Severe): {delta_sci:+.3f} (toward balanced)")
    print(f"  • Entropy shift (Mild → Severe): {delta_entropy:+.3f} (toward uniform)")
    print(f"  • Effect size for SCI (Mild vs Severe): d = {severe_row['d_SCI']:.3f}")
    print(f"  • Effect size for Entropy (Mild vs Severe): d = {severe_row['d_Entropy']:.3f}")


def export_severity_table_latex(summary_df: pd.DataFrame, filepath: str = "table_severity_stratified.tex"):
    """
    Export severity-stratified table in LaTeX format for manuscript.
    """
    latex = r"""\begin{table}[htbp]
\centering
\caption{Attention Characteristics by Depression Severity}
\label{tab:severity_stratified}
\begin{tabular}{lccccccc}
\hline
 & & \multicolumn{3}{c}{Somatic-Cognitive Index} & \multicolumn{2}{c}{Entropy} & \\
\cline{3-5} \cline{6-7}
Severity & $N$ & $M$ & $SD$ & $d$ & $M$ & $SD$ & $d$ \\
\hline
"""
    
    for _, row in summary_df.iterrows():
        if row['Severity'] == 'Mild (5-9)':
            d_sci = "—"
            d_ent = "—"
        else:
            d_sci = f"{row['d_SCI']:+.2f}"
            d_ent = f"{row['d_Entropy']:+.2f}"
        
        severity_clean = row['Severity'].replace('(', '').replace(')', '').replace('-', '--')
        
        latex += f"{severity_clean} & {row['N']} & {row['SCI_M']:.2f} & {row['SCI_SD']:.2f} & {d_sci} & "
        latex += f"{row['Entropy_M']:.2f} & {row['Entropy_SD']:.2f} & {d_ent} \\\\\n"
    
    latex += r"""\hline
\end{tabular}
\begin{tablenotes}
\small
\item \textit{Note.} SCI = Somatic-Cognitive Index (positive = somatic-dominant, negative = cognitive-dominant). 
Entropy ranges from 0 (concentrated) to 1 (uniform). 
Cohen's $d$ effect sizes are relative to the Mild severity group.
\end{tablenotes}
\end{table}
"""
    
    with open(filepath, 'w') as f:
        f.write(latex)
    
    print(f"\n  Saved: {filepath}")
    
    return latex


# =============================================================================
# INTEGRATION INTO MAIN ANALYSIS
# =============================================================================

def analyze_continuous_heterogeneity_with_severity_table(attention: np.ndarray, df: pd.DataFrame) -> dict:
    """
    Extended version of analyze_continuous_heterogeneity that includes
    the severity-stratified summary table.
    
    Add this call after the main analysis in run_phq9_analysis():
    
        # After computing SCI and Entropy...
        severity_table = compute_severity_stratified_table(results['df'], attention)
        print_severity_table(severity_table)
        export_severity_table_latex(severity_table)
    """
    pass  # Placeholder - integrate into main function


# =============================================================================
# EXAMPLE OUTPUT
# =============================================================================

if __name__ == "__main__":
    # Example usage - paste into v5 analysis
    print("""
    To integrate into run_phq9_analysis_v5.py:
    
    1. Import the functions:
       from severity_table import compute_severity_stratified_table, print_severity_table, export_severity_table_latex
    
    2. After analyze_continuous_heterogeneity(), add:
       severity_table = compute_severity_stratified_table(results['df'], attention)
       print_severity_table(severity_table)
       export_severity_table_latex(severity_table)
    
    3. The table will be saved as 'table_severity_stratified.tex'
    """)
