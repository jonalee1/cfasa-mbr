"""
CFASA Configuration Module

Central configuration for constants, device setup, and reproducibility.
All other CFASA modules import from here.

Author: Jonathan Lee
Version: 0.32.0
"""
import os
import warnings
import numpy as np
import torch

__version__ = "0.32.0"

# === Environment Configuration ===
# Suppress KMeans memory leak warning on Windows
os.environ["OMP_NUM_THREADS"] = "4"
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
warnings.filterwarnings('ignore')

# === Simulation Defaults ===
RANDOM_SEED = 123
DEFAULT_NOISE_VARIANCE = 0.15**2
DEFAULT_DIRICHLET_CONCENTRATION = 60.0

# === Device Configuration ===
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def set_reproducible_state(seed: int = RANDOM_SEED):
    """Set random seeds for reproducible results across numpy and torch."""
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# Initialize reproducible state on import
set_reproducible_state()
