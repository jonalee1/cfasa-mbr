"""
CFASA Data Generation Module

Universal persona generation for synthetic datasets with realistic,
overlapping attention patterns that scale across item counts and domains.

Supports two DGP modes for manuscript demonstration:
- "identifiable": Response composition ≈ GT attention (sanity check)
- "realistic": Estimand separation (signed factors + baseline heterogeneity)

Author: Jonathan Lee
Version: 0.35.0
"""
from __future__ import annotations
from ast import If
from typing import Optional, Dict, List

import numpy as np

from cfasa_config import (
    RANDOM_SEED, 
    DEFAULT_NOISE_VARIANCE, 
    DEFAULT_DIRICHLET_CONCENTRATION
)

def _make_item_templates(n_items: int, n_personas: int, 
                        primary_strength: float = 0.45,
                        secondary_strength: float = 0.30,
                        baseline: float = 0.08) -> np.ndarray:
    """
    Create realistic, overlapping attention templates that scale across item counts.
    
    This approach creates patterns with:
    - A primary focus item (strongest attention, ~45%)
    - A secondary focus item (moderate attention, ~30%)
    - Remaining items with baseline attention (~8% divided)
    - Realistic overlap and non-extreme values
    
    Similar to original foundation patterns like [0.060, 0.340, 0.110, 0.490]
    instead of extreme peaks like [0.925, 0.025, 0.025, 0.025].
    
    Args:
        n_items: Number of items
        n_personas: Number of persona templates to create
        primary_strength: Weight for primary attention item (default 0.45)
        secondary_strength: Weight for secondary attention item (default 0.30)
        baseline: Baseline attention for other items (default 0.08)
        
    Returns:
        Array of shape (n_personas, n_items) with realistic attention templates
    """
    templates = np.zeros((n_personas, n_items), dtype=float)
    
    # Distribute personas evenly across items for primary focus
    primary_indices = np.linspace(0, n_items - 1, num=n_personas, dtype=int)
    
    for k in range(n_personas):
        primary_idx = primary_indices[k]
        
        # Choose secondary focus item (adjacent to primary, wrapping around)
        if n_items > 1:
            # Alternate between before and after primary
            offset = 1 if k % 2 == 0 else -1
            secondary_idx = (primary_idx + offset) % n_items
        else:
            secondary_idx = primary_idx
        
        # Initialize with baseline attention for all items
        pattern = np.full(n_items, baseline / max(1, n_items - 2))
        
        # Set primary and secondary attention
        pattern[primary_idx] = primary_strength
        if secondary_idx != primary_idx:
            pattern[secondary_idx] = secondary_strength
        
        # Add small random perturbations for realism
        rng = np.random.default_rng(RANDOM_SEED + k)
        noise = rng.normal(0, 0.015, n_items)
        pattern = pattern + noise
        
        # Ensure non-negativity and normalize to probability simplex
        pattern = np.maximum(pattern, 0.01)
        pattern = pattern / pattern.sum()
        
        templates[k] = pattern
    
    return templates


def _sample_attention_from_template(template: np.ndarray, concentration: float = 60.0, 
                                   rng: Optional[np.random.Generator] = None) -> np.ndarray:
    """
    Sample individual attention pattern from template using Dirichlet distribution.
    Higher concentration = closer to template, lower = more variation.
    """
    if rng is None:
        rng = np.random.default_rng()
    
    # Convert template to Dirichlet alpha parameters
    alpha = np.clip(template, 1e-8, None) * float(concentration)
    
    # Sample from Dirichlet
    return rng.dirichlet(alpha)


def _softplus(x: np.ndarray, beta: float = 1.0) -> np.ndarray:
    """Numerically stable softplus: log(1 + exp(beta * x)) / beta."""
    # For large x, softplus(x) ≈ x; for small x, softplus(x) ≈ exp(x)
    return np.where(
        x * beta > 20,
        x,
        np.log1p(np.exp(beta * x)) / beta
    )


class UniversalPersonaGenerator:
    """
    Universal persona generator that works across domains and item counts.
    Uses systematic template generation for reliable 98.6-99.1% performance 
    in controlled simulations. Creates realistic, overlapping patterns rather 
    than extreme peaks.
    
    Supports two DGP modes:
    - "identifiable": Nonnegative factors, no baseline → response ∝ attention
    - "realistic": Signed factors + baseline heterogeneity → estimand separation
    """
    
    def __init__(self, n_items: int = 5, n_personas: int = 3):
        self.n_items = n_items
        self.n_personas = n_personas
        
        # Generate systematic templates with realistic overlap
        self.templates = _make_item_templates(n_items, n_personas)
        
        # Generic persona names
        self.persona_names = [f"persona_{k}" for k in range(n_personas)]
        
        # Item labels (generic but can be overridden)
        self.item_labels = [f"Item_{j+1}" for j in range(n_items)]
    
    def set_domain_labels(self, item_labels: List[str], 
                         persona_names: Optional[List[str]] = None):
        """Allow domain-specific labeling while keeping systematic generation."""
        if len(item_labels) != self.n_items:
            raise ValueError(f"Must provide exactly {self.n_items} item labels")
        
        self.item_labels = item_labels
        
        if persona_names is not None:
            if len(persona_names) != self.n_personas:
                raise ValueError(f"Must provide exactly {self.n_personas} persona names")
            self.persona_names = persona_names
    
    def generate_dataset(self, n_samples: int = 800, signal_strength: float = 5.0,
                        noise_variance: Optional[float] = None,
                        baseline_sd: Optional[float] = None,
                        person_scale_sd: Optional[float] = None,
                        factor_shift: Optional[float] = None,
                        factor_sd: Optional[float] = None,
                        concentration: float = DEFAULT_DIRICHLET_CONCENTRATION,
                        standardize: Optional[bool] = None,
                        dgp_mode: str = "realistic",
                        seed: int = RANDOM_SEED) -> Dict:
        """
        Generate dataset with systematic persona templates and proper scaling.
        
        Args:
            n_samples: Number of individuals
            signal_strength: Strength of factor-to-response relationship  
            noise_variance: Measurement error variance (mode-specific default if None)
            concentration: Dirichlet concentration (higher = less individual variation)
            standardize: Whether to standardize responses (mode-specific default if None)
            dgp_mode: Data generating process mode
                - "identifiable": Nonnegative factors, no baseline, low noise
                  Response composition ≈ GT attention (sanity check for self-consistency)
                - "realistic": Signed factors + baseline heterogeneity
                  Estimand separation (self-consistency target ≠ GT attention)
            seed: Random seed
            
        Returns:
            Dictionary with responses, true attention patterns, assignments, etc.
        """
        if dgp_mode not in ("identifiable", "realistic"):
            raise ValueError(f"dgp_mode must be 'identifiable' or 'realistic', got '{dgp_mode}'")
        
        rng = np.random.default_rng(seed)
        
        # Mode-specific defaults
        if noise_variance is None:
            noise_variance = 0.05**2 if dgp_mode == "identifiable" else DEFAULT_NOISE_VARIANCE
        if standardize is None:
            standardize = False if dgp_mode == "identifiable" else True
        if baseline_sd is None:
            baseline_sd = 0.0 if dgp_mode == "identifiable" else 0.03   #(soft)
            #baseline_sd = 0.0 if dgp_mode == "identifiable" else 0.20  #(hard)
        if person_scale_sd is None:
            person_scale_sd = 0.05 if dgp_mode == "identifiable" else 0.10  #(soft)
            #person_scale_sd = 0.05 if dgp_mode == "identifiable" else 0.20 #(hard)            
        if factor_sd is None:
            factor_sd = 1.0 if dgp_mode == "identifiable" else 0.5  #(soft)
            #factor_sd = 1.0 if dgp_mode == "identifiable" else 1   #(hard)
        if factor_shift is None:
            factor_shift = 0.0 if dgp_mode == "identifiable" else 1.5  #(soft)
            #factor_shift = 0.0 if dgp_mode == "identifiable" else 0.0 #(hard)

        # Assign personas with equal probability
        persona_assignments = rng.integers(0, self.n_personas, size=n_samples)
        individual_assignments = [self.persona_names[k] for k in persona_assignments]
        
        # Generate individual attention patterns from templates
        true_attention_patterns = np.zeros((n_samples, self.n_items))
        for i in range(n_samples):
            template = self.templates[persona_assignments[i]]
            true_attention_patterns[i] = _sample_attention_from_template(
                template, concentration, rng
            )
        
        # Generate factor scores (mode-specific)
        if dgp_mode == "identifiable":
            # Nonnegative factors: softplus(z) ensures f > 0
            # This makes response ∝ attention (no sign flips)
            z = rng.normal(0, 1, n_samples)
            true_factor_scores = _softplus(z)
        else:  # realistic
            # Signed factors: standard normal (can be positive or negative)
            true_factor_scores = rng.normal(loc=factor_shift, scale=factor_sd, size=n_samples)
        
        # Generate responses using attention-weighted model
        responses = np.zeros((n_samples, self.n_items))
        
        for i in range(n_samples):
            # Base response from attention-weighted factor score
            person_scale = rng.normal(1.0, person_scale_sd)  # Individual scaling variation
            base_response = (true_attention_patterns[i] * 
                           true_factor_scores[i] * 
                           signal_strength * person_scale)
            
            # Baseline (mode-specific)
            if dgp_mode == "identifiable":
                # No item-specific baseline → response composition ≈ attention
                baseline = np.zeros(self.n_items)
            else:  # realistic
                # Item-specific baseline → breaks response-attention equivalence
                baseline = rng.normal(2, baseline_sd, self.n_items)
                           
            # Add noise
            noise = rng.normal(0, np.sqrt(noise_variance), self.n_items)
            
            observed = base_response + baseline + noise
            responses[i] = np.clip(observed, 0.0, None)  # Non-negative responses
        
        # Standardization (optional, mode-dependent default)
        if standardize:
            # Per-item z-scoring
            item_means = responses.mean(axis=0, keepdims=True)
            item_stds = responses.std(axis=0, keepdims=True) + 1e-8
            responses = (responses - item_means) / item_stds
        
        return {
            'responses': responses.astype(np.float32),
            'true_attention_patterns': true_attention_patterns.astype(np.float32),
            'true_factor_scores': true_factor_scores.astype(np.float32),
            'individual_assignments': individual_assignments,
            'persona_templates': self.templates.astype(np.float32),
            'item_labels': self.item_labels,
            'persona_names': self.persona_names,
            'n_samples': n_samples,
            'generation_seed': seed,
            'n_items': self.n_items,
            'dgp_mode': dgp_mode,
            'standardize': standardize,
            'noise_variance': noise_variance,
            'baseline_sd': baseline_sd,
            'person_scale_sd': person_scale_sd,
            'factor_shift': factor_shift,
            'factor_sd': factor_sd,
            'concentration': concentration
        }


class AttentionPersonaGenerator:
    """Legacy interface that uses the universal generator with personality-specific labels."""
    
    def __init__(self):
        self.generator = UniversalPersonaGenerator(n_items=5, n_personas=3)
        
        # Set personality-specific labels
        self.generator.set_domain_labels(
            item_labels=['Social Withdrawal', 'Somatic Symptoms', 
                        'Sleep/Appetite', 'Cognitive/Anhedonia', 'Mood/Affect'],
            persona_names=['cognitive_focused', 'somatic_focused', 'social_focused']
        )

        # Store legacy persona info for compatibility
        self.personas = {
            'cognitive_focused': {
                'attention_pattern': self.generator.templates[0],
                'prevalence': 0.33
            },
            'somatic_focused': {
                'attention_pattern': self.generator.templates[1], 
                'prevalence': 0.34
            },
            'social_focused': {
                'attention_pattern': self.generator.templates[2],
                'prevalence': 0.33
            }
        }
        
        self.symptom_labels = self.generator.item_labels
    
    def generate_dataset(self, n_samples: int = 800, signal_strength: float = 5.0,
                        noise_variance: float = DEFAULT_NOISE_VARIANCE, 
                        seed: int = RANDOM_SEED,
                        dgp_mode: str = "realistic",
                        standardize: Optional[bool] = None) -> Dict:
        """Legacy interface using universal generator."""
        result = self.generator.generate_dataset(
            n_samples=n_samples,
            signal_strength=signal_strength, 
            noise_variance=noise_variance,
            seed=seed,
            dgp_mode=dgp_mode,
            standardize=standardize
        )
        
        # Add legacy fields for compatibility
        result['persona_info'] = self.personas
        result['symptom_labels'] = self.symptom_labels
        
        return result