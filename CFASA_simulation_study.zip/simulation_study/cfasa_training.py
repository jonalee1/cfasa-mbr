"""
CFASA Training Module

Training procedure, loss functions, and learning rate scheduling for CFASA.
Includes multi-objective optimization with distribution-aware losses.

Author: Jonathan Lee
Version: 0.36.2 (Fix: Tuned entropy floor for 10-item scale)
"""
from __future__ import annotations
import time
from typing import Optional, Dict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

from cfasa_config import DEVICE, RANDOM_SEED
from cfasa_model import CFASANetwork


# ============================================================================
# Learning Rate Scheduler
# ============================================================================

class WarmupCosineScheduler:
    """Learning rate scheduler with linear warmup followed by cosine decay."""
    
    def __init__(self, optimizer, warmup_steps: int = 200, total_steps: int = 2000):
        self.optimizer = optimizer
        self.warmup_steps = max(1, int(warmup_steps))
        self.total_steps = max(self.warmup_steps + 1, int(total_steps))
        self.current_step = 0
        self.base_learning_rates = [group['lr'] for group in optimizer.param_groups]
    
    def step(self):
        """Update learning rates for all parameter groups."""
        self.current_step += 1
        
        for i, param_group in enumerate(self.optimizer.param_groups):
            base_lr = self.base_learning_rates[i]
            
            if self.current_step < self.warmup_steps:
                # Linear warmup
                lr = base_lr * self.current_step / self.warmup_steps
            else:
                # Cosine decay
                progress = (self.current_step - self.warmup_steps) / (self.total_steps - self.warmup_steps)
                lr = base_lr * 0.5 * (1 + np.cos(np.pi * min(1.0, progress)))
            
            param_group['lr'] = float(lr)


# ============================================================================
# Loss Functions
# ============================================================================

def jensen_shannon_divergence(predicted: torch.Tensor, target: torch.Tensor, 
                             epsilon: float = 1e-8) -> torch.Tensor:
    """Compute Jensen-Shannon divergence between probability distributions."""
    # Clamp to valid probability range
    p = torch.clamp(predicted, epsilon, 1.0)
    q = torch.clamp(target, epsilon, 1.0)
    
    # Compute mixture distribution
    m = 0.5 * (p + q)
    
    # Compute KL divergences
    kl_pm = torch.sum(p * (torch.log(p) - torch.log(m)), dim=1)
    kl_qm = torch.sum(q * (torch.log(q) - torch.log(m)), dim=1)
    
    # JS divergence is symmetric average of KL divergences
    return 0.5 * (kl_pm + kl_qm)


def correlation_loss(predicted: torch.Tensor, target: torch.Tensor, 
                    epsilon: float = 1e-8) -> torch.Tensor:
    """Compute negative correlation between predicted and target distributions."""
    # Center the distributions
    p_centered = predicted - predicted.mean(dim=1, keepdim=True)
    t_centered = target - target.mean(dim=1, keepdim=True)
    
    # Compute correlation coefficients
    numerator = torch.sum(p_centered * t_centered, dim=1)
    denominator = torch.sqrt(
        torch.sum(p_centered**2, dim=1) * torch.sum(t_centered**2, dim=1) + epsilon
    ) + epsilon
    
    correlations = numerator / denominator
    
    # Return mean of (1 - correlation) to minimize negative correlation
    return torch.mean(1 - correlations)

def _build_simplex_target(raw_responses: torch.Tensor, n_items: int, 
                          alpha: float = 0.5, epsilon: float = 1e-8) -> torch.Tensor:
    """Build simplex target from raw responses with within-person centering."""
    # Within-person shift to remove baseline contamination
    person_min = raw_responses.min(dim=1, keepdim=True)[0]
    raw_shifted = raw_responses - person_min
    
    # Ensure positivity and apply tempering
    raw_pos = raw_shifted + epsilon
    if alpha != 1.0:
        raw_pos = torch.pow(raw_pos, alpha)
    
    # Normalize to simplex
    target_dist = raw_pos / torch.sum(raw_pos, dim=1, keepdim=True)
    
    # Light smoothing to avoid zero-mass issues
    uniform_dist = torch.full_like(target_dist, 1.0 / n_items)
    target_dist = 0.98 * target_dist + 0.02 * uniform_dist
    
    return target_dist

def _compute_entropy(attention: torch.Tensor, epsilon: float = 1e-8) -> torch.Tensor:
    """Compute entropy of attention distributions."""
    return -torch.sum(
        attention * torch.log(torch.clamp(attention, epsilon, 1.0)),
        dim=1
    )


# ============================================================================
# CFASA Trainer
# ============================================================================

class CFASATrainer:
    """
    Robust training procedure for CFASA networks.
    """
    
    # Loss weights for supervised training
    SUPERVISED_LOSS_WEIGHTS = {
        'attention_supervision': 12.5,
        'reconstruction': 0.85,
        'entropy_floor': 0.05,
        'head_diversity': 0.02
    }
    
    # Loss weights for B-only self-consistency
    SELF_CONSISTENCY_LOSS_WEIGHTS = {
        'attention_supervision': 0.0,
        'self_consistency_js': 1.0,
        'self_consistency_corr': 0.2,
        'reconstruction': 0.0,
        'entropy_floor': 0.05,
        'head_diversity': 0.1
    }
    
    def __init__(self, n_items: int = 5, n_attention_heads: int = 3,
                 hidden_dim: int = 64, 
                 mode: str = 'supervised',
                 loss_weights: Optional[Dict[str, float]] = None,
                 loss_function: str = 'jensen_shannon',
                 alpha_tempering: float = 0.5):
        """
        Initialize CFASA trainer.
        """
        self.n_items = n_items
        self.n_attention_heads = n_attention_heads
        self.hidden_dim = hidden_dim
        self.mode = mode
        self.loss_function = loss_function
        self.alpha_tempering = alpha_tempering
        
        # Entropy floor: Tuned to 30% of max entropy for higher item counts
        # This prevents collapse but allows for sharper distributions than 30%
        self.entropy_floor = 0.30 * np.log(n_items)
        
        # Select loss weights based on mode
        if loss_weights is not None:
            self.loss_weights = loss_weights
        elif mode == 'self_consistency':
            self.loss_weights = self.SELF_CONSISTENCY_LOSS_WEIGHTS.copy()
        else:  # supervised (default)
            self.loss_weights = self.SUPERVISED_LOSS_WEIGHTS.copy()
        
        # Initialize components
        self.network = None
        self.response_scaler = StandardScaler()
        
        # Training state
        self.training_history = {}
        self.best_model_state = None
        
    def _compute_multi_objective_loss(self, predictions: Dict[str, torch.Tensor],
                                    targets: Dict[str, torch.Tensor],
                                    batch_responses: torch.Tensor,
                                    raw_batch_responses: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """Compute all loss components for multi-objective optimization."""
        losses = {}
        device = batch_responses.device
        
        # === SUPERVISED MODE ===
        if 'attention_weights' in targets:
            p = torch.clamp(predictions['attention_weights'], 1e-8, 1.0)
            t = torch.clamp(targets['attention_weights'], 1e-8, 1.0)
            m = 0.5 * (p + t)
            js = 0.5 * (torch.sum(p * (torch.log(p) - torch.log(m)), 1) + 
                        torch.sum(t * (torch.log(t) - torch.log(m)), 1))
            losses['attention_supervision'] = torch.mean(js) + 0.5 * correlation_loss(p, t)
        else:
            losses['attention_supervision'] = torch.tensor(0.0, device=device)
        
        # === SELF-CONSISTENCY MODE ===
        if self.mode == 'self_consistency':
            if raw_batch_responses is None:
                raise ValueError("raw_batch_responses required for self_consistency mode")
            
            target_dist = _build_simplex_target(
                raw_batch_responses, self.n_items, alpha=self.alpha_tempering
            )
            
            losses['self_consistency_js'] = torch.mean(
                jensen_shannon_divergence(predictions['attention_weights'], target_dist)
            )
            losses['self_consistency_corr'] = correlation_loss(
                predictions['attention_weights'], target_dist
            )
        else:
            losses['self_consistency_js'] = torch.tensor(0.0, device=device)
            losses['self_consistency_corr'] = torch.tensor(0.0, device=device)
        
        # === RECONSTRUCTION ===
        if self.mode == 'supervised':
            reconstructed = predictions['attention_weights'] * predictions['factor_scores']
            losses['reconstruction'] = nn.SmoothL1Loss(beta=0.35)(reconstructed, batch_responses)
        else:
            losses['reconstruction'] = torch.tensor(0.0, device=device)
        
        # === ENTROPY FLOOR ===
        attention_entropy = _compute_entropy(predictions['attention_weights'])
        entropy_violation = F.relu(self.entropy_floor - attention_entropy)
        losses['entropy_floor'] = torch.mean(entropy_violation)
        
        # === HEAD DIVERSITY ===
        if 'attention_heads' in predictions:
            head_diversity_loss = torch.tensor(0.0, device=device)
            heads = predictions['attention_heads']
            for i in range(len(heads)):
                for j in range(i + 1, len(heads)):
                    similarity = F.cosine_similarity(heads[i], heads[j], dim=1).mean()
                    head_diversity_loss = head_diversity_loss + similarity**2
            losses['head_diversity'] = head_diversity_loss
        else:
            losses['head_diversity'] = torch.tensor(0.0, device=device)
        
        return losses
    
    def _compute_validation_metrics(self, val_attention, val_factor_scores, X_val, X_val_raw, y_val):
        """Compute validation metrics."""
        metrics = {'val_metric': 0.0, 'val_js': float('nan'), 'val_corr': float('nan')}
        
        if self.mode == 'supervised' and y_val is not None:
            # Correlation with ground truth
            corrs = [torch.corrcoef(torch.stack([val_attention[i], y_val[i]]))[0, 1] 
                     for i in range(len(val_attention))]
            metrics['val_corr'] = np.mean([c.item() for c in corrs if not torch.isnan(c)])
            metrics['val_metric'] = metrics['val_corr']
            
        elif self.mode == 'self_consistency' and X_val_raw is not None:
            # Self-consistency metrics
            target_dist = _build_simplex_target(X_val_raw, self.n_items, alpha=self.alpha_tempering)
            
            # JS Divergence
            js = torch.mean(jensen_shannon_divergence(val_attention, target_dist)).item()
            metrics['val_js'] = js
            metrics['val_metric'] = -js  # Lower is better
            
            # Correlation with target
            corrs = [torch.corrcoef(torch.stack([val_attention[i], target_dist[i]]))[0, 1] 
                     for i in range(len(val_attention))]
            metrics['val_corr'] = np.mean([c.item() for c in corrs if not torch.isnan(c)])
        
        return metrics
    
    def train(self, responses: np.ndarray, 
              true_attention_patterns: Optional[np.ndarray] = None,
              n_epochs: int = 220, learning_rate: float = 0.002,
              batch_size: int = 256, validation_split: float = 0.15,
              early_stopping_patience: int = 30, min_improvement: float = 1e-4,
              verbose: bool = True) -> Dict[str, float]:
        """
        Train CFASA network.
        """
        start_time = time.time()
        
        if verbose:
            print(f"Training in '{self.mode}' mode with {self.n_items} items")
        
        # Data preprocessing
        X_scaled = self.response_scaler.fit_transform(responses)
        X_tensor = torch.as_tensor(X_scaled, dtype=torch.float32, device=DEVICE)
        X_raw_tensor = torch.as_tensor(responses, dtype=torch.float32, device=DEVICE)
        
        # Prepare targets
        y_train = y_val = y_val_gt = None
        if true_attention_patterns is not None:
            y_tensor = torch.as_tensor(true_attention_patterns, dtype=torch.float32, device=DEVICE)
            if self.mode == 'supervised':
                y_target = 0.98 * y_tensor + 0.02 * (1.0 / self.n_items) # Smoothing
                y_train = y_target # Only split later if needed
                y_val_gt = y_tensor
            else:
                y_val_gt = y_tensor # Just for validation reporting
        
        # Train/validation split
        indices = np.arange(len(X_tensor))
        if validation_split > 0:
            train_idx, val_idx = train_test_split(indices, test_size=validation_split, random_state=RANDOM_SEED)
            X_train, X_val = X_tensor[train_idx], X_tensor[val_idx]
            X_train_raw, X_val_raw = X_raw_tensor[train_idx], X_raw_tensor[val_idx]
            if y_train is not None:
                y_train, y_val = y_train[train_idx], y_train[val_idx]
            if y_val_gt is not None:
                y_val_gt = y_val_gt[val_idx]
        else:
            X_train, X_val = X_tensor, None
            X_train_raw, X_val_raw = X_raw_tensor, None
        
        # Initialize network
        self.network = CFASANetwork(
            n_items=self.n_items, 
            n_attention_heads=self.n_attention_heads,
            hidden_dim=self.hidden_dim
        ).to(DEVICE)
        
        # Optimizer
        optimizer = optim.Adam([
            {'params': self.network.primary_encoder.parameters(), 'lr': learning_rate, 'weight_decay': 1e-5},
            {'params': self.network.secondary_encoder.parameters(), 'lr': learning_rate * 0.8, 'weight_decay': 1e-5},
            {'params': self.network.context_fusion.parameters(), 'lr': learning_rate, 'weight_decay': 1e-6},
            {'params': self.network.attention_heads.parameters(), 'lr': learning_rate * 1.2, 'weight_decay': 5e-6},
            {'params': self.network.attention_combiner.parameters(), 'lr': learning_rate * 1.1, 'weight_decay': 5e-6},
            {'params': [self.network.temperature_logit], 'lr': learning_rate * 0.5, 'weight_decay': 0.0},
            {'params': self.network.factor_predictor.parameters(), 'lr': learning_rate, 'weight_decay': 1e-4}
        ])
        
        n_batches = int(np.ceil(len(X_train) / batch_size))
        scheduler = WarmupCosineScheduler(optimizer, warmup_steps=min(100, n_batches*2), total_steps=n_epochs*n_batches)
        
        best_val_metric = -np.inf
        patience_counter = 0
        self.training_history = {'train_loss': [], 'val_metric': [], 'val_js': [], 'val_corr': [], 'val_gt_corr': []}
        
        for epoch in range(n_epochs):
            self.network.train()
            epoch_loss = 0.0
            
            perm = torch.randperm(len(X_train), device=DEVICE)
            
            for i in range(n_batches):
                idx = perm[i*batch_size : (i+1)*batch_size]
                batch_X, batch_X_raw = X_train[idx], X_train_raw[idx]
                batch_targets = {'attention_weights': y_train[idx]} if y_train is not None else {}
                
                optimizer.zero_grad()
                att, fac, ref, heads = self.network(batch_X, return_attention_heads=True)
                preds = {'attention_weights': att, 'factor_scores': fac, 'attention_heads': heads}
                
                losses = self._compute_multi_objective_loss(preds, batch_targets, batch_X, batch_X_raw)
                loss = sum(self.loss_weights.get(k, 0) * v for k, v in losses.items())
                
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.network.parameters(), 1.0)
                optimizer.step()
                scheduler.step()
                epoch_loss += loss.item()
            
            # Validation
            val_results = {'val_metric': -1.0} # Default
            val_gt = float('nan')
            
            if X_val is not None:
                self.network.eval()
                with torch.no_grad():
                    v_att, v_fac, _ = self.network(X_val)
                    val_results = self._compute_validation_metrics(v_att, v_fac, X_val, X_val_raw, y_val)
                    
                    if y_val_gt is not None:
                        # Diagnostic GT correlation
                        gt_c = [torch.corrcoef(torch.stack([v_att[k], y_val_gt[k]]))[0,1].item() for k in range(len(v_att))]
                        val_gt = np.nanmean(gt_c)
            
            # Tracking
            self.training_history['train_loss'].append(epoch_loss / n_batches)
            self.training_history['val_metric'].append(val_results['val_metric'])
            self.training_history['val_js'].append(val_results.get('val_js', float('nan')))
            self.training_history['val_corr'].append(val_results.get('val_corr', float('nan')))
            self.training_history['val_gt_corr'].append(val_gt)
            
            # Early Stopping
            if val_results['val_metric'] > best_val_metric + min_improvement:
                best_val_metric = val_results['val_metric']
                patience_counter = 0
                self.best_model_state = self.network.state_dict().copy()
            else:
                patience_counter += 1
                
            if verbose and (epoch % 20 == 0 or epoch == n_epochs - 1):
                msg = f"Epoch {epoch+1}: Loss={epoch_loss/n_batches:.4f}"
                if self.mode == 'self_consistency':
                    msg += f", JS={val_results.get('val_js', 0):.4f}, Corr={val_results.get('val_corr', 0):.3f}"
                print(msg)
                
            if patience_counter >= early_stopping_patience:
                if verbose: print(f"Early stopping at epoch {epoch+1}")
                break
                
        if self.best_model_state:
            self.network.load_state_dict(self.best_model_state)
            
        return {
            'training_time': time.time() - start_time,
            'epochs_trained': epoch + 1,
            'final_val_js': self.training_history['val_js'][-1],
            'final_val_corr': self.training_history['val_corr'][-1]
        }

    def predict_attention_patterns(self, responses: np.ndarray) -> Dict[str, np.ndarray]:
        """Predict attention patterns."""
        if self.network is None: raise ValueError("Model not trained")
        X_scaled = self.response_scaler.transform(responses)
        X_tensor = torch.as_tensor(X_scaled, dtype=torch.float32, device=DEVICE)
        self.network.eval()
        with torch.no_grad():
            att, fac, ref = self.network(X_tensor)
        return {
            'attention_weights': att.detach().cpu().numpy(),
            'factor_scores': fac.detach().cpu().numpy().flatten()
        }