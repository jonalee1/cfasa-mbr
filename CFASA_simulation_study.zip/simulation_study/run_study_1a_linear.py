"""
CFASA Simulation Study 1a: Architectural Validation

Purpose:
    Establish that the CFASA neural architecture can recover true 
    attention parameters when supervision is available.

Claim:
    "When true attention parameters are available, CFASA recovers them with 
    high fidelity regardless of DGP complexity. This establishes that the 
    dual-encoder architecture has sufficient representational capacity."

Design:
    - Mode: Supervised only (true parameters provided during training)
    - DGP conditions: Identifiable and Realistic
    - Key metrics: 
        * TP Corr: Individual-level correlation with true attention
        * Factor Score Corr: Correlation between predicted and true factor scores
        * ADI: Attention Diversity Index (true vs learned)

Usage:
    python run_study_1a_linear.py

Required modules (same directory):
    cfasa_config.py, cfasa_data.py, cfasa_model.py, 
    cfasa_training.py, cfasa_utils.py

Author: Jonathan Lee
Version: 1.1.0 (Manuscript Study 1a - ADI added)
"""

from __future__ import annotations
import numpy as np
from typing import Dict, List

from cfasa_config import RANDOM_SEED, set_reproducible_state
from cfasa_data import UniversalPersonaGenerator
from cfasa_training import CFASATrainer
from cfasa_utils import evaluate_attention_recovery


# =============================================================================
# Attention Diversity Index (ADI)
# =============================================================================

def compute_adi(attention_patterns: np.ndarray) -> float:
    """
    Compute Attention Diversity Index.
    
    ADI measures the observed variance in attention patterns relative to
    the maximum possible variance under the simplex constraint.
    
    ADI ≈ 0: Homogeneous measurement (all individuals similar)
    ADI ≈ 1: Maximal heterogeneity (individuals at simplex extremes)
    
    Args:
        attention_patterns: Array of shape [n_samples, n_items]
        
    Returns:
        ADI value in [0, 1]
    """
    n_items = attention_patterns.shape[1]
    
    # Maximum variance for a simplex: when mass concentrated on single item
    # Var of [1, 0, 0, ...] = (1/J)(1 - 1/J) for each component
    max_var = (1 / n_items) * (1 - 1 / n_items)
    
    # Observed variance: sum of per-item variances across individuals
    observed_var = np.sum(np.var(attention_patterns, axis=0))
    
    # Normalize by maximum possible (J * max_var)
    adi = observed_var / (n_items * max_var)
    
    return float(adi)


# =============================================================================
# Study 1a: Architectural Validation
# =============================================================================

def run_study_1a(n_samples: int = 800, 
                 n_items: int = 5, 
                 n_personas: int = 3,
                 n_epochs: int = 220,
                 seed: int = RANDOM_SEED,
                 verbose: bool = True) -> Dict:
    """
    Study 1a: Architectural Validation via Supervised Training.
    
    Tests whether the CFASA architecture can recover true attention
    parameters when provided during training. This is a necessary (not sufficient)
    condition for the self-consistency estimand to be meaningful.
    
    Args:
        n_samples: Number of individuals per condition
        n_items: Number of items (indicators)
        n_personas: Number of generating personas
        n_epochs: Training epochs
        seed: Random seed for reproducibility
        verbose: Whether to print progress
        
    Returns:
        Dictionary containing results for both DGP conditions
    """
    set_reproducible_state(seed)
    
    if verbose:
        print("=" * 72)
        print("STUDY 1a: ARCHITECTURAL VALIDATION")
        print("Supervised Training × Multiple DGP Conditions")
        print("=" * 72)
        print(f"\nSettings: N={n_samples}, J={n_items}, K={n_personas}, seed={seed}")
        print("\nClaim: CFASA architecture recovers true attention parameters when")
        print("       supervised, regardless of DGP complexity.")
        print()
    
    results = {}
    
    # Two DGP conditions
    dgp_conditions = [
        ("identifiable", "Nonnegative factors, no baselines, low noise"),
        ("realistic", "Signed factors, heterogeneous baselines, standardized")
    ]
    
    for dgp_mode, description in dgp_conditions:
        
        if verbose:
            print("─" * 72)
            print(f"Condition: {dgp_mode.upper()} DGP")
            print(f"  {description}")
            print("─" * 72)
        
        # ---------------------------------------------------------------------
        # 1. Generate Data
        # ---------------------------------------------------------------------
        generator = UniversalPersonaGenerator(n_items=n_items, n_personas=n_personas)
        
        # Set domain labels
        if n_items == 5:
            generator.set_domain_labels(
                item_labels=['Mood', 'Anhedonia', 'Cognitive', 'Somatic', 'Social'],
                persona_names=['mood_focused', 'somatic_focused', 'cognitive_social']
            )
        
        dataset = generator.generate_dataset(
            n_samples=n_samples,
            dgp_mode=dgp_mode,
            seed=seed
        )
        
        if verbose:
            print(f"\n  Data generated:")
            print(f"    dgp_mode={dgp_mode}")
            print(f"    standardize={dataset['standardize']}")
            print(f"    noise_var={dataset['noise_variance']:.4f}")
            print(f"    n_samples={dataset['n_samples']}")
        
        # ---------------------------------------------------------------------
        # 2. Train CFASA (Supervised)
        # ---------------------------------------------------------------------
        if verbose:
            print(f"\n  Training (supervised mode)...")
        
        trainer = CFASATrainer(
            n_items=n_items, 
            n_attention_heads=n_personas,
            mode='supervised'
        )
        
        training_results = trainer.train(
            responses=dataset['responses'],
            true_attention_patterns=dataset['true_attention_patterns'],
            n_epochs=n_epochs,
            verbose=False  # Suppress epoch-by-epoch output
        )
        
        if verbose:
            print(f"    Training completed in {training_results['training_time']:.1f}s")
            print(f"    Epochs: {training_results['epochs_trained']}")
        
        # ---------------------------------------------------------------------
        # 3. Evaluate Recovery
        # ---------------------------------------------------------------------
        predictions = trainer.predict_attention_patterns(dataset['responses'])
        predicted_attention = predictions['attention_weights']
        predicted_factor_scores = predictions['factor_scores']
        true_attention = dataset['true_attention_patterns']
        true_factor_scores = dataset['true_factor_scores']
        
        # Individual-level TP (true parameter) correlations
        tp_correlations = []
        for i in range(len(predicted_attention)):
            corr = np.corrcoef(predicted_attention[i], true_attention[i])[0, 1]
            if not np.isnan(corr):
                tp_correlations.append(corr)
        
        tp_correlations = np.array(tp_correlations)
        mean_tp_corr = np.mean(tp_correlations)
        std_tp_corr = np.std(tp_correlations)
        
        # Factor score correlation
        factor_score_corr = np.corrcoef(predicted_factor_scores, true_factor_scores)[0, 1]
        
        # ADI: Attention Diversity Index
        true_adi = compute_adi(true_attention)
        learned_adi = compute_adi(predicted_attention)
        
        # Persona-level evaluation
        eval_results = evaluate_attention_recovery(
            predicted_attention=predicted_attention,
            true_attention=true_attention,
            individual_assignments=dataset['individual_assignments']
        )
        
        # Store results
        results[dgp_mode] = {
            'dgp_mode': dgp_mode,
            'dataset': dataset,
            'trainer': trainer,
            'training_results': training_results,
            'predictions': predictions,
            'tp_correlations': tp_correlations,
            'mean_tp_corr': mean_tp_corr,
            'std_tp_corr': std_tp_corr,
            'factor_score_corr': factor_score_corr,
            'true_adi': true_adi,
            'learned_adi': learned_adi,
            'eval_results': eval_results
        }
        
        if verbose:
            print(f"\n  Results:")
            print(f"    TP correlation:      r = {mean_tp_corr:.3f} (SD = {std_tp_corr:.3f})")
            print(f"    Factor score corr:   r = {factor_score_corr:.3f}")
            print(f"    True ADI:            {true_adi:.3f}")
            print(f"    Learned ADI:         {learned_adi:.3f}")
            
            if 'persona_correlations' in eval_results:
                print(f"\n  Persona-level recovery:")
                for persona, corr in eval_results['persona_correlations'].items():
                    print(f"    {persona}: r = {corr:.3f}")
    
    # =========================================================================
    # Summary Table
    # =========================================================================
    if verbose:
        print("\n")
        print("=" * 72)
        print("STUDY 1a SUMMARY: Architectural Validation")
        print("=" * 72)
        print()
        print(f"{'DGP Condition':<15} {'TP Corr (Mean ± SD)':>20} {'Factor Score':>14} {'True ADI':>10} {'Learned ADI':>12}")
        print("─" * 72)
        
        for dgp_mode, _ in dgp_conditions:
            r = results[dgp_mode]
            tp_str = f"{r['mean_tp_corr']:.3f} ± {r['std_tp_corr']:.3f}"
            print(f"{dgp_mode:<15} {tp_str:>20} {r['factor_score_corr']:>14.3f} "
                  f"{r['true_adi']:>10.3f} {r['learned_adi']:>12.3f}")
        
        print("─" * 72)
        print()
        
        # Validation check
        ident_ok = results['identifiable']['mean_tp_corr'] > 0.95
        real_ok = results['realistic']['mean_tp_corr'] > 0.90
        
        if ident_ok and real_ok:
            print("✓ ARCHITECTURAL VALIDATION PASSED")
            print("  The dual-encoder architecture successfully recovers true attention")
            print("  parameters under both identifiable and realistic DGPs.")
        else:
            print("⚠ VALIDATION CHECK")
            if not ident_ok:
                print(f"  Identifiable DGP: TP corr = {results['identifiable']['mean_tp_corr']:.3f} (expected > 0.95)")
            if not real_ok:
                print(f"  Realistic DGP: TP corr = {results['realistic']['mean_tp_corr']:.3f} (expected > 0.90)")
        
        print()
        print("Interpretation:")
        print("  This study validates that CFASA's architecture has sufficient capacity")
        print("  to learn individual-specific attention patterns. High TP correlation")
        print("  confirms recovery of generating parameters. Comparable True/Learned ADI")
        print("  confirms preservation of population-level measurement heterogeneity.")
        print()
    
    return results


# =============================================================================
# Entry Point
# =============================================================================

if __name__ == "__main__":
    results = run_study_1a(
        n_samples=800,
        n_items=5,
        n_personas=3,
        n_epochs=220,
        seed=123,
        verbose=True
    )
