"""
CFASA Simulation Study 1b: Nonlinear Pattern Recovery

Purpose:
    Establish that the CFASA architecture can recover nonlinear 
    indicator-construct relationships when supervision is available.

Claim:
    "CFASA's dual-encoder architecture captures threshold, saturation, 
    and curvilinear attention patterns that violate classical CFA's 
    linearity assumption."

Design:
    - Mode: Supervised only (true parameters provided during training)
    - DGP: Four items with distinct nonlinear patterns
        * Item 0 (Threshold): Step function at η > 1.0
        * Item 1 (Saturation): Exponential decay toward asymptote
        * Item 2 (Curvilinear): Inverted parabola peaking at η = 0
        * Item 3 (Linear): Constant attention (control)
    - Key metrics:
        * TP Corr: Overall correlation with true attention
        * Item-specific TP correlation for each nonlinear pattern type
        * Factor Score Corr: Correlation between predicted and true η
        * ADI: Attention Diversity Index (True / Learned / Recovery)

Usage:
    python run_study_1b_nonlinear.py

Required modules (same directory):
    cfasa_config.py, cfasa_data.py, cfasa_model.py, 
    cfasa_training.py, cfasa_utils.py

Author: Jonathan Lee
Version: 1.1.0 (Manuscript Study 1b - Revised)
"""

from __future__ import annotations
import sys
import os

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from typing import Dict, Optional
import numpy as np
from scipy.stats import pearsonr

from cfasa_config import RANDOM_SEED, DEVICE, set_reproducible_state
from cfasa_training import CFASATrainer


# =============================================================================
# Nonlinear Pattern Data Generator
# =============================================================================

class NonlinearPatternGenerator:
    """
    Generate data with known nonlinear attention patterns for validation.
    
    Four items with distinct functional forms:
        - Threshold: Step function (attention jumps when η > threshold)
        - Saturation: Exponential approach to asymptote
        - Curvilinear: Peak attention at intermediate η values
        - Linear: Constant attention (control condition)
    """
    
    def __init__(self):
        self.n_items = 4
        self.item_labels = ['Threshold', 'Saturation', 'Curvilinear', 'Linear']
        
        # Pattern specifications
        self.patterns = {
            'threshold': {
                'item_idx': 0,
                'description': 'Step function: attention increases when η > 1.0',
                'params': {'threshold': 1.0, 'low': 0.15, 'high': 0.40}
            },
            'saturation': {
                'item_idx': 1,
                'description': 'Exponential: approaches asymptote as η increases',
                'params': {'baseline': 0.12, 'asymptote': 0.28, 'rate': 1.5}
            },
            'curvilinear': {
                'item_idx': 2,
                'description': 'Inverted parabola: peak attention at η = 0',
                'params': {'peak_loc': 0.0, 'width': 1.8, 'min_val': 0.16, 'peak_val': 0.42}
            },
            'linear': {
                'item_idx': 3,
                'description': 'Constant: uniform attention (control)',
                'params': {'value': 0.25}
            }
        }
    
    def _threshold_function(self, eta: np.ndarray, threshold: float, 
                           low: float, high: float) -> np.ndarray:
        """Step function: low attention below threshold, high above."""
        return np.where(eta > threshold, high, low)
    
    def _saturation_function(self, eta: np.ndarray, baseline: float,
                            asymptote: float, rate: float) -> np.ndarray:
        """Exponential saturation: baseline + asymptote × (1 - exp(-rate × η))."""
        return baseline + asymptote * (1 - np.exp(-rate * np.maximum(eta, 0)))
    
    def _curvilinear_function(self, eta: np.ndarray, peak_loc: float,
                              width: float, min_val: float, 
                              peak_val: float) -> np.ndarray:
        """Gaussian peak: maximum attention at peak_loc, declining away."""
        distances = (eta - peak_loc) / width
        gaussian = np.exp(-0.5 * distances ** 2)
        return min_val + (peak_val - min_val) * gaussian
    
    def _linear_function(self, eta: np.ndarray, value: float) -> np.ndarray:
        """Constant attention (linear control)."""
        return np.full_like(eta, value)
    
    def _generate_attention_patterns(self, factor_scores: np.ndarray) -> np.ndarray:
        """Generate true attention patterns using analytical functions."""
        n_samples = len(factor_scores)
        attention = np.zeros((n_samples, self.n_items))
        
        # Apply each pattern function
        p = self.patterns
        attention[:, 0] = self._threshold_function(factor_scores, **p['threshold']['params'])
        attention[:, 1] = self._saturation_function(factor_scores, **p['saturation']['params'])
        attention[:, 2] = self._curvilinear_function(factor_scores, **p['curvilinear']['params'])
        attention[:, 3] = self._linear_function(factor_scores, **p['linear']['params'])
        
        # Normalize to probability simplex
        row_sums = attention.sum(axis=1, keepdims=True)
        attention = attention / row_sums
        
        return attention
    
    def generate_dataset(self, n_samples: int = 800, 
                        signal_strength: float = 4.5,
                        noise_sd: float = 0.10,
                        seed: int = RANDOM_SEED) -> Dict:
        """
        Generate nonlinear pattern test data.
        
        Args:
            n_samples: Number of individuals
            signal_strength: Scaling factor for attention × factor signal
            noise_sd: Standard deviation of measurement noise
            seed: Random seed
            
        Returns:
            Dataset dictionary compatible with CFASA training
        """
        rng = np.random.default_rng(seed)
        
        # Generate factor scores with good coverage of nonlinear regions
        # Use wider distribution to capture threshold and saturation effects
        factor_scores = rng.normal(0, 1.4, n_samples)
        
        # Generate true attention patterns
        true_attention = self._generate_attention_patterns(factor_scores)
        
        # Generate observed responses
        responses = np.zeros((n_samples, self.n_items))
        
        for i in range(n_samples):
            for j in range(self.n_items):
                signal = true_attention[i, j] * factor_scores[i] * signal_strength
                noise = rng.normal(0, noise_sd)
                baseline = rng.normal(4.0, 0.08)
                responses[i, j] = np.clip(signal + baseline + noise, 1, 7)
        
        return {
            'responses': responses.astype(np.float32),
            'true_attention_patterns': true_attention.astype(np.float32),
            'true_factor_scores': factor_scores.astype(np.float32),
            'individual_assignments': ['nonlinear'] * n_samples,
            'item_labels': self.item_labels,
            'patterns': self.patterns,
            'n_samples': n_samples,
            'n_items': self.n_items,
            'generation_seed': seed
        }


# =============================================================================
# Pattern Recovery Analysis (renamed from Fidelity)
# =============================================================================

def compute_pattern_recovery(true_attention: np.ndarray, 
                             predicted_attention: np.ndarray,
                             item_labels: list) -> Dict:
    """
    Compute TP correlation metrics for nonlinear pattern recovery.
    
    Args:
        true_attention: True attention patterns [n_samples, n_items]
        predicted_attention: Learned attention patterns [n_samples, n_items]
        item_labels: Names for each item/pattern type
        
    Returns:
        Dictionary with overall and item-specific TP correlation metrics
    """
    n_samples, n_items = true_attention.shape
    
    # Overall individual-level correlations
    individual_corrs = []
    for i in range(n_samples):
        corr = np.corrcoef(true_attention[i], predicted_attention[i])[0, 1]
        if not np.isnan(corr):
            individual_corrs.append(corr)
    
    individual_corrs = np.array(individual_corrs)
    
    # Item-specific TP correlation (pattern-type recovery)
    item_tp_corr = {}
    for j in range(n_items):
        true_j = true_attention[:, j]
        pred_j = predicted_attention[:, j]
        
        corr, _ = pearsonr(true_j, pred_j)
        mae = np.mean(np.abs(true_j - pred_j))
        
        item_tp_corr[item_labels[j]] = {
            'tp_correlation': corr if not np.isnan(corr) else 0.0,
            'mae': mae
        }
    
    return {
        'mean_individual_corr': np.mean(individual_corrs),
        'std_individual_corr': np.std(individual_corrs),
        'min_individual_corr': np.min(individual_corrs),
        'item_tp_corr': item_tp_corr
    }


def compute_adi(attention: np.ndarray) -> float:
    """
    Compute Attention Diversity Index.
    
    ADI = observed variance / maximum possible variance under simplex constraint.
    
    Args:
        attention: Attention patterns [n_samples, n_items]
        
    Returns:
        ADI value between 0 (homogeneous) and 1 (maximum diversity)
    """
    n_items = attention.shape[1]
    max_var = (1 / n_items) * (1 - 1 / n_items)  # Maximum variance for simplex
    observed_var = np.sum(np.var(attention, axis=0))
    return observed_var / (n_items * max_var)


# =============================================================================
# Study 1b: Nonlinear Pattern Recovery
# =============================================================================

def run_study_1b(n_samples: int = 800,
                 n_epochs: int = 220,
                 seed: int = RANDOM_SEED,
                 verbose: bool = True) -> Dict:
    """
    Study 1b: Nonlinear Pattern Recovery via Supervised Training.
    
    Tests whether the CFASA architecture can recover nonlinear
    attention functions (threshold, saturation, curvilinear) when
    true patterns are provided during training.
    
    Args:
        n_samples: Number of individuals
        n_epochs: Training iterations
        seed: Random seed for reproducibility
        verbose: Whether to print progress
        
    Returns:
        Dictionary containing results and diagnostics
    """
    set_reproducible_state(seed)
    
    if verbose:
        print("=" * 72)
        print("STUDY 1b: NONLINEAR PATTERN RECOVERY")
        print("Supervised Training × Nonlinear Indicator-Construct Relationships")
        print("=" * 72)
        print(f"\nSettings: N={n_samples}, J=4, seed={seed}")
        print("\nClaim: CFASA architecture recovers threshold, saturation, and")
        print("       curvilinear attention patterns that violate CFA linearity.")
        print()
    
    # -------------------------------------------------------------------------
    # 1. Generate Nonlinear Test Data
    # -------------------------------------------------------------------------
    if verbose:
        print("─" * 72)
        print("Data Generation: Nonlinear Attention Patterns")
        print("─" * 72)
    
    generator = NonlinearPatternGenerator()
    dataset = generator.generate_dataset(n_samples=n_samples, seed=seed)
    
    if verbose:
        print("\n  Pattern specifications:")
        for name, info in generator.patterns.items():
            print(f"    {name.capitalize()}: {info['description']}")
        
        # Show factor score coverage
        eta = dataset['true_factor_scores']
        print(f"\n  Factor score range: [{eta.min():.2f}, {eta.max():.2f}]")
        print(f"    Below threshold (η ≤ 1.0): {np.sum(eta <= 1.0)} individuals")
        print(f"    Above threshold (η > 1.0): {np.sum(eta > 1.0)} individuals")
    
    # -------------------------------------------------------------------------
    # 2. Train CFASA (Supervised)
    # -------------------------------------------------------------------------
    if verbose:
        print(f"\n  Training (supervised mode)...")
    
    trainer = CFASATrainer(
        n_items=4,
        n_attention_heads=3,
        mode='supervised'
    )
    
    training_results = trainer.train(
        responses=dataset['responses'],
        true_attention_patterns=dataset['true_attention_patterns'],
        n_epochs=n_epochs,
        verbose=False
    )
    
    if verbose:
        print(f"    Completed in {training_results['training_time']:.1f}s")
    
    # -------------------------------------------------------------------------
    # 3. Evaluate Pattern Recovery
    # -------------------------------------------------------------------------
    predictions = trainer.predict_attention_patterns(dataset['responses'])
    predicted_attention = predictions['attention_weights']
    predicted_factor_scores = predictions['factor_scores']
    true_attention = dataset['true_attention_patterns']
    true_factor_scores = dataset['true_factor_scores']
    
    # Compute TP correlation metrics
    recovery = compute_pattern_recovery(
        true_attention, predicted_attention, generator.item_labels
    )
    
    # Factor score correlation
    factor_score_corr = np.corrcoef(predicted_factor_scores, true_factor_scores)[0, 1]
    
    # Compute ADI
    true_adi = compute_adi(true_attention)
    learned_adi = compute_adi(predicted_attention)
    adi_recovery = 1-(abs(learned_adi-true_adi) / true_adi)
    
    if verbose:
        print(f"\n  Results:")
        print(f"    Overall TP correlation: r = {recovery['mean_individual_corr']:.3f} "
              f"(SD = {recovery['std_individual_corr']:.3f})")
        print(f"    Factor score correlation: r = {factor_score_corr:.3f}")
        
        print(f"\n  Attention Diversity Index:")
        print(f"    True ADI:     {true_adi:.3f}")
        print(f"    Learned ADI:  {learned_adi:.3f}")
        print(f"    Recovery:     {adi_recovery:.1%}")
        
        print(f"\n  Pattern-specific TP correlation:")
        for label, metrics in recovery['item_tp_corr'].items():
            print(f"    {label}: r = {metrics['tp_correlation']:.3f}")
    
    # -------------------------------------------------------------------------
    # 4. Store Results
    # -------------------------------------------------------------------------
    results = {
        'dataset': dataset,
        'trainer': trainer,
        'training_results': training_results,
        'predictions': predictions,
        'recovery': recovery,
        'factor_score_corr': factor_score_corr,
        'true_adi': true_adi,
        'learned_adi': learned_adi,
        'adi_recovery': adi_recovery
    }
    
    # =========================================================================
    # Summary Table
    # =========================================================================
    if verbose:
        print("\n")
        print("=" * 72)
        print("STUDY 1b SUMMARY: Nonlinear Pattern Recovery")
        print("=" * 72)
        print()
        
        # Overall metrics
        print(f"{'Metric':<35} {'Value':>15}")
        print("─" * 52)
        tp_str = f"{recovery['mean_individual_corr']:.3f} ± {recovery['std_individual_corr']:.3f}"
        print(f"{'TP Corr (Mean ± SD)':<35} {tp_str:>15}")
        print(f"{'Factor Score Corr':<35} {factor_score_corr:>15.3f}")
        print(f"{'Min Individual Corr':<35} {recovery['min_individual_corr']:>15.3f}")
        print()
        
        # ADI metrics
        print(f"{'Attention Diversity Index':<35}")
        print(f"  {'True ADI:':<20} {true_adi:>10.3f}")
        print(f"  {'Learned ADI:':<20} {learned_adi:>10.3f}")
        print(f"  {'Recovery:':<20} {adi_recovery:>10.1%}")
        print()
        
        # Pattern-specific table
        print(f"{'Pattern Type':<15} {'TP Corr (r)':>12}   {'Description':<40}")
        print("─" * 72)
        
        pattern_order = ['Threshold', 'Saturation', 'Curvilinear', 'Linear']
        descriptions = {
            'Threshold': 'Step function at η > 1.0',
            'Saturation': 'Logistic ceiling, plateau above η ≈ 1.5',
            'Curvilinear': 'Peak at η = 0, declining away',
            'Linear': 'Constant (control)'
        }
        
        for label in pattern_order:
            r = recovery['item_tp_corr'][label]['tp_correlation']
            desc = descriptions[label]
            print(f"{label:<15} {r:>12.3f}   {desc:<40}")
        
        print("─" * 72)
        print()
        
        # Validation check
        overall_ok = recovery['mean_individual_corr'] > 0.90
        all_patterns_ok = all(
            recovery['item_tp_corr'][label]['tp_correlation'] > 0.80 
            for label in pattern_order
        )
        adi_ok = adi_recovery > 0.90
        
        if overall_ok and all_patterns_ok and adi_ok:
            print("✓ NONLINEAR PATTERN RECOVERY VALIDATED")
            print("  CFASA successfully recovers threshold, saturation, and curvilinear")
            print("  attention patterns that violate classical CFA linearity assumptions.")
            print(f"  Attention diversity preserved at {adi_recovery:.1%}.")
        else:
            print("⚠ VALIDATION CHECK")
            if not overall_ok:
                print(f"  Overall TP corr = {recovery['mean_individual_corr']:.3f} (expected > 0.90)")
            for label in pattern_order:
                r = recovery['item_tp_corr'][label]['tp_correlation']
                if r <= 0.80:
                    print(f"  {label} TP corr = {r:.3f} (expected > 0.80)")
            if not adi_ok:
                print(f"  ADI recovery = {adi_recovery:.1%} (expected > 90%)")
        
        print()
        print("Interpretation:")
        print("  This study validates that CFASA can learn nonlinear indicator-construct")
        print("  relationships. The architecture's representational capacity extends beyond")
        print("  the linear loading constraints of classical confirmatory factor analysis.")
        print()
    
    return results


# =============================================================================
# Entry Point
# =============================================================================

if __name__ == "__main__":
    results = run_study_1b(
        n_samples=800,
        n_epochs=220,
        seed=123,
        verbose=True
    )
