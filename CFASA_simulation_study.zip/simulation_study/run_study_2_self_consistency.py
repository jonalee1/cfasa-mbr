"""
================================================================================
STUDY 2: ESTIMAND CHARACTERIZATION
Self-Consistent Estimation Under Varying Identification Regimes

Manuscript: "Beyond Measurement Invariance: Individual-Specific Confirmatory 
            Factor Analysis with Self-Attention"
Section:    Simulation Studies - Study 2
================================================================================

PURPOSE:
    This study addresses a fundamental question: What does self-consistent 
    estimation measure? The answer depends on whether response composition 
    is informative about the latent measurement structure—a condition that 
    varies with the data-generating process (DGP).

DESIGN:
    We evaluate self-consistent estimation under three simulation regimes 
    spanning a continuum from favorable to adversarial identification conditions:
    
    1. IDENTIFIABLE REGIME
       - Nonnegative factors (softplus transformation)
       - No item-specific baselines
       - Low noise (σ² = 0.0025)
       - No standardization
       → Response composition approximates generating attention
    
    2. REALISTIC (SOFT) REGIME  
       - Signed factors with positive shift (μ_η = 1.5)
       - Modest baseline heterogeneity (σ_b = 0.03)
       - Moderate noise (σ² = 0.0225)
       - Standardization applied
       → Partial alignment between response composition and generating attention
    
    3. REALISTIC (HARD) REGIME
       - Unshifted signed factors (μ_η = 0)
       - Substantial baseline heterogeneity (σ_b = 0.20)
       - Large person-scale variation
       - Standardization applied
       → Response composition and generating attention are distinct estimands

KEY METRICS:
    - Reference Attention Correlation: Estimated vs. self-consistency target
    - True Patterns (TP) Correlation: Estimated vs. generating attention  
    - Jensen-Shannon Divergence: Distribution distance to target

THEORETICAL INSIGHT:
    Self-consistency estimates "response profile allocation"—the relative 
    distribution of responses across indicators, independent of level. 
    TP correlation is a diagnostic indexing alignment between what is measured 
    and what generated the data, rather than a success criterion. When 
    identification conditions hold, these coincide; when violated, they diverge.

USAGE:
    python run_study_2_self_consistency.py

Author: Jonathan Lee
Version: 1.0.0
Dependencies: cfasa_config, cfasa_data, cfasa_training, cfasa_utils
================================================================================
"""

from __future__ import annotations
import argparse
import sys
import time
from typing import Dict, List, Tuple
from dataclasses import dataclass

import numpy as np
import pandas as pd

from cfasa_config import RANDOM_SEED, set_reproducible_state
from cfasa_data import UniversalPersonaGenerator
from cfasa_training import CFASATrainer
from cfasa_utils import evaluate_attention_recovery


# ============================================================================
# SIMULATION CONFIGURATION
# ============================================================================

@dataclass
class RegimeConfig:
    """Configuration for a simulation regime."""
    name: str
    description: str
    dgp_mode: str
    # DGP-specific parameters (override defaults in UniversalPersonaGenerator)
    factor_shift: float = None
    factor_sd: float = None
    baseline_sd: float = None
    person_scale_sd: float = None
    noise_variance: float = None
    standardize: bool = None


# Define the three regimes from the manuscript
REGIMES = [
    RegimeConfig(
        name="identifiable",
        description="Nonnegative factors, no baseline, low noise",
        dgp_mode="identifiable",
        # Uses defaults: factor via softplus, no baseline, σ²=0.0025, no standardization
    ),
    RegimeConfig(
        name="realistic_soft",
        description="Signed factors (μ=1.5), modest baseline (σ=0.03), standardized",
        dgp_mode="realistic",
        factor_shift=1.5,
        factor_sd=0.5,
        baseline_sd=0.03,
        person_scale_sd=0.10,
        # Uses default noise for realistic mode
    ),
    RegimeConfig(
        name="realistic_hard",
        description="Signed factors (μ=0), large baseline (σ=0.20), standardized",
        dgp_mode="realistic",
        factor_shift=0.0,
        factor_sd=1.0,
        baseline_sd=0.20,
        person_scale_sd=0.20,
    ),
]


# ============================================================================
# CORE SIMULATION FUNCTIONS
# ============================================================================

def run_single_condition(
    regime: RegimeConfig,
    n_samples: int = 800,
    n_items: int = 5,
    n_personas: int = 3,
    seed: int = RANDOM_SEED,
    verbose: bool = True
) -> Dict:
    """
    Run self-consistency estimation under a single regime.
    
    Args:
        regime: RegimeConfig specifying the DGP
        n_samples: Number of individuals to generate
        n_items: Number of indicators
        n_personas: Number of latent personas
        seed: Random seed for reproducibility
        verbose: Whether to print progress
        
    Returns:
        Dictionary containing:
        - regime_name: Name of the regime
        - target_corr: Correlation with self-consistency target (reference attention)
        - tp_corr: Correlation with true generating attention patterns
        - js_divergence: Jensen-Shannon divergence to target
        - individual_target_corrs: Per-person target correlations
        - individual_tp_corrs: Per-person TP correlations
        - training_results: Raw training output
        - dataset: Generated data (for post-hoc analysis)
    """
    set_reproducible_state(seed)
    
    if verbose:
        print(f"\n{'─' * 70}")
        print(f"REGIME: {regime.name.upper()}")
        print(f"  {regime.description}")
        print(f"{'─' * 70}")
    
    # -------------------------------------------------------------------------
    # Step 1: Generate data under specified DGP
    # -------------------------------------------------------------------------
    generator = UniversalPersonaGenerator(n_items=n_items, n_personas=n_personas)
    
    # Build kwargs for dataset generation, using regime-specific overrides
    dgp_kwargs = {
        'n_samples': n_samples,
        'dgp_mode': regime.dgp_mode,
        'seed': seed,
    }
    
    # Apply regime-specific parameter overrides
    if regime.factor_shift is not None:
        dgp_kwargs['factor_shift'] = regime.factor_shift
    if regime.factor_sd is not None:
        dgp_kwargs['factor_sd'] = regime.factor_sd
    if regime.baseline_sd is not None:
        dgp_kwargs['baseline_sd'] = regime.baseline_sd
    if regime.person_scale_sd is not None:
        dgp_kwargs['person_scale_sd'] = regime.person_scale_sd
    if regime.noise_variance is not None:
        dgp_kwargs['noise_variance'] = regime.noise_variance
    if regime.standardize is not None:
        dgp_kwargs['standardize'] = regime.standardize
    
    dataset = generator.generate_dataset(**dgp_kwargs)
    
    if verbose:
        print(f"  Generated N={n_samples}, J={n_items}, K={n_personas}")
        print(f"  DGP settings: standardize={dataset['standardize']}, "
              f"noise_var={dataset['noise_variance']:.4f}, "
              f"baseline_sd={dataset.get('baseline_sd', 'default')}")
    
    # -------------------------------------------------------------------------
    # Step 2: Train CFASA with self-consistency
    # -------------------------------------------------------------------------
    trainer = CFASATrainer(
        n_items=n_items, 
        n_attention_heads=3, 
        mode='self_consistency'
    )
    
    training_results = trainer.train(
        responses=dataset['responses'],
        true_attention_patterns=dataset['true_attention_patterns'],  # For validation only
        n_epochs=220,
        verbose=False  # Suppress epoch-by-epoch output
    )
    
    # -------------------------------------------------------------------------
    # Step 3: Extract predictions and compute metrics
    # -------------------------------------------------------------------------
    predictions = trainer.predict_attention_patterns(dataset['responses'])
    predicted_attention = predictions['attention_weights']
    true_attention = dataset['true_attention_patterns']
    
    # Compute individual-level correlations with TRUE GENERATING PATTERNS
    tp_correlations = []
    for i in range(len(predicted_attention)):
        corr = np.corrcoef(predicted_attention[i], true_attention[i])[0, 1]
        if not np.isnan(corr):
            tp_correlations.append(corr)
    mean_tp_corr = np.mean(tp_correlations)
    
    # Extract self-consistency metrics (correlation with TARGET, not ground truth)
    target_corr = training_results['final_val_corr']
    js_divergence = training_results['final_val_js']
    
    if verbose:
        print(f"\n  RESULTS:")
        print(f"    Reference Attention Corr (vs target): {target_corr:.3f}")
        print(f"    True Patterns Corr (vs generating):   {mean_tp_corr:.3f}")
        print(f"    Jensen-Shannon Divergence:            {js_divergence:.4f}")
    
    return {
        'regime_name': regime.name,
        'regime_description': regime.description,
        'target_corr': target_corr,
        'tp_corr': mean_tp_corr,
        'js_divergence': js_divergence,
        'individual_tp_corrs': tp_correlations,
        'training_results': training_results,
        'dataset': dataset,
        'predicted_attention': predicted_attention,
        'seed': seed,
    }


def run_study_2(
    n_samples: int = 800,
    n_items: int = 5,
    n_personas: int = 3,
    n_seeds: int = 1,
    base_seed: int = RANDOM_SEED,
    verbose: bool = True
) -> Dict:
    """
    Run complete Study 2: Estimand Characterization.
    
    Evaluates self-consistency estimation under three regimes to demonstrate
    the dissociation between reference attention correlation and TP correlation.
    
    Args:
        n_samples: Number of individuals per condition
        n_items: Number of indicators
        n_personas: Number of latent personas
        n_seeds: Number of random seeds for stability (default=1 for single run)
        base_seed: Starting seed for reproducibility
        verbose: Whether to print detailed output
        
    Returns:
        Dictionary with results aggregated across regimes and seeds
    """
    start_time = time.time()
    
    if verbose:
        print("=" * 80)
        print("STUDY 2: ESTIMAND CHARACTERIZATION")
        print("Self-Consistent Estimation Under Varying Identification Regimes")
        print("=" * 80)
        print(f"\nSettings: N={n_samples}, J={n_items}, K={n_personas}, Seeds={n_seeds}")
    
    # Storage for results
    all_results = {regime.name: [] for regime in REGIMES}
    
    # Run each regime × seed combination
    for seed_idx in range(n_seeds):
        seed = base_seed + seed_idx
        
        if verbose and n_seeds > 1:
            print(f"\n{'═' * 80}")
            print(f"SEED {seed_idx + 1}/{n_seeds} (seed={seed})")
            print(f"{'═' * 80}")
        
        for regime in REGIMES:
            result = run_single_condition(
                regime=regime,
                n_samples=n_samples,
                n_items=n_items,
                n_personas=n_personas,
                seed=seed,
                verbose=verbose
            )
            all_results[regime.name].append(result)
    
    # -------------------------------------------------------------------------
    # Aggregate results across seeds
    # -------------------------------------------------------------------------
    summary = {}
    for regime in REGIMES:
        regime_results = all_results[regime.name]
        summary[regime.name] = {
            'description': regime.description,
            'target_corr_mean': np.mean([r['target_corr'] for r in regime_results]),
            'target_corr_std': np.std([r['target_corr'] for r in regime_results]),
            'tp_corr_mean': np.mean([r['tp_corr'] for r in regime_results]),
            'tp_corr_std': np.std([r['tp_corr'] for r in regime_results]),
            'js_mean': np.mean([r['js_divergence'] for r in regime_results]),
            'js_std': np.std([r['js_divergence'] for r in regime_results]),
            'n_runs': len(regime_results),
        }
    
    # -------------------------------------------------------------------------
    # Print summary table
    # -------------------------------------------------------------------------
    if verbose:
        elapsed = time.time() - start_time
        
        print("\n")
        print("=" * 80)
        print("STUDY 2 SUMMARY: Estimand Characterization Results")
        print("=" * 80)
        print()
        
        # Header
        print(f"{'Regime':<20} {'Target Corr':>14} {'TP Corr':>14} {'JS Div':>12}")
        print("─" * 65)
        
        # Results rows
        for regime in REGIMES:
            s = summary[regime.name]
            if n_seeds > 1:
                target_str = f"{s['target_corr_mean']:.3f} ± {s['target_corr_std']:.3f}"
                tp_str = f"{s['tp_corr_mean']:.3f} ± {s['tp_corr_std']:.3f}"
                js_str = f"{s['js_mean']:.4f}"
            else:
                target_str = f"{s['target_corr_mean']:.3f}"
                tp_str = f"{s['tp_corr_mean']:.3f}"
                js_str = f"{s['js_mean']:.4f}"
            
            print(f"{regime.name:<20} {target_str:>14} {tp_str:>14} {js_str:>12}")
        
        print("─" * 65)
        print()
        
        # Interpretation
        print("INTERPRETATION:")
        print("  • Target Corr: Alignment with self-consistency objective (response profile)")
        print("  • TP Corr:     Alignment with generating attention (ground truth)")
        print("  • JS Div:      Distribution distance to target (lower = better fit)")
        print()
        print("KEY FINDING:")
        print("  Self-consistency succeeds at its optimization objective regardless of regime")
        print("  (high Target Corr, low JS). TP Corr varies by regime:")
        print()
        print("  • Identifiable:    Target ≈ TP (response composition reveals attention)")
        print("  • Realistic Soft:  Target > TP (partial alignment)")
        print("  • Realistic Hard:  Target >> TP (estimands are distinct)")
        print()
        
        # Check if pattern matches theory
        id_result = summary['identifiable']
        hard_result = summary['realistic_hard']
        
        estimand_separation = (
            id_result['tp_corr_mean'] > 0.7 and
            hard_result['tp_corr_mean'] < id_result['tp_corr_mean'] - 0.3 and
            hard_result['target_corr_mean'] > 0.7
        )
        
        if estimand_separation:
            print("  ✓ ESTIMAND SEPARATION CONFIRMED")
            print(f"    Identifiable TP corr:    {id_result['tp_corr_mean']:.3f}")
            print(f"    Realistic Hard TP corr:  {hard_result['tp_corr_mean']:.3f}")
            print(f"    (difference demonstrates estimand ≠ ground truth under violation)")
        else:
            print("  ⚠ Review results - pattern may differ from expected")
        
        print()
        print(f"Total runtime: {elapsed:.1f}s")
    
    return {
        'summary': summary,
        'all_results': all_results,
        'settings': {
            'n_samples': n_samples,
            'n_items': n_items,
            'n_personas': n_personas,
            'n_seeds': n_seeds,
            'base_seed': base_seed,
        }
    }


def export_results_table(results: Dict, output_path: str = None) -> pd.DataFrame:
    """
    Export Study 2 results as a formatted table for manuscript.
    
    Args:
        results: Output from run_study_2()
        output_path: Optional path to save CSV
        
    Returns:
        pandas DataFrame with formatted results
    """
    summary = results['summary']
    n_seeds = results['settings']['n_seeds']
    
    rows = []
    for regime_name, s in summary.items():
        row = {
            'Regime': regime_name,
            'Description': s['description'],
            'Target_Corr': s['target_corr_mean'],
            'TP_Corr': s['tp_corr_mean'],
            'JS_Divergence': s['js_mean'],
        }
        if n_seeds > 1:
            row['Target_Corr_SD'] = s['target_corr_std']
            row['TP_Corr_SD'] = s['tp_corr_std']
            row['JS_SD'] = s['js_std']
        rows.append(row)
    
    df = pd.DataFrame(rows)
    
    if output_path:
        df.to_csv(output_path, index=False)
        print(f"Results saved to: {output_path}")
    
    return df


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Study 2: Estimand Characterization - Self-Consistency Under Varying Regimes"
    )
    parser.add_argument('--n_samples', type=int, default=800,
                        help='Number of samples per condition (default: 800)')
    parser.add_argument('--n_items', type=int, default=5,
                        help='Number of items/indicators (default: 5)')
    parser.add_argument('--n_personas', type=int, default=3,
                        help='Number of latent personas (default: 3)')
    parser.add_argument('--seeds', type=int, default=1,
                        help='Number of random seeds for stability (default: 1)')
    parser.add_argument('--base_seed', type=int, default=RANDOM_SEED,
                        help=f'Base random seed (default: {RANDOM_SEED})')
    parser.add_argument('--output', type=str, default=None,
                        help='Path to save results CSV (optional)')
    parser.add_argument('--quiet', action='store_true',
                        help='Suppress detailed output')
    
    # Handle Jupyter/IPython environment
    if 'ipykernel_launcher.py' in sys.argv[0]:
        args = parser.parse_args(args=[])
    else:
        args = parser.parse_args()
    
    # Run Study 2
    results = run_study_2(
        n_samples=args.n_samples,
        n_items=args.n_items,
        n_personas=args.n_personas,
        n_seeds=args.seeds,
        base_seed=args.base_seed,
        verbose=not args.quiet
    )
    
    # Export results if requested
    if args.output:
        export_results_table(results, args.output)
