"""
CFASA Study 3: Robustness Testing - Publication Version

Comprehensive robustness evaluation under supervised mode with identifiable DGP.
Tests whether GT recovery remains stable across stress conditions.

Test battery:
1. Sample size variation (N=400-1500)
2. Noise tolerance (σ²=0.00-0.50)
3. Cross-validation stability (5-fold)
4. Initialization sensitivity (10 random seeds)
5. Model misspecification (K=3 architecture on K=4 data)
6. Distributional violations (skewness, mixture errors)
7. Outlier contamination (5-15%)

All tests use supervised mode with identifiable DGP.
Metric: Correlation between estimated and generating attention (GT correlation).

Usage:
    python run_study_3_robustness.py

Author: Jonathan Lee
Version: 1.0.0 (Modularized)
"""

import numpy as np
import time
from typing import Dict, List, Optional
import warnings
warnings.filterwarnings('ignore')

# Import from modularized CFASA suite
from cfasa_config import DEVICE, set_reproducible_state, RANDOM_SEED
from cfasa_data import UniversalPersonaGenerator
from cfasa_training import CFASATrainer
from cfasa_utils import evaluate_attention_recovery

# ============================================================================
# Utility Functions
# ============================================================================

def compute_mean_gt_correlation(predicted: np.ndarray, true: np.ndarray) -> float:
    """Compute mean individual-level GT correlation."""
    correlations = []
    for i in range(len(predicted)):
        if np.std(predicted[i]) > 1e-8 and np.std(true[i]) > 1e-8:
            corr = np.corrcoef(predicted[i], true[i])[0, 1]
            if not np.isnan(corr):
                correlations.append(corr)
    return np.mean(correlations) if correlations else 0.0

def summarize_performance(label: str, correlations: List[float]):
    """Print summary statistics for a test condition."""
    mean_r = np.mean(correlations)
    std_r = np.std(correlations) if len(correlations) > 1 else 0.0
    print(f"  {label}: r = {mean_r:.3f} (SD = {std_r:.3f})")
    return {'mean': mean_r, 'std': std_r, 'n': len(correlations)}

def train_and_evaluate(responses: np.ndarray, 
                       true_attention: np.ndarray,
                       n_items: int = 5,
                       n_epochs: int = 200,
                       seed: int = RANDOM_SEED,
                       verbose: bool = False) -> float:
    """Train CFASA in supervised mode and return GT correlation."""
    set_reproducible_state(seed)
    
    trainer = CFASATrainer(
        n_items=n_items,
        n_attention_heads=3,
        mode='supervised'
    )
    
    trainer.train(
        responses=responses,
        true_attention_patterns=true_attention,
        n_epochs=n_epochs,
        verbose=verbose
    )
    
    predictions = trainer.predict_attention_patterns(responses)
    gt_corr = compute_mean_gt_correlation(
        predictions['attention_weights'], 
        true_attention
    )
    
    return gt_corr

# ============================================================================
# Data Generation Helpers
# ============================================================================

def generate_identifiable_data(n_samples: int, n_items: int = 5, n_personas: int = 3,
                                noise_variance: float = 0.05**2,
                                seed: int = RANDOM_SEED) -> Dict:
    """Generate data under identifiable DGP."""
    generator = UniversalPersonaGenerator(n_items=n_items, n_personas=n_personas)
    return generator.generate_dataset(
        n_samples=n_samples,
        noise_variance=noise_variance,
        dgp_mode='identifiable',
        seed=seed
    )

def generate_with_skewed_errors(n_samples: int, n_items: int = 5, n_personas: int = 3,
                                 seed: int = RANDOM_SEED) -> Dict:
    """Generate identifiable data with skewed (non-normal) errors."""
    # First generate standard identifiable data
    data = generate_identifiable_data(n_samples, n_items, n_personas, seed=seed)
    
    # Add skewed perturbation to responses
    rng = np.random.default_rng(seed + 1000)
    skew_noise = 0.3 * (rng.normal(0, 1, data['responses'].shape)**2 - 1.0)
    data['responses'] = np.clip(data['responses'] + skew_noise, 0, None)
    
    return data

def generate_with_mixture_errors(n_samples: int, n_items: int = 5, n_personas: int = 3,
                                  seed: int = RANDOM_SEED) -> Dict:
    """Generate identifiable data with mixture (heavy-tailed) errors."""
    data = generate_identifiable_data(n_samples, n_items, n_personas, seed=seed)
    
    rng = np.random.default_rng(seed + 2000)
    
    # 30% of observations get inflated noise
    contaminated = rng.random(data['responses'].shape) < 0.3
    extra_noise = rng.normal(0, 0.3, data['responses'].shape)
    data['responses'] = np.where(
        contaminated,
        data['responses'] + extra_noise,
        data['responses']
    )
    data['responses'] = np.clip(data['responses'], 0, None)
    
    return data

def add_outliers(responses: np.ndarray, contamination_rate: float = 0.10,
                 seed: int = RANDOM_SEED) -> np.ndarray:
    """Add outlier contamination to responses."""
    rng = np.random.default_rng(seed)
    X_contaminated = responses.copy()
    n_samples, n_items = responses.shape
    
    n_outliers = int(n_samples * contamination_rate)
    outlier_indices = rng.choice(n_samples, size=n_outliers, replace=False)
    
    for idx in outlier_indices:
        # Random extreme values
        X_contaminated[idx] = rng.uniform(
            responses.min() - 2 * responses.std(),
            responses.max() + 2 * responses.std(),
            size=n_items
        )
    
    return np.clip(X_contaminated, 0, None)

# ============================================================================
# Test 1: Sample Size Robustness
# ============================================================================

def test_sample_size(sample_sizes: List[int] = [400, 600, 800, 1000, 1500],
                     n_items: int = 5,
                     base_seed: int = RANDOM_SEED,
                     verbose: bool = True) -> Dict:
    """Test robustness across sample sizes."""
    if verbose:
        print("\nTest 1: Sample Size Robustness")
        print("-" * 50)
    
    results = []
    for N in sample_sizes:
        data = generate_identifiable_data(n_samples=N, n_items=n_items, seed=base_seed)
        corr = train_and_evaluate(
            data['responses'],
            data['true_attention_patterns'],
            n_items=n_items,
            seed=base_seed
        )
        results.append({'N': N, 'mean': corr, 'std': 0.0})
        if verbose:
            print(f"  N = {N:4d}: r = {corr:.3f}")
    
    return results

# ============================================================================
# Test 2: Noise Tolerance
# ============================================================================

def test_noise_tolerance(noise_levels: List[float] = [0.00, 0.05, 0.10, 0.20, 0.35, 0.50],
                         n_samples: int = 800,
                         n_items: int = 5,
                         base_seed: int = RANDOM_SEED,
                         verbose: bool = True) -> Dict:
    """Test robustness across noise levels (σ²)."""
    if verbose:
        print("\nTest 2: Noise Tolerance")
        print("-" * 50)
    
    results = []
    for sigma2 in noise_levels:
        data = generate_identifiable_data(
            n_samples=n_samples, 
            n_items=n_items,
            noise_variance=sigma2,
            seed=base_seed
        )
        corr = train_and_evaluate(
            data['responses'],
            data['true_attention_patterns'],
            n_items=n_items,
            seed=base_seed
        )
        results.append({'sigma2': sigma2, 'mean': corr, 'std': 0.0})
        if verbose:
            print(f"  σ² = {sigma2:.2f}: r = {corr:.3f}")
    
    return results

# ============================================================================
# Test 3: Cross-Validation Stability
# ============================================================================

def test_cv_stability(n_folds: int = 5,
                      n_samples: int = 800,
                      n_items: int = 5,
                      base_seed: int = RANDOM_SEED,
                      verbose: bool = True) -> Dict:
    """Test estimation stability via cross-validation."""
    if verbose:
        print("\nTest 3: Cross-Validation Stability")
        print("-" * 50)
    
    data = generate_identifiable_data(n_samples=n_samples, n_items=n_items, seed=base_seed)
    
    fold_correlations = []
    indices = np.arange(n_samples)
    rng = np.random.default_rng(base_seed)
    rng.shuffle(indices)
    
    fold_size = n_samples // n_folds
    
    for fold in range(n_folds):
        # Hold out one fold for testing
        test_start = fold * fold_size
        test_end = test_start + fold_size
        test_idx = indices[test_start:test_end]
        train_idx = np.concatenate([indices[:test_start], indices[test_end:]])
        
        # Train on training fold
        trainer = CFASATrainer(n_items=n_items, n_attention_heads=3, mode='supervised')
        trainer.train(
            responses=data['responses'][train_idx],
            true_attention_patterns=data['true_attention_patterns'][train_idx],
            n_epochs=200,
            verbose=False
        )
        
        # Evaluate on held-out fold
        predictions = trainer.predict_attention_patterns(data['responses'][test_idx])
        fold_corr = compute_mean_gt_correlation(
            predictions['attention_weights'],
            data['true_attention_patterns'][test_idx]
        )
        fold_correlations.append(fold_corr)
        
        if verbose:
            print(f"  Fold {fold+1}: r = {fold_corr:.3f}")
    
    mean_corr = np.mean(fold_correlations)
    std_corr = np.std(fold_correlations)
    
    if verbose:
        print(f"  Overall: r = {mean_corr:.3f} (SD = {std_corr:.3f})")
    
    return {'mean': mean_corr, 'std': std_corr, 'folds': fold_correlations}

# ============================================================================
# Test 4: Initialization Sensitivity
# ============================================================================

def test_initialization_sensitivity(n_inits: int = 10,
                                     n_samples: int = 800,
                                     n_items: int = 5,
                                     base_seed: int = RANDOM_SEED,
                                     verbose: bool = True) -> Dict:
    """Test sensitivity to random initialization."""
    if verbose:
        print("\nTest 4: Initialization Sensitivity")
        print("-" * 50)
    
    data = generate_identifiable_data(n_samples=n_samples, n_items=n_items, seed=base_seed)
    
    init_correlations = []
    for i in range(n_inits):
        seed_i = base_seed + i * 100
        corr = train_and_evaluate(
            data['responses'],
            data['true_attention_patterns'],
            n_items=n_items,
            seed=seed_i
        )
        init_correlations.append(corr)
        
        if verbose:
            print(f"  Init {i+1:2d}: r = {corr:.3f}")
    
    mean_corr = np.mean(init_correlations)
    std_corr = np.std(init_correlations)
    
    if verbose:
        print(f"  Overall: r = {mean_corr:.3f} (SD = {std_corr:.3f})")
    
    return {'mean': mean_corr, 'std': std_corr, 'inits': init_correlations}

# ============================================================================
# Test 5: Model Misspecification
# ============================================================================

def test_misspecification(n_samples: int = 800,
                          n_items: int = 5,
                          base_seed: int = RANDOM_SEED,
                          verbose: bool = True) -> Dict:
    """Test K=3 architecture on K=4 generating data."""
    if verbose:
        print("\nTest 5: Model Misspecification (K=3 on K=4 data)")
        print("-" * 50)
    
    results = {}
    
    # Generate data with K=4 personas
    generator_k4 = UniversalPersonaGenerator(n_items=n_items, n_personas=4)
    data_k4 = generator_k4.generate_dataset(
        n_samples=n_samples,
        dgp_mode='identifiable',
        seed=base_seed
    )
    
    # Train with K=3 architecture (misspecified)
    trainer = CFASATrainer(n_items=n_items, n_attention_heads=3, mode='supervised')
    trainer.train(
        responses=data_k4['responses'],
        true_attention_patterns=data_k4['true_attention_patterns'],
        n_epochs=200,
        verbose=False
    )
    
    predictions = trainer.predict_attention_patterns(data_k4['responses'])
    corr_misspec = compute_mean_gt_correlation(
        predictions['attention_weights'],
        data_k4['true_attention_patterns']
    )
    
    results['k3_on_k4'] = corr_misspec
    
    if verbose:
        print(f"  K=3 architecture on K=4 data: r = {corr_misspec:.3f}")
    
    # Also test correct specification as baseline
    generator_k3 = UniversalPersonaGenerator(n_items=n_items, n_personas=3)
    data_k3 = generator_k3.generate_dataset(
        n_samples=n_samples,
        dgp_mode='identifiable',
        seed=base_seed
    )
    
    corr_correct = train_and_evaluate(
        data_k3['responses'],
        data_k3['true_attention_patterns'],
        n_items=n_items,
        seed=base_seed
    )
    
    results['k3_on_k3'] = corr_correct
    results['degradation'] = corr_correct - corr_misspec
    
    if verbose:
        print(f"  K=3 architecture on K=3 data: r = {corr_correct:.3f}")
        print(f"  Degradation due to misspec: Δr = {results['degradation']:.3f}")
    
    return results

# ============================================================================
# Test 6: Distributional Violations
# ============================================================================

def test_distributional_violations(n_samples: int = 800,
                                    n_items: int = 5,
                                    base_seed: int = RANDOM_SEED,
                                    verbose: bool = True) -> Dict:
    """Test robustness to non-normal error distributions."""
    if verbose:
        print("\nTest 6: Distributional Violations")
        print("-" * 50)
    
    results = {}
    
    # Baseline: Normal errors
    data_normal = generate_identifiable_data(n_samples, n_items, seed=base_seed)
    corr_normal = train_and_evaluate(
        data_normal['responses'],
        data_normal['true_attention_patterns'],
        n_items=n_items,
        seed=base_seed
    )
    results['normal'] = corr_normal
    
    if verbose:
        print(f"  Normal errors: r = {corr_normal:.3f}")
    
    # Skewed errors
    data_skewed = generate_with_skewed_errors(n_samples, n_items, seed=base_seed)
    corr_skewed = train_and_evaluate(
        data_skewed['responses'],
        data_skewed['true_attention_patterns'],
        n_items=n_items,
        seed=base_seed
    )
    results['skewed'] = corr_skewed
    
    if verbose:
        print(f"  Skewed errors: r = {corr_skewed:.3f}")
    
    # Mixture (heavy-tailed) errors
    data_mixture = generate_with_mixture_errors(n_samples, n_items, seed=base_seed)
    corr_mixture = train_and_evaluate(
        data_mixture['responses'],
        data_mixture['true_attention_patterns'],
        n_items=n_items,
        seed=base_seed
    )
    results['mixture'] = corr_mixture
    
    if verbose:
        print(f"  Mixture errors: r = {corr_mixture:.3f}")
    
    return results

# ============================================================================
# Test 7: Outlier Contamination
# ============================================================================

def test_outlier_contamination(contamination_rates: List[float] = [0.05, 0.10, 0.15],
                                n_samples: int = 800,
                                n_items: int = 5,
                                base_seed: int = RANDOM_SEED,
                                verbose: bool = True) -> Dict:
    """Test robustness to outlier contamination."""
    if verbose:
        print("\nTest 7: Outlier Contamination")
        print("-" * 50)
    
    data = generate_identifiable_data(n_samples, n_items, seed=base_seed)
    
    results = {}
    
    # Baseline (no outliers)
    corr_clean = train_and_evaluate(
        data['responses'],
        data['true_attention_patterns'],
        n_items=n_items,
        seed=base_seed
    )
    results['clean'] = corr_clean
    
    if verbose:
        print(f"  Clean (0%): r = {corr_clean:.3f}")
    
    for rate in contamination_rates:
        X_contaminated = add_outliers(data['responses'], rate, seed=base_seed)
        corr = train_and_evaluate(
            X_contaminated,
            data['true_attention_patterns'],
            n_items=n_items,
            seed=base_seed
        )
        results[f'{int(rate*100)}pct'] = corr
        
        if verbose:
            print(f"  Outliers ({int(rate*100)}%): r = {corr:.3f}")
    
    return results

# ============================================================================
# Comprehensive Testing
# ============================================================================

def run_complete_robustness_battery(n_items: int = 5,
                                     base_seed: int = RANDOM_SEED,
                                     verbose: bool = True) -> Dict:
    """Run all robustness tests."""
    
    print("=" * 70)
    print("CFASA STUDY 3: ROBUSTNESS TESTING")
    print("=" * 70)
    print(f"Mode: Supervised | DGP: Identifiable | Items: {n_items}")
    print("=" * 70)
    
    start_time = time.time()
    results = {}
    
    # Test 1: Sample Size
    results['sample_size'] = test_sample_size(
        sample_sizes=[400, 600, 800, 1000, 1500],
        n_items=n_items,
        base_seed=base_seed,
        verbose=verbose
    )
    
    # Test 2: Noise Tolerance
    results['noise'] = test_noise_tolerance(
        noise_levels=[0.00, 0.05, 0.10, 0.20, 0.35, 0.50],
        n_items=n_items,
        base_seed=base_seed,
        verbose=verbose
    )
    
    # Test 3: CV Stability
    results['cv'] = test_cv_stability(
        n_folds=5,
        n_items=n_items,
        base_seed=base_seed,
        verbose=verbose
    )
    
    # Test 4: Initialization Sensitivity
    results['init'] = test_initialization_sensitivity(
        n_inits=10,
        n_items=n_items,
        base_seed=base_seed,
        verbose=verbose
    )
    
    # Test 5: Misspecification
    results['misspec'] = test_misspecification(
        n_items=n_items,
        base_seed=base_seed,
        verbose=verbose
    )
    
    # Test 6: Distributional Violations
    results['distributional'] = test_distributional_violations(
        n_items=n_items,
        base_seed=base_seed,
        verbose=verbose
    )
    
    # Test 7: Outlier Contamination
    results['outliers'] = test_outlier_contamination(
        n_items=n_items,
        base_seed=base_seed,
        verbose=verbose
    )
    
    elapsed = time.time() - start_time
    
    # Summary
    print("\n" + "=" * 70)
    print("ROBUSTNESS SUMMARY")
    print("=" * 70)
    
    # Sample size
    size_corrs = [r['mean'] for r in results['sample_size']]
    print(f"\nSample Size (N=400-1500):")
    print(f"  Range: {min(size_corrs):.3f} - {max(size_corrs):.3f}")
    print(f"  Minimum ≥ 0.95: {'✓' if min(size_corrs) >= 0.95 else '✗'}")
    
    # Noise
    noise_corrs = [r['mean'] for r in results['noise']]
    noise_at_high = results['noise'][-1]['mean']  # σ²=0.50
    print(f"\nNoise Tolerance (σ²=0.00-0.50):")
    print(f"  At σ²=0.50: {noise_at_high:.3f}")
    print(f"  Graceful degradation (≥0.85): {'✓' if noise_at_high >= 0.85 else '✗'}")
    
    # Stability
    cv_std = results['cv']['std']
    init_std = results['init']['std']
    print(f"\nEstimation Stability:")
    print(f"  CV std: {cv_std:.4f}")
    print(f"  Init std: {init_std:.4f}")
    print(f"  High stability (std < 0.02): {'✓' if max(cv_std, init_std) < 0.02 else '✗'}")
    
    # Misspecification
    misspec_corr = results['misspec']['k3_on_k4']
    print(f"\nMisspecification (K=3 on K=4):")
    print(f"  Performance: {misspec_corr:.3f}")
    print(f"  Robust (≥0.90): {'✓' if misspec_corr >= 0.90 else '✗'}")
    
    # Distributional
    dist_min = min(results['distributional']['skewed'], results['distributional']['mixture'])
    print(f"\nDistributional Violations:")
    print(f"  Skewed: {results['distributional']['skewed']:.3f}")
    print(f"  Mixture: {results['distributional']['mixture']:.3f}")
    print(f"  Robust (≥0.90): {'✓' if dist_min >= 0.90 else '✗'}")
    
    # Outliers
    outlier_15 = results['outliers'].get('15pct', 0)
    print(f"\nOutlier Contamination:")
    print(f"  At 15%: {outlier_15:.3f}")
    print(f"  Robust (≥0.85): {'✓' if outlier_15 >= 0.85 else '✗'}")
    
    # Overall
    criteria = [
        min(size_corrs) >= 0.95,
        noise_at_high >= 0.85,
        max(cv_std, init_std) < 0.02,
        misspec_corr >= 0.90,
        dist_min >= 0.90,
        outlier_15 >= 0.85
    ]
    passed = sum(criteria)
    
    print(f"\n{'=' * 70}")
    print(f"OVERALL: {passed}/6 criteria passed")
    if passed >= 5:
        print("✓ CFASA demonstrates robust performance across stress conditions")
    elif passed >= 4:
        print("~ CFASA shows acceptable robustness with minor sensitivity")
    else:
        print("✗ Some robustness concerns warrant further investigation")
    print(f"Total time: {elapsed:.1f}s")
    print("=" * 70)
    
    results['summary'] = {
        'criteria_passed': passed,
        'total_criteria': 6,
        'elapsed_time': elapsed
    }
    
    return results

# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    results = run_complete_robustness_battery(
        n_items=5,
        base_seed=RANDOM_SEED,
        verbose=True
    )
