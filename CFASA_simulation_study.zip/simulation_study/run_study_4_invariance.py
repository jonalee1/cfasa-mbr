"""
CFASA Simulation Study 4: Response-Style Invariance
=====================================================

This study tests whether CFASA attention patterns are invariant to 
response-style contamination that commonly confounds measurement.

KEY INSIGHT: Uniform global transformations (x → αx + c applied identically
to all items for all people) don't break CFA either. The real problems are:

  1. PERSON-SPECIFIC acquiescence (each person has different shift)
  2. ITEM-DIRECTION effects (positive/negative items affected differently)  
  3. HETEROGENEOUS response styles across individuals

Design:
  - Generate N=600 individuals with K=3 known personas
  - Apply REALISTIC response-style contaminations:
    • Person-specific random intercepts (acquiescence heterogeneity)
    • Item-direction acquiescence (pos/neg keyed items shift oppositely)
    • Extreme response style (person-specific scale factors)
  - Compare CFASA attention stability vs CFA loading/score stability

Expected Results:
  - CFASA attention: High within-person correlation (shape preserved)
  - CFA: Loading pattern distortion, reduced score reliability

Usage:
    python run_study_4_invariance.py  

Author: Jonathan Lee
Version: 2.0.0 (Realistic response-style manipulations)
"""

import numpy as np
from typing import Dict, List, Tuple
from sklearn.decomposition import FactorAnalysis
from scipy.stats import pearsonr
import warnings

from cfasa_config import RANDOM_SEED, set_reproducible_state
from cfasa_data import UniversalPersonaGenerator
from cfasa_training import CFASATrainer

warnings.filterwarnings('ignore')

# =============================================================================
# REALISTIC RESPONSE-STYLE TRANSFORMATIONS
# =============================================================================

def apply_person_specific_acquiescence(X: np.ndarray, 
                                        shift_sd: float = 1.0,
                                        seed: int = RANDOM_SEED) -> Tuple[np.ndarray, np.ndarray]:
    """
    Simulate PERSON-SPECIFIC acquiescence bias.
    
    Each person has their own intercept c_i ~ N(0, shift_sd²).
    This is the realistic scenario: some people use higher portions
    of the scale than others, independent of content.
    
    CFASA should be invariant (x_i + c_i still has same shape).
    CFA covariance structure is distorted by between-person variance.
    
    Returns: (transformed X, person shifts for analysis)
    """
    rng = np.random.default_rng(seed)
    N = X.shape[0]
    
    # Each person gets their own shift
    person_shifts = rng.normal(0, shift_sd, N)
    
    X_transformed = X + person_shifts[:, np.newaxis]
    
    return X_transformed, person_shifts


def apply_item_direction_acquiescence(X: np.ndarray,
                                       item_directions: np.ndarray = None,
                                       acquiescence_strength: float = 1.0,
                                       seed: int = RANDOM_SEED) -> np.ndarray:
    """
    Simulate ITEM-DIRECTION acquiescence bias.
    
    Acquiescent responders say "yes" to everything:
      - Positively-keyed items: inflated (+c)
      - Negatively-keyed items: also inflated (+c) but these SHOULD be low
    
    This is the classic "yea-saying" bias that contaminates scales
    with mixed item directions.
    
    item_directions: +1 for positive items, -1 for negative items
    
    For items where direction = -1, acquiescence INCREASES the score
    even though the "true" response should be low.
    """
    rng = np.random.default_rng(seed)
    N, J = X.shape
    
    if item_directions is None:
        # Default: first 3 items positive, last 2 negative
        item_directions = np.array([1, 1, 1, -1, -1])
    
    # Each person has acquiescence tendency
    person_acquiescence = rng.uniform(0, acquiescence_strength, N)
    
    X_transformed = X.copy()
    for j in range(J):
        if item_directions[j] == -1:
            # Negative items: acquiescence inflates scores inappropriately
            X_transformed[:, j] = X[:, j] + person_acquiescence
        else:
            # Positive items: acquiescence inflates scores (appropriate direction)
            X_transformed[:, j] = X[:, j] + person_acquiescence
    
    return X_transformed


def apply_person_specific_scale(X: np.ndarray,
                                 scale_sd: float = 0.3,
                                 seed: int = RANDOM_SEED) -> Tuple[np.ndarray, np.ndarray]:
    """
    Simulate PERSON-SPECIFIC extreme response style.
    
    Each person has their own scale factor α_i ~ LogNormal.
    Some people use extremes (α > 1), others are moderate (α < 1).
    
    CFASA should be invariant (shape preserved under scaling).
    CFA affected by heterogeneous variances across persons.
    
    Returns: (transformed X, person scales for analysis)
    """
    rng = np.random.default_rng(seed)
    N = X.shape[0]
    
    # Log-normal ensures positive scales, centered around 1
    person_scales = rng.lognormal(0, scale_sd, N)
    
    X_transformed = X * person_scales[:, np.newaxis]
    
    return X_transformed, person_scales


def apply_combined_person_styles(X: np.ndarray,
                                  shift_sd: float = 0.8,
                                  scale_sd: float = 0.25,
                                  seed: int = RANDOM_SEED) -> Tuple[np.ndarray, Dict]:
    """
    Combined person-specific response styles.
    
    Each person has:
      - Their own intercept (acquiescence)
      - Their own scale (extreme responding)
    
    X_i → α_i * X_i + c_i
    
    This is the most realistic scenario.
    """
    rng = np.random.default_rng(seed + 999)
    N = X.shape[0]
    
    person_shifts = rng.normal(0, shift_sd, N)
    person_scales = rng.lognormal(0, scale_sd, N)
    
    X_transformed = X * person_scales[:, np.newaxis] + person_shifts[:, np.newaxis]
    
    return X_transformed, {'shifts': person_shifts, 'scales': person_scales}


# =============================================================================
# CFA UTILITIES
# =============================================================================

def run_cfa(X: np.ndarray, n_factors: int = 1) -> Dict:
    """
    Run single-factor CFA using sklearn's FactorAnalysis.
    
    Returns loadings, factor scores, and fit statistics.
    """
    fa = FactorAnalysis(n_components=n_factors, random_state=RANDOM_SEED)
    scores = fa.fit_transform(X)
    loadings = fa.components_.flatten()  # Shape: (n_factors, n_items) -> (n_items,)
    
    # Compute reconstruction and variance explained
    X_reconstructed = scores @ fa.components_ + fa.mean_
    residuals = X - X_reconstructed
    total_var = np.var(X, axis=0).sum()
    explained_var = 1 - np.var(residuals, axis=0).sum() / total_var
    
    return {
        'loadings': loadings,
        'scores': scores.flatten(),
        'explained_variance': explained_var,
        'mean': fa.mean_
    }


def compute_loading_drift(loadings_ref: np.ndarray, 
                          loadings_test: np.ndarray) -> Dict:
    """
    Compute metrics of loading drift between conditions.
    """
    # Absolute difference
    abs_diff = np.abs(loadings_ref - loadings_test)
    
    # Correlation (pattern similarity)
    corr, _ = pearsonr(loadings_ref, loadings_test)
    
    # Congruence coefficient (Tucker)
    numer = np.sum(loadings_ref * loadings_test)
    denom = np.sqrt(np.sum(loadings_ref**2) * np.sum(loadings_test**2))
    tucker = numer / denom if denom > 0 else 0
    
    return {
        'mean_abs_diff': np.mean(abs_diff),
        'max_abs_diff': np.max(abs_diff),
        'pattern_correlation': corr,
        'tucker_congruence': tucker
    }


# =============================================================================
# MAIN STUDY FUNCTION
# =============================================================================

def run_study4_invariance(n_samples: int = 600,
                          n_items: int = 5,
                          n_personas: int = 3,
                          verbose: bool = True) -> Dict:
    """
    Run Study 4: Response-Style Invariance demonstration.
    
    Tests whether CFASA attention is invariant to REALISTIC response-style
    contaminations that actually cause problems in measurement.
    
    Key difference from v1: Person-specific (not global) transformations.
    """
    set_reproducible_state(RANDOM_SEED)
    
    if verbose:
        print("=" * 80)
        print("STUDY 4: RESPONSE-STYLE INVARIANCE (v2 - Realistic)")
        print("=" * 80)
        print(f"\nDesign: N={n_samples}, J={n_items}, K={n_personas}")
        print("Testing PERSON-SPECIFIC response styles (not uniform global transforms)")
    
    # =========================================================================
    # 1. GENERATE BASE DATASET
    # =========================================================================
    if verbose:
        print("\n" + "-" * 80)
        print("1. Generating Base Dataset (Identifiable DGP)")
        print("-" * 80)
    
    generator = UniversalPersonaGenerator(n_items=n_items, n_personas=n_personas)
    base_data = generator.generate_dataset(
        n_samples=n_samples,
        dgp_mode='identifiable',
        seed=RANDOM_SEED
    )
    
    X_clean = base_data['responses']
    true_attention = base_data['true_attention_patterns']
    persona_assignments = base_data['individual_assignments']
    
    if verbose:
        print(f"  Base responses: shape {X_clean.shape}")
        print(f"  Response range: [{X_clean.min():.2f}, {X_clean.max():.2f}]")
        print(f"  Mean: {X_clean.mean():.2f}, SD: {X_clean.std():.2f}")
    
    # =========================================================================
    # 2. CREATE PERSON-SPECIFIC TRANSFORMATIONS
    # =========================================================================
    if verbose:
        print("\n" + "-" * 80)
        print("2. Creating PERSON-SPECIFIC Response-Style Contaminations")
        print("-" * 80)
    
    # Each transformation is person-specific (not uniform!)
    X_acquiescence, person_shifts = apply_person_specific_acquiescence(
        X_clean, shift_sd=1.0, seed=RANDOM_SEED
    )
    X_extreme, person_scales = apply_person_specific_scale(
        X_clean, scale_sd=0.3, seed=RANDOM_SEED + 1
    )
    X_combined, style_params = apply_combined_person_styles(
        X_clean, shift_sd=0.8, scale_sd=0.25, seed=RANDOM_SEED + 2
    )
    
    transformations = {
        'clean': X_clean.copy(),
        'acquiescence': X_acquiescence,
        'extreme': X_extreme,
        'combined': X_combined
    }
    
    if verbose:
        print("\n  Person-Specific Acquiescence (c_i ~ N(0, 1.0²)):")
        print(f"    Shift range: [{person_shifts.min():.2f}, {person_shifts.max():.2f}]")
        print(f"    Result range: [{X_acquiescence.min():.2f}, {X_acquiescence.max():.2f}]")
        
        print("\n  Person-Specific Extreme Style (α_i ~ LogNormal):")
        print(f"    Scale range: [{person_scales.min():.2f}, {person_scales.max():.2f}]")
        print(f"    Result range: [{X_extreme.min():.2f}, {X_extreme.max():.2f}]")
        
        print("\n  Combined Person Styles (α_i * X + c_i):")
        print(f"    Result range: [{X_combined.min():.2f}, {X_combined.max():.2f}]")
    
    # =========================================================================
    # 3. TRAIN CFASA ON EACH CONDITION SEPARATELY
    # =========================================================================
    if verbose:
        print("\n" + "-" * 80)
        print("3. Training CFASA on Each Condition (Self-Consistency Mode)")
        print("-" * 80)
    
    cfasa_attention = {}
    
    for cond_name, X_cond in transformations.items():
        if verbose:
            print(f"\n  Training on {cond_name}...")
        
        trainer = CFASATrainer(
            n_items=n_items, 
            n_attention_heads=3,
            mode='self_consistency',
            alpha_tempering=0.5
        )
        
        trainer.train(
            responses=X_cond,
            n_epochs=200,
            learning_rate=0.002,
            batch_size=128,
            verbose=False
        )
        
        cfasa_attention[cond_name] = trainer.predict_attention_patterns(X_cond)['attention_weights']
        
        if verbose:
            print(f"    Done. Attention entropy: {-np.sum(cfasa_attention[cond_name] * np.log(cfasa_attention[cond_name] + 1e-8), axis=1).mean():.3f}")
    
    # =========================================================================
    # 4. COMPUTE WITHIN-PERSON CFASA STABILITY
    # =========================================================================
    if verbose:
        print("\n" + "-" * 80)
        print("4. CFASA Attention Stability Across Contaminations")
        print("-" * 80)
    
    cfasa_stability = {}
    reference = 'clean'
    
    for cond in transformations.keys():
        if cond == reference:
            continue
        
        # Correlate attention patterns for same individuals across conditions
        corrs = []
        for i in range(n_samples):
            a_ref = cfasa_attention[reference][i]
            a_test = cfasa_attention[cond][i]
            r, _ = pearsonr(a_ref, a_test)
            if not np.isnan(r):
                corrs.append(r)
        
        cfasa_stability[f'{reference}_vs_{cond}'] = {
            'mean_r': np.mean(corrs),
            'sd_r': np.std(corrs),
            'min_r': np.min(corrs),
            'pct_above_90': np.mean(np.array(corrs) > 0.90) * 100
        }
    
    if verbose:
        print("\n  Within-Person Attention Correlation (Clean vs Contaminated):")
        print(f"  {'Comparison':<25} {'Mean r':>10} {'SD':>10} {'Min':>10} {'% > 0.90':>10}")
        print("  " + "-" * 65)
        for comp, stats in cfasa_stability.items():
            print(f"  {comp:<25} {stats['mean_r']:>10.3f} {stats['sd_r']:>10.3f} "
                  f"{stats['min_r']:>10.3f} {stats['pct_above_90']:>10.1f}%")
    
    # =========================================================================
    # 5. RUN CFA ON EACH CONDITION
    # =========================================================================
    if verbose:
        print("\n" + "-" * 80)
        print("5. CFA Results by Condition (Separate Models)")
        print("-" * 80)
    
    cfa_results = {}
    for cond, X in transformations.items():
        cfa_results[cond] = run_cfa(X, n_factors=1)
    
    if verbose:
        print("\n  CFA Loadings by Condition:")
        print(f"  {'Condition':<15}", end="")
        for j in range(n_items):
            print(f"  Item {j+1:>2}", end="")
        print(f"  {'Var Expl':>10}")
        print("  " + "-" * (15 + n_items*9 + 12))
        
        for cond, results in cfa_results.items():
            print(f"  {cond:<15}", end="")
            for loading in results['loadings']:
                print(f"  {loading:>7.3f}", end="")
            print(f"  {results['explained_variance']:>10.1%}")
    
    # =========================================================================
    # 6. COMPUTE CFA DRIFT METRICS
    # =========================================================================
    if verbose:
        print("\n" + "-" * 80)
        print("6. CFA Loading and Score Drift")
        print("-" * 80)
    
    cfa_drift = {}
    loadings_ref = cfa_results['clean']['loadings']
    scores_ref = cfa_results['clean']['scores']
    
    for cond in transformations.keys():
        if cond == 'clean':
            continue
        
        loadings_test = cfa_results[cond]['loadings']
        scores_test = cfa_results[cond]['scores']
        
        # Loading drift
        loading_drift = compute_loading_drift(loadings_ref, loadings_test)
        
        # Score correlation (same individuals across conditions)
        score_corr, _ = pearsonr(scores_ref, scores_test)
        
        cfa_drift[f'clean_vs_{cond}'] = {
            'loading_pattern_r': loading_drift['pattern_correlation'],
            'loading_tucker': loading_drift['tucker_congruence'],
            'loading_mean_diff': loading_drift['mean_abs_diff'],
            'score_r': score_corr
        }
    
    if verbose:
        print("\n  CFA Drift from Clean Condition:")
        print(f"  {'Comparison':<25} {'Loading r':>12} {'Tucker φ':>12} {'|Δλ| mean':>12} {'Score r':>12}")
        print("  " + "-" * 75)
        for comp, drift in cfa_drift.items():
            print(f"  {comp:<25} {drift['loading_pattern_r']:>12.3f} "
                  f"{drift['loading_tucker']:>12.3f} {drift['loading_mean_diff']:>12.3f} "
                  f"{drift['score_r']:>12.3f}")
    
    # =========================================================================
    # 7. GROUND-TRUTH ATTENTION COMPARISON
    # =========================================================================
    if verbose:
        print("\n" + "-" * 80)
        print("7. Ground-Truth Attention Recovery (Across Contaminations)")
        print("-" * 80)
    
    gt_correlations = {}
    for cond in transformations.keys():
        corrs = []
        for i in range(n_samples):
            r, _ = pearsonr(cfasa_attention[cond][i], true_attention[i])
            if not np.isnan(r):
                corrs.append(r)
        gt_correlations[cond] = {
            'mean_r': np.mean(corrs),
            'sd_r': np.std(corrs)
        }
    
    if verbose:
        print("\n  CFASA-GT Correlation by Condition:")
        print(f"  {'Condition':<15} {'Mean r':>10} {'SD':>10}")
        print("  " + "-" * 35)
        for cond, stats in gt_correlations.items():
            print(f"  {cond:<15} {stats['mean_r']:>10.3f} {stats['sd_r']:>10.3f}")
    
    # =========================================================================
    # 8. SUMMARY COMPARISON
    # =========================================================================
    if verbose:
        print("\n" + "=" * 80)
        print("SUMMARY: CFASA vs CFA Under Person-Specific Response Styles")
        print("=" * 80)
        
        print("\n  CFASA Attention Stability (within-person r, clean vs contaminated):")
        cfasa_all_stable = True
        for comp, stats in cfasa_stability.items():
            status = "✓" if stats['mean_r'] > 0.85 else "⚠"
            if stats['mean_r'] <= 0.85:
                cfasa_all_stable = False
            print(f"    {status} {comp}: r = {stats['mean_r']:.3f} (min = {stats['min_r']:.3f})")
        
        print("\n  CFA Score Stability (within-person r, clean vs contaminated):")
        cfa_any_unstable = False
        for comp, drift in cfa_drift.items():
            status = "✓" if drift['score_r'] > 0.95 else "⚠"
            if drift['score_r'] <= 0.95:
                cfa_any_unstable = True
            print(f"    {status} {comp}: r = {drift['score_r']:.3f}")
        
        print("\n  CFA Loading Pattern Stability:")
        for comp, drift in cfa_drift.items():
            status = "✓" if drift['loading_pattern_r'] > 0.95 else "⚠"
            print(f"    {status} {comp}: r = {drift['loading_pattern_r']:.3f}, |Δλ| = {drift['loading_mean_diff']:.3f}")
        
        print("\n  " + "-" * 60)
        print(f"  CFASA attention stable under response style: {'YES ✓' if cfasa_all_stable else 'PARTIAL'}")
        print(f"  CFA shows response-style sensitivity:        {'YES ✓' if cfa_any_unstable else 'NO'}")
        
        if cfasa_all_stable:
            print("\n  INTERPRETATION:")
            print("    CFASA's within-person centering (x_j - x_min) removes")
            print("    person-specific intercepts. The α-tempering handles")
            print("    person-specific scales. Result: attention tracks SHAPE,")
            print("    not response style artifacts.")
    
    # =========================================================================
    # RETURN RESULTS
    # =========================================================================
    return {
        'n_samples': n_samples,
        'n_items': n_items,
        'transformations': list(transformations.keys()),
        'cfasa_stability': cfasa_stability,
        'cfasa_attention': cfasa_attention,
        'gt_correlations': gt_correlations,
        'cfa_results': cfa_results,
        'cfa_drift': cfa_drift,
        'cfasa_stable': cfasa_all_stable,
        'cfa_sensitive': cfa_any_unstable
    }


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    # Run main study with person-specific contaminations
    results = run_study4_invariance(n_samples=600, verbose=True)
    
    # Print final pass/fail
    print("\n" + "=" * 80)
    print("STUDY 4 FINAL ASSESSMENT")
    print("=" * 80)
    
    # Criteria
    cfasa_stable = results['cfasa_stable']
    cfa_sensitive = results['cfa_sensitive']
    
    print(f"\n  Criterion 1: CFASA attention stable (r > 0.85): "
          f"{'PASS ✓' if cfasa_stable else 'FAIL'}")
    print(f"  Criterion 2: CFA shows sensitivity to person styles: "
          f"{'CONFIRMED ✓' if cfa_sensitive else 'NOT CONFIRMED'}")
    
    if cfasa_stable:
        print("\n  STUDY 4: PASS")
        print("    CFASA attention is robust to person-specific response styles.")
        if cfa_sensitive:
            print("    CFA shows expected sensitivity to heterogeneous contamination.")
        else:
            print("    Note: CFA also robust in this scenario (may need stronger manipulation).")
    else:
        print("\n  STUDY 4: CHECK RESULTS")
