"""
CFASA Study 5: Specificity Validation (Self-Contained)

Demonstrates that CFASA does not hallucinate persona structure when:
- Null A (K=1): All individuals share the same attention profile
- Null B (Style Groups): Apparent groups exist only in response style, not attention

This file is self-contained and does not modify the foundation cfasa_data.py.

- "True attention variance" to use between-person variance (not item variance)
- Added cosine similarity and L1 distance to centroid metrics
- Softened cluster-factor interpretation wording
- Null A: Check centroid similarity (clusters should have ~identical attention)
- Null B: Check attention η² and ARI with style groups
- Added cluster interpretation diagnostics

Usage:
    python run_study_5_specificity.py

Author: Jonathan Lee
Version: 1.2.0
"""
from __future__ import annotations
from typing import Optional, Dict, List
import numpy as np
from scipy import stats
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score

from cfasa_config import RANDOM_SEED, DEVICE, set_reproducible_state
from cfasa_training import CFASATrainer

# =============================================================================
# Null World Data Generator (Standalone)
# =============================================================================

def _softplus(x: np.ndarray, beta: float = 1.0) -> np.ndarray:
    """Numerically stable softplus."""
    return np.where(x * beta > 20, x, np.log1p(np.exp(beta * x)) / beta)


class NullWorldGenerator:
    """
    Generator for null-world datasets where CFASA should NOT find persona structure.
    
    Supports three null modes:
    - "null_k1": Everyone shares exact same attention (K=1 true)
    - "null_style_only": Shared attention + response-style groups (style ≠ attention)
    - "null_iid_dirichlet": Independent Dirichlet draws (no cluster structure)
    """
    
    def __init__(self, n_items: int = 5):
        self.n_items = n_items
        self.item_labels = [f"Item_{j+1}" for j in range(n_items)]
        
        # Default shared attention: mildly uneven but fixed
        self._default_shared_attention = self._make_default_attention(n_items)
    
    def _make_default_attention(self, n_items: int) -> np.ndarray:
        """Create a fixed attention profile (not uniform, but single pattern)."""
        rng = np.random.default_rng(42)  # Fixed seed for reproducibility
        raw = np.array([0.35, 0.25, 0.18, 0.12, 0.10][:n_items])
        if n_items > 5:
            raw = np.concatenate([raw, np.full(n_items - 5, 0.05)])
        raw = raw + rng.normal(0, 0.02, n_items)
        raw = np.clip(raw, 0.02, None)
        return raw / raw.sum()
    
    def generate(
        self,
        n_samples: int = 800,
        null_mode: str = "null_k1",
        signal_strength: float = 5.0,
        noise_sd: float = 0.15,
        # Style group parameters (for null_style_only)
        n_style_groups: int = 3,
        style_shifts: Optional[List[float]] = None,
        style_scales: Optional[List[float]] = None,
        # Dirichlet concentration (for null_iid_dirichlet)
        dirichlet_alpha: float = 2.0,
        # Shared attention override
        shared_attention: Optional[np.ndarray] = None,
        seed: int = RANDOM_SEED
    ) -> Dict:
        """
        Generate null-world dataset.
        
        Args:
            n_samples: Number of individuals
            null_mode: One of "null_k1", "null_style_only", "null_iid_dirichlet"
            signal_strength: Factor-to-response scaling
            noise_sd: Measurement noise standard deviation
            n_style_groups: Number of style groups (for null_style_only)
            style_shifts: Additive shifts per group [default: 0.0, 0.6, 1.2]
            style_scales: Multiplicative scales per group [default: 1.0, 1.3, 0.8]
            dirichlet_alpha: Symmetric Dirichlet concentration (for null_iid_dirichlet)
            shared_attention: Override the default shared attention vector
            seed: Random seed
            
        Returns:
            Dictionary with responses, true_attention_patterns, style_groups, etc.
        """
        if null_mode not in ("null_k1", "null_style_only", "null_iid_dirichlet"):
            raise ValueError(f"Unknown null_mode: {null_mode}")
        
        rng = np.random.default_rng(seed)
        
        # Resolve shared attention
        a_star = shared_attention if shared_attention is not None else self._default_shared_attention.copy()
        a_star = a_star / (a_star.sum() + 1e-12)
        
        # === Generate attention patterns ===
        true_attention_patterns = np.zeros((n_samples, self.n_items), dtype=np.float32)
        
        if null_mode in ("null_k1", "null_style_only"):
            # Everyone gets the same attention
            true_attention_patterns[:] = a_star[None, :]
        
        elif null_mode == "null_iid_dirichlet":
            # Independent draws from symmetric Dirichlet (no cluster structure)
            alpha_vec = np.ones(self.n_items) * dirichlet_alpha
            for i in range(n_samples):
                true_attention_patterns[i] = rng.dirichlet(alpha_vec)
        
        # === Generate factor scores (always nonnegative for clean response generation) ===
        z = rng.normal(0, 1, n_samples)
        factor_scores = _softplus(z) + 0.5  # Shift to ensure positive
        
        # === Generate style groups (for null_style_only) ===
        style_groups = None
        if null_mode == "null_style_only":
            style_groups = rng.integers(0, n_style_groups, size=n_samples)
            
            # Default style parameters (no negative shifts to avoid clipping issues)
            if style_shifts is None:
                style_shifts = [0.0, 0.6, 1.2][:n_style_groups]
                style_shifts += [0.0] * max(0, n_style_groups - len(style_shifts))
            if style_scales is None:
                style_scales = [1.0, 1.3, 0.8][:n_style_groups]
                style_scales += [1.0] * max(0, n_style_groups - len(style_scales))
        
        # === Generate responses ===
        responses = np.zeros((n_samples, self.n_items), dtype=np.float32)
        
        for i in range(n_samples):
            # Base response: attention * factor * signal
            base = true_attention_patterns[i] * factor_scores[i] * signal_strength
            
            # Add small item-specific baseline (fixed across people)
            baseline = np.array([0.5, 0.4, 0.3, 0.35, 0.45][:self.n_items])
            if self.n_items > 5:
                baseline = np.concatenate([baseline, np.full(self.n_items - 5, 0.4)])
            
            # Add noise
            noise = rng.normal(0, noise_sd, self.n_items)
            
            observed = base + baseline + noise
            
            # Apply style transform (null_style_only only)
            if null_mode == "null_style_only" and style_groups is not None:
                g = style_groups[i]
                observed = style_scales[g] * observed + style_shifts[g]
            
            responses[i] = np.clip(observed, 0.0, None)
        
        return {
            'responses': responses,
            'true_attention_patterns': true_attention_patterns,
            'factor_scores': factor_scores.astype(np.float32),
            'shared_attention': a_star if null_mode != "null_iid_dirichlet" else None,
            'style_groups': style_groups,
            'null_mode': null_mode,
            'n_samples': n_samples,
            'n_items': self.n_items,
            'item_labels': self.item_labels,
            'seed': seed,
            'n_style_groups': n_style_groups if null_mode == "null_style_only" else None,
            'style_shifts': style_shifts if null_mode == "null_style_only" else None,
            'style_scales': style_scales if null_mode == "null_style_only" else None,
        }


# =============================================================================
# Metrics for Specificity Validation
# =============================================================================

def compute_adi(attention_patterns: np.ndarray) -> float:
    """
    Compute Attention Dispersion Index: mean L2 distance from centroid.
    ADI ≈ 0 indicates homogeneous attention (no individual differences).
    """
    centroid = np.mean(attention_patterns, axis=0)
    distances = np.linalg.norm(attention_patterns - centroid, axis=1)
    return float(np.mean(distances))


def compute_silhouette_scores(attention_patterns: np.ndarray, k_range: range = range(2, 7)) -> Dict:
    """
    Compute silhouette scores across K values.
    Returns dict with best_k, best_silhouette, all_scores, and cluster_labels.
    """
    scores = {}
    all_labels = {}
    
    for k in k_range:
        if k >= len(attention_patterns):
            continue
        try:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels = kmeans.fit_predict(attention_patterns)
            score = silhouette_score(attention_patterns, labels)
            scores[k] = float(score)
            all_labels[k] = labels
        except Exception:
            scores[k] = float('nan')
    
    if not scores:
        return {'best_k': None, 'best_silhouette': float('nan'), 'all_scores': {}, 'all_labels': {}}
    
    best_k = max(scores, key=lambda k: scores[k] if not np.isnan(scores[k]) else -np.inf)
    return {
        'best_k': best_k,
        'best_silhouette': scores[best_k],
        'all_scores': scores,
        'all_labels': all_labels
    }


def compute_centroid_similarity(attention_patterns: np.ndarray, n_clusters: int = 2) -> Dict:
    """
    Check if K-means clusters have essentially identical attention centroids.
    
    This is the key test for Null A: clusters may exist (due to intensity variation)
    but they should all have the SAME attention profile.
    
    Returns:
        min_centroid_corr: Minimum pairwise correlation between centroids
        mean_centroid_corr: Mean pairwise correlation between centroids
        min_cosine_sim: Minimum pairwise cosine similarity (primary metric)
        max_l1_distance: Maximum L1 distance between centroids
        centroids: The actual centroid vectors
    """
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = kmeans.fit_predict(attention_patterns)
    
    # Compute centroids from data (more accurate than kmeans.cluster_centers_ for attention)
    centroids = np.array([attention_patterns[labels == k].mean(axis=0) for k in range(n_clusters)])
    
    # Compute pairwise metrics between centroids
    pairwise_corrs = []
    pairwise_cosines = []
    pairwise_l1 = []
    
    for i in range(n_clusters):
        for j in range(i + 1, n_clusters):
            # Correlation
            corr = np.corrcoef(centroids[i], centroids[j])[0, 1]
            pairwise_corrs.append(corr)
            
            # Cosine similarity (natural for simplex vectors)
            cos_sim = np.dot(centroids[i], centroids[j]) / (
                np.linalg.norm(centroids[i]) * np.linalg.norm(centroids[j]) + 1e-12
            )
            pairwise_cosines.append(cos_sim)
            
            # L1 distance (total variation)
            l1_dist = np.sum(np.abs(centroids[i] - centroids[j]))
            pairwise_l1.append(l1_dist)
    
    if not pairwise_corrs:
        return {
            'min_centroid_corr': 1.0, 'mean_centroid_corr': 1.0,
            'min_cosine_sim': 1.0, 'max_l1_distance': 0.0,
            'centroids': centroids, 'labels': labels
        }
    
    return {
        'min_centroid_corr': float(np.min(pairwise_corrs)),
        'mean_centroid_corr': float(np.mean(pairwise_corrs)),
        'min_cosine_sim': float(np.min(pairwise_cosines)),
        'max_l1_distance': float(np.max(pairwise_l1)),
        'centroids': centroids,
        'labels': labels,
        'cluster_sizes': [int(np.sum(labels == k)) for k in range(n_clusters)]
    }


def compute_cluster_factor_correlation(cluster_labels: np.ndarray, factor_scores: np.ndarray) -> float:
    """
    Compute correlation between cluster assignment and factor scores.
    
    If clusters are driven by intensity (not persona), this will be high.
    """
    # Use point-biserial correlation for K=2, or eta for K>2
    unique_clusters = np.unique(cluster_labels)
    
    if len(unique_clusters) == 2:
        # Point-biserial correlation
        return float(np.abs(np.corrcoef(cluster_labels, factor_scores)[0, 1]))
    else:
        # Eta-squared (ANOVA effect size)
        groups = [factor_scores[cluster_labels == k] for k in unique_clusters]
        ss_between = sum(len(g) * (np.mean(g) - np.mean(factor_scores))**2 for g in groups)
        ss_total = np.sum((factor_scores - np.mean(factor_scores))**2)
        eta2 = ss_between / (ss_total + 1e-12)
        return float(np.sqrt(eta2))  # Return correlation-scale metric


def compute_style_discriminability(
    attention_patterns: np.ndarray,
    factor_scores: np.ndarray,
    style_groups: np.ndarray
) -> Dict:
    """
    Compute how well style groups are discriminable in attention vs factor scores.
    Uses eta-squared from one-way ANOVA.
    """
    unique_groups = np.unique(style_groups)
    n_groups = len(unique_groups)
    
    if n_groups < 2:
        return {'attention_eta2': 0.0, 'factor_eta2': 0.0, 'factor_f_stat': 0.0, 'factor_p_val': 1.0}
    
    # Factor score discriminability (1D ANOVA)
    groups_factor = [factor_scores[style_groups == g] for g in unique_groups]
    f_stat, p_val = stats.f_oneway(*groups_factor)
    
    # Eta-squared for factor scores
    ss_between = sum(len(g) * (np.mean(g) - np.mean(factor_scores))**2 for g in groups_factor)
    ss_total = np.sum((factor_scores - np.mean(factor_scores))**2)
    factor_eta2 = ss_between / (ss_total + 1e-12)
    
    # Attention discriminability (multivariate → use centroid-based eta)
    attention_centroids = np.array([attention_patterns[style_groups == g].mean(axis=0) 
                                     for g in unique_groups])
    global_centroid = attention_patterns.mean(axis=0)
    
    ss_between_att = sum(
        np.sum(style_groups == g) * np.sum((attention_centroids[i] - global_centroid)**2)
        for i, g in enumerate(unique_groups)
    )
    ss_total_att = np.sum((attention_patterns - global_centroid)**2)
    attention_eta2 = ss_between_att / (ss_total_att + 1e-12)
    
    return {
        'attention_eta2': float(attention_eta2),
        'factor_eta2': float(factor_eta2),
        'factor_f_stat': float(f_stat),
        'factor_p_val': float(p_val)
    }


# =============================================================================
# Success Criteria
# =============================================================================

def check_null_a_success(centroid_similarity: Dict, threshold: float = 0.95) -> Dict:
    """
    Null A passes if cluster centroids have essentially identical attention profiles.
    
    Clusters may exist (due to factor score / intensity variation), but they
    should all represent the SAME underlying attention pattern.
    """
    min_cosine = centroid_similarity['min_cosine_sim']
    passed = min_cosine >= threshold
    
    return {
        'passed': passed,
        'criterion': f'min_cosine_sim >= {threshold}',
        'value': min_cosine,
        'interpretation': 'Clusters have identical attention' if passed else 'Clusters have different attention'
    }


def check_null_c_success(attention_eta2: float, ari_with_style: float,
                         eta2_threshold: float = 0.01, ari_threshold: float = 0.05) -> Dict:
    """
    Null B passes if:
    1. Style groups don't predict attention (η² < threshold)
    2. Discovered clusters don't align with style groups (|ARI| < threshold)
    """
    eta2_ok = attention_eta2 < eta2_threshold
    ari_ok = abs(ari_with_style) < ari_threshold
    passed = eta2_ok and ari_ok
    
    return {
        'passed': passed,
        'eta2_passed': eta2_ok,
        'ari_passed': ari_ok,
        'criterion': f'attention_η² < {eta2_threshold} AND |ARI| < {ari_threshold}',
        'attention_eta2': attention_eta2,
        'ari': ari_with_style,
        'interpretation': 'Style does not predict attention' if passed else 'Style predicts attention'
    }


# =============================================================================
# Study 5 Runner
# =============================================================================

def run_study5(n_samples: int = 800, n_items: int = 5, verbose: bool = True) -> Dict:
    """
    Run Study 5: Specificity Validation.
    
    Tests two null conditions:
    - Null A (K=1): Single shared attention, should find no persona structure
    - Null B (Style Groups): Style groups exist, but attention should not cluster by style
    
    Returns:
        Dictionary with results for both conditions
    """
    set_reproducible_state(RANDOM_SEED)
    
    if verbose:
        print("=" * 80)
        print("STUDY 5: SPECIFICITY VALIDATION")
        print("=" * 80)
        print(f"Settings: N={n_samples}, J={n_items}")
        print()
        print("Success Criteria (Corrected):")
        print("  Null A: Cluster centroids must be similar (min cosine >= 0.95)")
        print("  Null B: Style must not predict attention (η² < 0.01 AND |ARI| < 0.05)")
        print()
    
    generator = NullWorldGenerator(n_items=n_items)
    results = {}
    
    # =========================================================================
    # Condition A: Null K=1 (Everyone shares same attention)
    # =========================================================================
    if verbose:
        print("-" * 80)
        print("CONDITION A: Null K=1 (Single Shared Attention)")
        print("-" * 80)
    
    data_a = generator.generate(
        n_samples=n_samples,
        null_mode="null_k1",
        seed=RANDOM_SEED
    )
    
    if verbose:
        print(f"Shared attention: [{', '.join(f'{x:.3f}' for x in data_a['shared_attention'])}]")
        # Between-person variance (should be ~0 for null K=1)
        between_person_var = np.mean(np.var(data_a['true_attention_patterns'], axis=0))
        print(f"Between-person attention variance: {between_person_var:.6f} (should be ~0)")
    
    # Train CFASA
    trainer_a = CFASATrainer(n_items=n_items, n_attention_heads=3, mode='self_consistency')
    train_result_a = trainer_a.train(
        responses=data_a['responses'],
        true_attention_patterns=data_a['true_attention_patterns'],
        n_epochs=200,
        verbose=False
    )
    
    # Get predictions
    preds_a = trainer_a.predict_attention_patterns(data_a['responses'])
    learned_attention_a = preds_a['attention_weights']
    learned_factors_a = preds_a['factor_scores']
    
    # Compute metrics
    adi_a = compute_adi(learned_attention_a)
    silhouette_a = compute_silhouette_scores(learned_attention_a)
    centroid_sim_a = compute_centroid_similarity(learned_attention_a, n_clusters=2)
    
    # Cluster-factor correlation (diagnostic: shows clusters are intensity-driven)
    cluster_factor_corr_a = compute_cluster_factor_correlation(
        centroid_sim_a['labels'], learned_factors_a
    )
    
    # GT recovery
    gt_corrs_a = [np.corrcoef(learned_attention_a[i], data_a['true_attention_patterns'][i])[0, 1]
                  for i in range(n_samples)]
    mean_gt_corr_a = np.nanmean(gt_corrs_a)
    
    # Check success (corrected criterion)
    success_a = check_null_a_success(centroid_sim_a)
    
    results['null_k1'] = {
        'adi': adi_a,
        'best_silhouette': silhouette_a['best_silhouette'],
        'best_k': silhouette_a['best_k'],
        'silhouette_scores': silhouette_a['all_scores'],
        'mean_gt_corr': mean_gt_corr_a,
        'centroid_similarity': centroid_sim_a,
        'cluster_factor_corr': cluster_factor_corr_a,
        'success': success_a,
        'training_results': train_result_a
    }
    
    if verbose:
        print(f"\nDescriptive Metrics:")
        print(f"  ADI (attention dispersion): {adi_a:.4f}")
        print(f"  Mean GT correlation: {mean_gt_corr_a:.3f}")
        print(f"  Best silhouette (K=2..6): {silhouette_a['best_silhouette']:.4f} at K={silhouette_a['best_k']}")
        
        print(f"\nCluster Analysis (K=2):")
        print(f"  Cluster sizes: {centroid_sim_a['cluster_sizes']}")
        print(f"  Centroid similarity metrics:")
        print(f"    Correlation: {centroid_sim_a['min_centroid_corr']:.4f}")
        print(f"    Cosine sim:  {centroid_sim_a['min_cosine_sim']:.4f}")
        print(f"    Max L1 dist: {centroid_sim_a['max_l1_distance']:.4f}")
        print(f"  Cluster-factor correlation: {cluster_factor_corr_a:.3f}")
        print(f"    (Nontrivial value suggests intensity contributes to clustering geometry)")
        
        print(f"\n  Centroid 0: [{', '.join(f'{x:.3f}' for x in centroid_sim_a['centroids'][0])}]")
        print(f"  Centroid 1: [{', '.join(f'{x:.3f}' for x in centroid_sim_a['centroids'][1])}]")
        print(f"  True:       [{', '.join(f'{x:.3f}' for x in data_a['shared_attention'])}]")
        
        print(f"\nSuccess Criterion: {success_a['criterion']}")
        if success_a['passed']:
            print(f"  ✓ PASS: {success_a['interpretation']} (cos = {success_a['value']:.4f})")
        else:
            print(f"  ✗ FAIL: {success_a['interpretation']} (cos = {success_a['value']:.4f})")
    
    # =========================================================================
    # Condition B: Null Style Groups (Style ≠ Attention)
    # =========================================================================
    if verbose:
        print()
        print("-" * 80)
        print("CONDITION B: Null Style Groups (Response Style ≠ Attention)")
        print("-" * 80)
    
    data_c = generator.generate(
        n_samples=n_samples,
        null_mode="null_style_only",
        n_style_groups=3,
        seed=RANDOM_SEED + 100
    )
    
    if verbose:
        print(f"Shared attention: [{', '.join(f'{x:.3f}' for x in data_c['shared_attention'])}]")
        print(f"Style groups: {data_c['n_style_groups']}")
        print(f"  Shifts: {data_c['style_shifts']}")
        print(f"  Scales: {data_c['style_scales']}")
        for g in range(data_c['n_style_groups']):
            n_g = np.sum(data_c['style_groups'] == g)
            print(f"  Group {g}: n={n_g}")
    
    # Train CFASA
    trainer_c = CFASATrainer(n_items=n_items, n_attention_heads=3, mode='self_consistency')
    train_result_c = trainer_c.train(
        responses=data_c['responses'],
        true_attention_patterns=data_c['true_attention_patterns'],
        n_epochs=200,
        verbose=False
    )
    
    # Get predictions
    preds_c = trainer_c.predict_attention_patterns(data_c['responses'])
    learned_attention_c = preds_c['attention_weights']
    learned_factors_c = preds_c['factor_scores']
    
    # Compute metrics
    adi_c = compute_adi(learned_attention_c)
    silhouette_c = compute_silhouette_scores(learned_attention_c)
    centroid_sim_c = compute_centroid_similarity(learned_attention_c, n_clusters=2)
    
    # Style discriminability
    style_discrim = compute_style_discriminability(
        learned_attention_c,
        learned_factors_c,
        data_c['style_groups']
    )
    
    # GT recovery
    gt_corrs_c = [np.corrcoef(learned_attention_c[i], data_c['true_attention_patterns'][i])[0, 1]
                  for i in range(n_samples)]
    mean_gt_corr_c = np.nanmean(gt_corrs_c)
    
    # Cluster alignment with style groups
    if silhouette_c['best_k'] and silhouette_c['best_k'] in silhouette_c['all_labels']:
        cluster_labels_c = silhouette_c['all_labels'][silhouette_c['best_k']]
        ari_with_style = adjusted_rand_score(data_c['style_groups'], cluster_labels_c)
    else:
        cluster_labels_c = centroid_sim_c['labels']
        ari_with_style = adjusted_rand_score(data_c['style_groups'], cluster_labels_c)
    
    # Check success (corrected criterion)
    success_c = check_null_c_success(style_discrim['attention_eta2'], ari_with_style)
    
    results['null_style_only'] = {
        'adi': adi_c,
        'best_silhouette': silhouette_c['best_silhouette'],
        'best_k': silhouette_c['best_k'],
        'silhouette_scores': silhouette_c['all_scores'],
        'mean_gt_corr': mean_gt_corr_c,
        'attention_eta2': style_discrim['attention_eta2'],
        'factor_eta2': style_discrim['factor_eta2'],
        'factor_f_stat': style_discrim['factor_f_stat'],
        'factor_p_val': style_discrim['factor_p_val'],
        'ari_with_style': ari_with_style,
        'centroid_similarity': centroid_sim_c,
        'success': success_c,
        'training_results': train_result_c
    }
    
    if verbose:
        print(f"\nDescriptive Metrics:")
        print(f"  ADI (attention dispersion): {adi_c:.4f}")
        print(f"  Mean GT correlation: {mean_gt_corr_c:.3f}")
        print(f"  Best silhouette (K=2..6): {silhouette_c['best_silhouette']:.4f} at K={silhouette_c['best_k']}")
        
        print(f"\nStyle Group Discriminability (Key Test):")
        print(f"  Factor scores η²: {style_discrim['factor_eta2']:.3f} (F={style_discrim['factor_f_stat']:.1f}, p={style_discrim['factor_p_val']:.4f})")
        print(f"  Attention η²:     {style_discrim['attention_eta2']:.4f}")
        print(f"  ARI (clusters ↔ style): {ari_with_style:.4f}")
        
        print(f"\nSuccess Criterion: {success_c['criterion']}")
        if success_c['passed']:
            print(f"  ✓ PASS: {success_c['interpretation']}")
            print(f"    η² = {success_c['attention_eta2']:.4f} < 0.01 ✓")
            print(f"    |ARI| = {abs(success_c['ari']):.4f} < 0.05 ✓")
        else:
            status_eta = "✓" if success_c['eta2_passed'] else "✗"
            status_ari = "✓" if success_c['ari_passed'] else "✗"
            print(f"  ✗ FAIL: {success_c['interpretation']}")
            print(f"    η² = {success_c['attention_eta2']:.4f} < 0.01 {status_eta}")
            print(f"    |ARI| = {abs(success_c['ari']):.4f} < 0.05 {status_ari}")
    
    # =========================================================================
    # Summary
    # =========================================================================
    if verbose:
        print()
        print("=" * 80)
        print("STUDY 5 SUMMARY")
        print("=" * 80)
        print()
        print(f"{'Condition':<20} {'ADI':>8} {'GT Corr':>10} {'Criterion':>30} {'Result':>10}")
        print("-" * 80)
        
        r_a = results['null_k1']
        status_a = "PASS ✓" if r_a['success']['passed'] else "FAIL ✗"
        print(f"{'Null A (K=1)':<20} {r_a['adi']:>8.4f} {r_a['mean_gt_corr']:>10.3f} "
              f"{'centroid cos = ' + format(r_a['centroid_similarity']['min_cosine_sim'], '.3f'):>30} {status_a:>10}")
        
        r_c = results['null_style_only']
        status_c = "PASS ✓" if r_c['success']['passed'] else "FAIL ✗"
        print(f"{'Null B (Style)':<20} {r_c['adi']:>8.4f} {r_c['mean_gt_corr']:>10.3f} "
              f"{'η²=' + format(r_c['attention_eta2'], '.4f') + ', ARI=' + format(r_c['ari_with_style'], '.3f'):>30} {status_c:>10}")
        
        print()
        print("Key Insight:")
        print("  Silhouette > 0 does NOT mean CFASA hallucinates personas.")
        print("  Clusters can reflect intensity variation while attention profiles remain identical.")
        print("  The correct test is whether clusters have different ATTENTION, not whether clusters exist.")
        print()
        
        print("Contrast (Null B):")
        print(f"  Style predicts FACTOR SCORES: η² = {r_c['factor_eta2']:.3f} (strong)")
        print(f"  Style predicts ATTENTION:     η² = {r_c['attention_eta2']:.4f} (negligible)")
        print("  → CFASA separates shape (attention) from intensity/style (factor scores)")
        print()
        
        all_pass = r_a['success']['passed'] and r_c['success']['passed']
        if all_pass:
            print("CONCLUSION: CFASA demonstrates SPECIFICITY")
            print("  - Does not hallucinate persona structure when none exists (Null A)")
            print("  - Does not conflate response style with measurement allocation (Null B)")
        else:
            print("CONCLUSION: Some criteria not met. Review individual results above.")
    
    return results


# =============================================================================
# Entry Point
# =============================================================================

if __name__ == "__main__":
    results = run_study5(n_samples=800, n_items=5, verbose=True)
